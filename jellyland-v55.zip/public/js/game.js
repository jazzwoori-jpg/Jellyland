/* JELLY LAND — 메인 게임 */
(function () {
  const CFG = window.JELLY_CONFIG;
  const API = window.JellyAPI;
  const I = window.I18N;
  const t = (k, v) => I.t(k, v);
  const L = (v) => I.L(v);
  const $ = (s) => document.querySelector(s);
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const FONT = "'Galmuri11', 'Galmuri9', 'Apple SD Gothic Neo', 'Hiragino Sans', 'Noto Sans JP', sans-serif";
  const ARTIST_LOOK = { gender: "f", hair: 1, hairColor: 0, skin: 0, outfit: 1, eye: 1 }; // 긴 흑발 + Can't Stop! 곰돌이 후디 + 키타
  const APP_VERSION = "55"; // public/version.json 과 같게 — 배포 때마다 올리면 접속 중인 사람에게 새 버전 알림
  const staff = (r) => r === "artist" || r === "admin"; // 관리자 (호스트 포함)
  const IS_TOUCH = "ontouchstart" in window || navigator.maxTouchPoints > 0;
  if (IS_TOUCH) document.body.classList.add("touch");
  if (/iPhone|iPad|iPod/.test(navigator.userAgent) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1)) document.body.classList.add("ios");

  const canvas = $("#game");
  const ctx = canvas.getContext("2d");
  let dpr = 1, S = 3, VW = 0, VH = 0;

  const G = {
    mode: "title", // title | creator | world
    user: null,
    scene: null, worlds: {},
    player: { x: 640, y: 840, dir: "up", moving: false, t: 0 },
    others: new Map(),
    npcs: [],
    cam: { x: 0, y: 0 },
    keys: new Set(),
    joy: { x: 0, y: 0 },
    target: null, pendingZone: null,
    zone: null,
    bubbles: new Map(), // userId -> {m, until}
    chat: { since: 0, seen: new Set(), msgs: [], notice: null, unread: 0 },
    online: 1,
    modalOpen: false,
    lastInput: 0,
    t: 0,
  };

  // ---------------- 화면 크기 / 모바일 대응 ----------------
  function resize() {
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    VW = window.innerWidth; VH = window.innerHeight;
    canvas.width = Math.round(VW * dpr); canvas.height = Math.round(VH * dpr);
    S = Math.max(1.5, Math.min(4, Math.floor(Math.min(VW / 470, VH / 300) * 2) / 2));
    ctx.imageSmoothingEnabled = false;
    document.documentElement.style.setProperty("--vh", VH + "px");
  }
  window.addEventListener("resize", resize);
  window.addEventListener("orientationchange", () => setTimeout(resize, 250));
  resize();
  // 모바일 키보드가 올라오면 채팅창을 키보드 위로 올림 (특히 iPhone)
  if (window.visualViewport) {
    const vv = window.visualViewport;
    const onVV = () => {
      const kb = Math.max(0, window.innerHeight - vv.height - vv.offsetTop);
      document.documentElement.style.setProperty("--kb", kb + "px");
      document.body.classList.toggle("kb-open", kb > 80);
    };
    vv.addEventListener("resize", onVV); vv.addEventListener("scroll", onVV);
  }
  // iOS 핀치 확대·더블탭 확대 방지 (입력창 제외)
  document.addEventListener("gesturestart", (e) => e.preventDefault());
  let lastTouch = 0;
  document.addEventListener("touchend", (e) => {
    const now = Date.now();
    if (now - lastTouch < 300 && !/^(INPUT|TEXTAREA|A|BUTTON|SELECT|LABEL)$/.test(e.target.tagName)) e.preventDefault();
    lastTouch = now;
  }, { passive: false });
  document.addEventListener("focusout", () => { if (IS_TOUCH) setTimeout(() => window.scrollTo(0, 0), 50); });

  // ---------------- 토스트 / 페이드 ----------------
  let toastT;
  function toast(msg, ms) { const el = $("#toast"); el.textContent = msg; el.style.opacity = 1; clearTimeout(toastT); toastT = setTimeout(() => (el.style.opacity = 0), ms || 2200); }
  const fade = (on) => new Promise((r) => { $("#fade").classList.toggle("on", on); setTimeout(r, 360); });

  // ---------------- 월드 ----------------
  function buildWorlds() {
    G.worlds.plaza = World.buildPlaza();
    G.worlds.lounge = World.buildLounge();
    G.worlds.shop = World.buildShop();
    G.worlds.cinema = World.buildCinema();
    G.worlds.meadow = World.buildMeadow();
    G.worlds.beach = World.buildBeach();
    const oldSea = G.worlds.sea;
    G.worlds.sea = World.buildSea();
    if (oldSea) { G.worlds.sea.placeChest(oldSea.chestSpot); Object.assign(G.worlds.sea.sea, oldSea.sea); G.worlds.sea.icons[0].icon = oldSea.icons[0].icon; }
  }
  function scene() { return G.worlds[G.scene]; }
  // 장소별 배경음악 (샵은 라운지 음악, 초원은 광장 음악, 시네마·바닷속은 없음)
  const bgmFor = (id) => (id === "shop" ? "lounge" : id === "meadow" ? "plaza" : id);
  // 장소 음악 틀기: 🏖️ 해변은 직접 만든 잔잔한 음악 + 파도·갈매기 소리, 나머지는 배경음악 파일
  function sceneMusic(id) {
    if (id === "beach") { BGM.stop(); try { Chip.play("beach"); Ambient.start(); } catch {} return; }
    try { if (Chip.playing === "beach") Chip.stop(); Ambient.stop(); } catch {}
    BGM.play(bgmFor(id));
  }
  function stopMusic() { BGM.stop(); try { if (Chip.playing === "beach") Chip.stop(); Ambient.stop(); } catch {} }
  // 혼자 들어가는 공간 (분수대 속 바다 · 젤리젤리샵 안): 다른 사람에게는 입구 앞에 서 있는 것처럼 보임
  const soloScene = (sc) => sc === "sea"; // 젤리젤리샵 · 젤리 시네마는 다른 사람과 함께 있는 방
  function setScene(id, pos) {
    G.scene = id;
    const w = scene();
    const p = pos || w.spawn;
    G.player.x = p.x; G.player.y = p.y; G.player.dir = pos && pos.dir ? pos.dir : "up";
    G.target = null; G.pendingZone = null; G.others.clear(); setTimeout(rtEnsure, 0); setTimeout(() => { if (G.mode === "world") kickSync(); }, 60); // 방을 옮기면 바로 알리고 그 방 사람들을 불러옴 G.zone = null; G.seat = null; G.seatObj = null;
    $("#prompt").classList.add("hidden");
    buildMinimap();
    updateSceneLabels();
    resetChat();
    if (G.mode === "world" && !G.gameOpen) sceneMusic(id);
    if (id !== "beach" && G.fish) endFishing(true);
    if (id === "plaza") loadWhaleHall();
  }
  function updateSceneLabels() {
    if (!G.scene) return;
    $("#mm-label").textContent = G.scene === "plaza" ? t("mapPlaza") : G.scene === "sea" ? t("mapSea") : G.scene === "shop" ? t("bShop") : G.scene === "cinema" ? t("bCinema") : G.scene === "meadow" ? t("mapMeadow") : G.scene === "beach" ? t("mapBeach") : t("mapLounge");
    $("#chat-title").textContent = G.scene === "lounge" ? t("chatLounge") : G.scene === "shop" ? t("chatShop") : G.scene === "cinema" ? t("chatCinema") : G.scene === "meadow" ? t("chatMeadow") : G.scene === "beach" ? t("chatBeach") : t("chatPlaza");
    $("#btn-gb").classList.toggle("hidden", G.scene !== "lounge");
  }

  function blocked(x, y) {
    const w = scene();
    if (!w.walkable(x, y)) return true;
    for (const [a, b, cw, ch] of w.colliders) if (x > a && x < a + cw && y > b && y < b + ch) return true;
    return false;
  }
  const blockedFeet = (x, y) => blocked(x - 4, y) || blocked(x + 4, y) || blocked(x, y - 3) || blocked(x, y + 1);

  // 주민 NPC (분위기용)
  function makeNPCs() {
    G.npcs = [0, 1, 2].map((i) => ({ i, av: Avatar.random(), x: 560 + i * 60, y: 640 + (i % 2) * 40, tx: 0, ty: 0, dir: "down", moving: false, wait: 1 + i, t: 0, line: 0 }));
  }
  function updateNPCs(dt) {
    if (G.scene !== "plaza") return;
    for (const n of G.npcs) {
      n.t += dt;
      // 대사: 1번부터 10번까지 순서대로, 말풍선 4.5초 → 쉬고 → 다음 대사
      if (n.nextTalk === undefined) { n.nextTalk = G.t + 1500 + n.i * 2500; n.line = 0; }
      if (G.t >= n.nextTalk) {
        const lines = t("npcLines")[n.i] || [];
        n.say = lines[n.line % Math.max(1, lines.length)]; n.sayUntil = G.t + 4500;
        n.line = (n.line + 1) % Math.max(1, lines.length);
        n.nextTalk = G.t + 7500;
      }
      if (n.wait > 0) { n.wait -= dt; n.moving = false; if (n.wait <= 0) { n.tx = n.x + (Math.random() - 0.5) * 220; n.ty = n.y + (Math.random() - 0.5) * 160; } continue; }
      const dx = n.tx - n.x, dy = n.ty - n.y, d = Math.hypot(dx, dy);
      if (d < 3) { n.wait = 1.5 + Math.random() * 3; continue; }
      const sp = 40 * dt, nx = n.x + (dx / d) * sp, ny = n.y + (dy / d) * sp;
      if (blockedFeet(nx, ny)) { n.wait = 0.8; continue; }
      n.x = nx; n.y = ny; n.moving = true;
      n.dir = Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? "right" : "left") : dy > 0 ? "down" : "up";
    }
  }

  // ---------------- 입력 ----------------
  const KEYMAP = { ArrowUp: "u", KeyW: "u", ArrowDown: "d", KeyS: "d", ArrowLeft: "l", KeyA: "l", ArrowRight: "r", KeyD: "r" };
  window.addEventListener("keydown", (e) => {
    if (e.target.tagName === "INPUT") { if (e.key === "Escape") e.target.blur(); return; }
    if (G.modalOpen) { if (e.key === "Escape") closeModal(); return; }
    if (G.mode !== "world") return;
    if (KEYMAP[e.code]) { G.keys.add(KEYMAP[e.code]); G.target = null; e.preventDefault(); }
    if (e.code === "KeyE" || e.code === "Space") { interact(); e.preventDefault(); }
    if (e.code === "Enter") { openChat(); $("#chat-input").focus(); e.preventDefault(); }
    if (e.code === "KeyP") { takeScreenshot(); e.preventDefault(); }
  });
  window.addEventListener("keyup", (e) => { if (KEYMAP[e.code]) G.keys.delete(KEYMAP[e.code]); });
  window.addEventListener("blur", () => G.keys.clear());

  const toWorld = (sx, sy) => ({ x: sx / S + G.cam.x, y: sy / S + G.cam.y });
  canvas.addEventListener("pointerdown", (e) => {
    if (G.mode !== "world" || G.modalOpen || G.fish) return; // 낚시 중에는 화면을 눌러도 걷지 않음
    if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
    const p = toWorld(e.clientX, e.clientY);
    const w = scene();
    // 건물 클릭 → 문 앞으로 이동 후 입장
    if (w.buildings) for (const b of w.buildings) if (p.x > b.x && p.x < b.x + b.w && p.y > b.y && p.y < b.y + b.h + 6) { G.target = { x: b.door.x, y: b.door.y + 6 }; G.pendingZone = b.id; return; }
    if (w.clickables) for (const ck of w.clickables) if (Math.hypot(p.x - ck.x, p.y - ck.y) < ck.r) { G.target = { ...ck.front }; G.pendingZone = ck.go; return; }
    if (w.piano && Math.abs(p.x - w.piano.x) < 26 && p.y > w.piano.y - 26 && p.y < w.piano.y + 16) { G.target = { ...w.piano.front }; G.pendingZone = "piano"; return; }
    if (w.artist && Math.hypot(p.x - w.artist.x, p.y - 18 - w.artist.y) < 22) { G.target = { x: w.artist.x + 10, y: w.artist.y + 26 }; G.pendingZone = "profile"; return; }
    G.target = p; G.pendingZone = null;
  });

  // 가상 조이스틱 (안드로이드 / 아이폰)
  (function joystick() {
    const joy = $("#joy"), knob = joy.querySelector(".knob");
    let id = null, cx = 0, cy = 0;
    joy.addEventListener("pointerdown", (e) => { e.preventDefault(); id = e.pointerId; const r = joy.getBoundingClientRect(); cx = r.left + r.width / 2; cy = r.top + r.height / 2; try { joy.setPointerCapture(id); } catch {} move(e); G.target = null; });
    joy.addEventListener("pointermove", (e) => { if (e.pointerId === id) { e.preventDefault(); move(e); } });
    const end = () => { id = null; G.joy.x = G.joy.y = 0; knob.style.transform = ""; };
    joy.addEventListener("pointerup", end); joy.addEventListener("pointercancel", end); joy.addEventListener("lostpointercapture", end);
    function move(e) {
      let dx = e.clientX - cx, dy = e.clientY - cy; const d = Math.hypot(dx, dy), m = 44;
      if (d > m) { dx = (dx / d) * m; dy = (dy / d) * m; }
      knob.style.transform = `translate(${dx}px,${dy}px)`;
      G.joy.x = d > 8 ? dx / m : 0; G.joy.y = d > 8 ? dy / m : 0;
    }
  })();
  $("#act").addEventListener("click", () => { if (!Fishing.active) interact(); });
  $("#act").addEventListener("pointerdown", (e) => { if (Fishing.active) { e.preventDefault(); Fishing.tap(); } }); // 🎣 낚시 중: 누르는 순간 바로 (타이밍 게임)
  $("#prompt").addEventListener("click", interact);

  // ---------------- 업데이트 ----------------
  function update(dt) {
    G.t += dt * 1000;
    cafeTick();
    const p = G.player;
    let vx = 0, vy = 0;
    if (G.mode === "world" && !G.modalOpen && !G.frozen && !G.quizOpen) {
      if (G.keys.has("u")) vy -= 1; if (G.keys.has("d")) vy += 1; if (G.keys.has("l")) vx -= 1; if (G.keys.has("r")) vx += 1;
      if (G.joy.x || G.joy.y) { vx = G.joy.x; vy = G.joy.y; }
      if (G.seat && (vx || vy || G.target)) standUp();
      if (!vx && !vy && G.target) {
        const dx = G.target.x - p.x, dy = G.target.y - p.y, d = Math.hypot(dx, dy);
        if (d < 3) { G.target = null; if (G.pendingZone) { const z = G.pendingZone; G.pendingZone = null; runZone(z); } }
        else { vx = dx / d; vy = dy / d; }
      }
    }
    const len = Math.hypot(vx, vy);
    const wasMoving = p.moving;
    if (p.vx === undefined) { p.vx = 0; p.vy = 0; }
    p.moving = len > 0.05;
    if (p.moving) G.lastInput = Date.now();
    if (!p.moving) { p.vx = 0; p.vy = 0; }
    if (p.moving !== wasMoving && G.mode === "world" && !RT.ok) kickSync(); // 출발·정지 순간 바로 알림 (실시간 서버가 없을 때)
    if (p.moving) {
      if (len > 1) { vx /= len; vy /= len; }
      const sp = (G.scene === "sea" ? 74 : 92) * dt;
      const nx = p.x + vx * sp, ny = p.y + vy * sp;
      const ox = p.x, oy = p.y;
      if (!blockedFeet(nx, p.y)) p.x = nx;
      if (!blockedFeet(p.x, ny)) p.y = ny;
      p.dir = Math.abs(vx) > Math.abs(vy) ? (vx > 0 ? "right" : "left") : vy > 0 ? "down" : "up";
      p.t += dt;
      // 실제 이동 속도 (다른 사람 화면에서 미리 예측해 움직이도록 함께 보냄)
      p.vx = p.vx * 0.5 + ((p.x - ox) / dt) * 0.5; p.vy = p.vy * 0.5 + ((p.y - oy) / dt) * 0.5;
      if (G.target && Math.hypot(p.x - ox, p.y - oy) < 0.01) { p.stuck = (p.stuck || 0) + dt; if (p.stuck > 0.35) { G.target = null; G.pendingZone = null; p.stuck = 0; } } else p.stuck = 0;
    }
    // 내 이동 기록: 0.1초마다 위치를 남겨 다음 sync 때 함께 보냄 (다른 사람 화면에서 그대로 재생)
    const nowMs = Date.now();
    if (G.mode === "world" && !soloScene(G.scene)) {
      if (!G.trail) G.trail = [];
      const lt = G.trail[G.trail.length - 1];
      if (p.moving || wasMoving) { if (!lt || nowMs - lt[0] >= 100 || (!p.moving && (lt[1] !== Math.round(p.x) || lt[2] !== Math.round(p.y)))) G.trail.push([nowMs, Math.round(p.x), Math.round(p.y)]); }
      if (G.trail.length > 40) G.trail.splice(0, G.trail.length - 40);
    }
    // ⚡ 실시간 서버로 내 위치 보내기 (걷는 동안 1초에 15번, 멈추는 순간 1번)
    if (RT.ok && G.mode === "world" && !soloScene(G.scene) && RT.room === G.scene) {
      if (p.moving && nowMs - RT.lastSend >= 66) rtSend(1);
      else if (!p.moving && (wasMoving || (nowMs - RT.lastSend > 250 && (Math.abs(p.x - RT.lx) > 2 || Math.abs(p.y - RT.ly) > 2)))) rtSend(0); // 멈춤 · 순간이동(문 출입 등)
    }
    if (nowMs - RT.chk > 1000) { RT.chk = nowMs; rtEnsure(); }
    RT.delay += Math.max(-dt * 40, Math.min(dt * 150, RT.target - RT.delay));
    const rtAt = Date.now() + RT.off - RT.delay;
    // 다른 플레이어: 서버가 준 "지나온 길"을 살짝(약 0.7~1.5초) 늦게 그대로 재생 → 끊김·빨리감기 없이 부드럽게
    // 재생 지연은 천천히 바꿈 (한 번에 확 바꾸면 그 순간 빨리감기/멈춤처럼 보이니까)
    G.netDelay += Math.max(-dt * 40, Math.min(dt * 120, (G.lagHist.length < 4 ? Math.max(1000, G.netTarget) : G.netTarget) - G.netDelay));
    const renderAt = serverNow() - G.netDelay;
    for (const o of G.others.values()) {
      if (o.buf && o.buf.length && !o.seat) {
        const b = o.buf, rAt = o.rt ? rtAt : renderAt;
        let tx, ty;
        if (rAt <= b[0][0]) { tx = b[0][1]; ty = b[0][2]; }
        else if (rAt >= b[b.length - 1][0]) { // 다음 길이 아직 안 왔으면: 걷던 방향으로 잠깐(최대 0.45초) 이어서 걸어감
          const L = b[b.length - 1], P = b.length > 1 ? b[b.length - 2] : L, span = L[0] - P[0];
          const over = Math.min(o.rt ? 250 : 450, rAt - L[0]);
          let vx = span > 0 ? (L[1] - P[1]) / span : 0, vy = span > 0 ? (L[2] - P[2]) / span : 0; const vs = Math.hypot(vx, vy), VMAX = 0.13; // 최대 130px/s
          if (vs > VMAX) { vx *= VMAX / vs; vy *= VMAX / vs; }
          if ((o.rt ? o.rtMov : (o.vx || o.vy)) && span >= 50 && span < 400 && vs > 0.02) { /* 아직 걷는 중일 때만 */ tx = L[1] + vx * over; ty = L[2] + vy * over; if (blockedFeet(tx, ty)) { tx = L[1]; ty = L[2]; } }
          else { tx = L[1]; ty = L[2]; }
        }
        else { let i = 1; while (i < b.length && b[i][0] < rAt) i++; const A = b[i - 1], B = b[i], k = (rAt - A[0]) / Math.max(1, B[0] - A[0]); tx = A[1] + (B[1] - A[1]) * k; ty = A[2] + (B[2] - A[2]) * k; }
        const dx = tx - o.rx, dy = ty - o.ry, d = Math.hypot(dx, dy);
        if (d > 160) { o.rx = tx; o.ry = ty; o.walking = false; continue; } // 순간이동(장면 이동 등)
        // 보정이 필요할 때도 순간이동하지 않고, 걷는 속도의 1.6배 안에서 부드럽게 따라감
        const maxStep = Math.max(150, d * 3) * dt;
        if (d <= maxStep) { o.rx = tx; o.ry = ty; } else { o.rx += (dx / d) * maxStep; o.ry += (dy / d) * maxStep; }
        o.walking = d > 0.15 / Math.max(dt, 0.001) * dt; // 이번 프레임에 움직였으면 걷는 모습
        if (d > 0.05) { o.t = (o.t || 0) + dt; o.dir = Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? "right" : "left") : dy > 0 ? "down" : "up"; o.lastMove = nowMs; }
        if (nowMs - (o.lastMove || 0) > 120) { o.walking = false; if (o.sdir) o.dir = o.sdir; }
        continue;
      }
      // (예전 버전 앱을 쓰는 사람: 이동 기록이 없으면 예전 방식으로 예측)
      let tx = o.x, ty = o.y;
      const moving = !o.seat && (o.vx || o.vy) && !o.pv; // 새 버전 앱은 길 정보로만 움직임 (앞질러 예측하지 않음)
      if (moving) {
        const el = Math.min(800, (o.age || 0) + (nowMs - (o.recv || nowMs))) / 1000;
        const px = o.x + o.vx * el, py = o.y + o.vy * el;
        if (!blockedFeet(px, py)) { tx = px; ty = py; }
      }
      const dx = tx - o.rx, dy = ty - o.ry, d = Math.hypot(dx, dy);
      if (d > 160) { o.rx = tx; o.ry = ty; o.walking = false; continue; }
      const sp = Math.max(moving ? Math.hypot(o.vx, o.vy) : 80, d * 5) * dt;
      if (d <= sp) { o.rx = tx; o.ry = ty; } else { o.rx += (dx / d) * sp; o.ry += (dy / d) * sp; }
      o.walking = moving || d > 1.2;
      if (o.walking) {
        o.t = (o.t || 0) + dt;
        const hx = moving ? o.vx : dx, hy = moving ? o.vy : dy;
        o.dir = Math.abs(hx) > Math.abs(hy) ? (hx > 0 ? "right" : "left") : hy > 0 ? "down" : "up";
      }
    }
    updateNPCs(dt);
    updateDive(dt);
    const w = scene();
    // 밟으면 바로 일어나는 자리 (북·서쪽 준비 중 통로 · 동쪽 초원 길 · 수상한 동굴)
    if (G.mode === "world" && w.triggers && !G.modalOpen) for (const tr of w.triggers) {
      const inside = p.x > tr.x && p.x < tr.x + tr.w && p.y > tr.y && p.y < tr.y + tr.h;
      if (inside && !tr.inside) { tr.inside = true; runTrigger(tr.id); } else if (!inside) tr.inside = false;
    }
    let zone = null;
    if (G.mode === "world") for (const z of w.zones) if (p.x > z.x && p.x < z.x + z.w && p.y > z.y && p.y < z.y + z.h) { zone = z; break; }
    // 벤치 · 테이블 좌석: 가까운 빈자리가 있으면 "앉기"
    if (G.mode === "world" && G.seat && G.seatObj && G.seatObj.watch) zone = G.watchZone || (G.watchZone = { id: "watch", label: t("actWatch") }); // 영화관 좌석: 다시 영상 보기 (움직이면 일어남)
    else if (G.mode === "world" && G.seat && G.seatObj && G.seatObj.fish) zone = G.fish ? null : castZone(); // 🎣 낚시 의자: "낚시줄 던지기" (움직이면 일어남)
    else if (G.mode === "world" && G.seat) zone = G.standZone || (G.standZone = { id: "stand", label: t("actStand") });
    else if (G.mode === "world" && !zone && w.seats) {
      let best = null, bd = 26;
      for (const st of w.seats) { if (st.hostOnly && G.user.role !== "artist") continue; const d = Math.hypot(p.x - st.ax, p.y - st.ay); if (d < bd && !seatTaken(st.id)) { bd = d; best = st; } }
      if (best) zone = best.zone || (best.zone = { id: "seat", seat: best, label: t(best.labelKey || "actSit") });
    }
    if (zone !== G.zone) { G.zone = zone; renderPrompt(); }
    // 카메라
    const vw = VW / S, vh = VH / S;
    let cx = p.x - vw / 2, cy = p.y - 18 - vh / 2;
    // 모바일에서 채팅창이 열려 있으면 캐릭터가 가려지지 않게 카메라를 옮김
    if (IS_TOUCH && G.mode === "world") {
      if (!G.chatRectT || G.t - G.chatRectT > 400) { G.chatRectT = G.t; const c = $("#chat"); G.chatRect = c.classList.contains("collapsed") ? null : c.getBoundingClientRect(); G.hudBottom = $(".hud-top").getBoundingClientRect().bottom; }
      const r = G.chatRect;
      if (r) {
        if (r.width > VW * 0.6) cy = p.y - 18 - (G.hudBottom + r.top) / 2 / S; // 세로 화면: 상단 메뉴와 채팅창 사이 가운데
        else if (r.left > VW * 0.3) cx = p.x - r.left / 2 / S; // 가로 화면: 채팅창 왼쪽 공간 가운데
      }
    }
    if (G.mode === "title") { cx = 640 - vw / 2 + Math.sin(G.t / 9000) * 260; cy = 470 - vh / 2 + Math.cos(G.t / 11000) * 160; }
    if (w.W > vw) cx = Math.max(0, Math.min(w.W - vw, cx)); else cx = (w.W - vw) / 2;
    const chatUp = IS_TOUCH && G.mode === "world" && G.chatRect && G.chatRect.width > VW * 0.6;
    if (chatUp) cy = Math.max(Math.min(0, (w.H - vh) / 2), Math.min(w.H - G.chatRect.top / S + 30, cy)); // 채팅창 위로 맵 끝까지 보이게
    else if (w.H > vh) cy = Math.max(0, Math.min(w.H - vh, cy)); else cy = (w.H - vh) / 2;
    G.cam.x = Math.round(cx * S) / S; G.cam.y = Math.round(cy * S) / S;
  }
  function renderPrompt() {
    const pr = $("#prompt"), z = G.zone;
    if (!z) return pr.classList.add("hidden");
    const act = z.id === "exit" || z.id === "exitShop" || z.id === "exitCinema" || z.id === "watch" || z.id === "seat" || z.id === "stand" || z.id === "surface" || z.id === "cast" ? "" : z.id === "piano" ? t("actPlay") : z.id === "cafe" ? t("cafeOrder") : z.id === "clerk" ? t("actShopTalk") : z.id === "fountain" ? t("actDive") : z.id === "chest" ? t("actOpen") : z.id === "recboard" || z.id === "rankboard" || z.id === "profile" || z.id === "guide" || z.id === "guestbook" || z.id === "art" || z.id === "whaleboard" ? t("actView") : t("actEnter");
    pr.innerHTML = `<kbd>E</kbd>${esc(z.label)} ${esc(act)}`;
    pr.classList.remove("hidden");
  }

  // ---------------- 렌더 ----------------
  const frameOf = (moving, tt) => (moving ? [1, 0, 3, 0][Math.floor(tt * 8) % 4] : 0);
  // 내가 쓴 말은 쓴 그대로, 다른 사람 말은 내 언어로 번역해서 보여 줌
  const msgText = (m) => (m.id && G.user && m.id === G.user.id ? m.text : (m.tr && m.tr[I.lang]) || m.text);
  // 🌐 번역 표시 공통: 내 언어 번역을 보여 주고 "원문 보기" 버튼으로 원문 ↔ 번역 (공지·쪽지·방명록·관리자 화면 등)
  const trPick = (text, tr) => (tr && tr[I.lang]) || text;
  const brHTML = (s) => esc(s).replace(/\n/g, "<br>");
  function trBlock(text, tr, mine) {
    const shown = mine ? text : trPick(text, tr);
    return `<span class="tr-t">${brHTML(shown)}</span>${shown !== text ? ` <button type="button" class="tr-btn" data-o="${esc(text)}" data-t="${esc(shown)}">🌐 ${esc(t("gbOrig"))}</button>` : ""}`;
  }
  document.addEventListener("click", (e) => {
    const b = e.target.closest && e.target.closest(".tr-btn"); if (!b) return;
    e.preventDefault(); e.stopPropagation();
    const on = b.classList.toggle("on"), box = b.previousElementSibling;
    if (box) box.innerHTML = brHTML(on ? b.dataset.o : b.dataset.t);
    b.textContent = "🌐 " + t(on ? "gbTrans" : "gbOrig");
  });
  function render() {
    const w = scene();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.fillStyle = w.id === "plaza" ? "#4a4458" : w.id === "sea" ? "#123a58" : w.id === "shop" ? "#3a2a40" : w.id === "cinema" ? "#140c1c" : w.id === "meadow" ? "#2f6e3a" : w.id === "beach" ? "#155a92" : "#2a2230";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    const k = S * dpr;
    ctx.setTransform(k, 0, 0, k, -G.cam.x * k, -G.cam.y * k);
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(w.ground, 0, 0); World.blitText(ctx, w.ground, 0, 0);

    const vx0 = G.cam.x - 60, vx1 = G.cam.x + VW / S + 60, vy0 = G.cam.y - 20, vy1 = G.cam.y + VH / S + 80;
    const list = [];
    for (const o of w.objects) if (o.always || (o.y > vy0 && o.y < vy1 + 120 && o.x > vx0 - 200 && o.x < vx1)) list.push(o);
    const chars = [];
    if (w.artist) chars.push({ y: w.artist.y, x: w.artist.x, name: L(CFG.artist.name) + " ♪", av: ARTIST_LOOK, dir: "down", frame: 0, crown: true, artist: true, bobby: true, keytar: true });
    if (w.staff) chars.push({ x: w.staff.x, y: w.staff.y, name: t(w.staff.nameKey || "cafeStaff"), av: w.staff.av, dir: "down", frame: 0, npc: w.staff });
    if (G.scene === "plaza") for (const n of G.npcs) chars.push({ x: n.x, y: n.y, name: t("npc")[n.i], av: n.av, dir: n.dir, frame: frameOf(n.moving, n.t), npc: n });
    const seatMap = w.seats ? Object.fromEntries(w.seats.map((st) => [st.id, st])) : {};
    for (const o of G.others.values()) {
      const st = o.seat && seatMap[o.seat];
      if (st) { o.rx = o.x = st.x; o.ry = o.y = st.y; }
      chars.push({ emo: o.emoShow, x: o.rx, y: o.ry, name: o.name, av: o.avatar, dir: st ? st.dir : o.dir || "down", frame: frameOf(o.walking, o.t || 0), crown: o.role === "artist", id: o.id, artist: o.role === "artist", admin: o.role === "admin", sit: !!st, drink: o.drink });
    }
    if (G.mode === "world") chars.push({ swim: G.scene === "sea", emo: G.myEmo, x: G.player.x, y: G.player.y, name: G.user.nickname, av: G.user.avatar, dir: G.player.dir, frame: frameOf(G.player.moving, G.player.t), crown: G.user.role === "artist", me: true, id: G.user.id, artist: G.user.role === "artist", admin: G.user.role === "admin", sit: !!G.seat, drink: G.user.drink });
    for (const c of chars) list.push({ y: c.y, char: c });
    list.sort((a, b) => a.y - b.y);
    for (const o of list) {
      if (o.char) {
        const c = o.char;
        if (c.artist || c.admin) drawAura(c.x, c.y, G.t, c.admin);
        const ofit = c.av && Avatar.OUTFITS[c.av.outfit];
        if (ofit && ofit.auroraGlow) drawAuroraGlow(c.x, c.y, G.t);
        const dk = c.drink && c.drink.until > serverNow_() ? c.drink : null;
        if (dk && c.dir === "up") drawHeldDrink(c, dk); // 뒤돌아 있으면 몸 뒤에
        Avatar.draw(ctx, c.av, c.x, c.y + (c.swim ? Math.round(Math.sin(G.t / 320) * 2) : 0), c.dir, c.bobby ? (Math.floor(G.t / 500) % 2 ? 1 : 0) : c.frame, { keytar: c.keytar, sit: c.sit });
        if (dk && c.dir !== "up") drawHeldDrink(c, dk);
        if (c.artist || c.admin) drawSparkles(c.x, c.y, G.t, c.admin);
      } else o.draw(ctx, G.t);
    }
    if (w.id === "beach") drawFishingLines(w, chars);
    drawFx(Math.min(0.05, (performance.now() - (G.fxT || performance.now())) / 1000)); G.fxT = performance.now();
    if (w.id === "cinema") drawCinemaLight(w);
    if (G.target) { ctx.fillStyle = "rgba(255,127,174,.8)"; const r = 3 + (Math.floor(G.t / 150) % 2); ctx.fillRect(G.target.x - r, G.target.y - 1, r * 2, 2); ctx.fillRect(G.target.x - 1, G.target.y - r, 2, r * 2); }

    // ---- 화면 해상도 오버레이 (이름표, 말풍선, 아이콘) ----
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    // 입체감용 화면 조명: 왼쪽 위는 밝게, 가장자리는 살짝 어둡게
    if (!G.vig || G.vigW !== VW || G.vigH !== VH) {
      G.vigW = VW; G.vigH = VH;
      const v = ctx.createRadialGradient(VW * 0.42, VH * 0.4, Math.min(VW, VH) * 0.25, VW * 0.5, VH * 0.5, Math.max(VW, VH) * 0.75);
      v.addColorStop(0, "rgba(255,245,225,0.06)"); v.addColorStop(0.6, "rgba(0,0,0,0)"); v.addColorStop(1, "rgba(35,15,50,0.30)");
      G.vig = v;
    }
    ctx.fillStyle = G.vig; ctx.fillRect(0, 0, VW, VH);
    drawAmbient(w);
    const sx = (x) => (x - G.cam.x) * S, sy = (y) => (y - G.cam.y) * S;
    for (const ic of w.icons) {
      const X = sx(ic.x), Y = sy(ic.y) - 16 - Math.sin(G.t / 300) * 4;
      ctx.fillStyle = "#3a2530"; ctx.beginPath(); ctx.arc(X, Y, 17, 0, 7); ctx.fill();
      ctx.fillStyle = "#fff8ea"; ctx.beginPath(); ctx.arc(X, Y, 14, 0, 7); ctx.fill();
      ctx.font = `16px sans-serif`; ctx.textAlign = "center"; ctx.textBaseline = "middle"; ctx.fillText(ic.icon, X, Y + 1);
    }
    ctx.textAlign = "center"; ctx.textBaseline = "middle";
    for (const sg of w.signs || []) {
      let txt = t(sg.key);
      if (sg.type) { const ph = G.t % 7000, n = Math.min(txt.length, Math.floor(ph / 110) + 1); txt = [...txt].slice(0, n).join(""); } // 한 글자씩 스르륵
      drawBubble(sx(sg.x), sy(sg.y) - 22 - Math.sin(G.t / 280) * 3, txt, sg.bg || "#fff3a8");
    }
    const now = Date.now();
    for (const c of chars) {
      const X = sx(c.x), Y = sy(c.y - (c.sit ? 33 : 42));
      ctx.font = `${c.me || c.artist ? "bold " : ""}12px ${FONT}`;
      const label = c.artist ? "✦ " + c.name : c.admin ? "★ " + c.name : c.name;
      if (c.admin) ctx.font = `bold 12px ${FONT}`;
      const tw = ctx.measureText(label).width + 10;
      ctx.fillStyle = c.artist ? "rgba(40,130,230,.95)" : c.admin ? "rgba(214,150,10,.95)" : c.me ? "rgba(58,37,48,.85)" : c.npc ? "rgba(79,195,176,.85)" : "rgba(58,37,48,.6)";
      rrect(X - tw / 2, Y - 9, tw, 17, 6); ctx.fill();
      ctx.strokeStyle = c.artist ? "rgba(190,235,255,.9)" : c.admin ? "rgba(255,236,150,.9)" : "rgba(255,255,255,.35)"; ctx.lineWidth = 1; ctx.stroke();
      ctx.fillStyle = "#fff"; ctx.fillText(label, X, Y);
      const b = c.id && G.bubbles.get(c.id);
      if (b && b.until > now) drawBubble(X, Y - 14, msgText(b.m), null, bubbleStyleOf(c));
      if (c.artist && !c.id && G.scene === "plaza" && Math.floor(G.t / 4000) % 3 === 0) drawBubble(X, Y - 14, t("artistHello"));
      if (c.npc && c.npc.say && c.npc.sayUntil > G.t) drawBubble(X, Y - 14, c.npc.say);
      if (c.emo && c.emo.until > now) drawEmote(X, Y, c.emo, now, b && b.until > now);
    }
    drawBanner();
    if (G.mode === "world" && G.t - (G.mmT || 0) > 120) { G.mmT = G.t; drawMinimapFrame(); } // 지도는 초당 8번만 (폰 부담 줄이기)
  }
  // 🎬 영화관 조명: 실내는 어둡게, 스크린에서 영상 빛이 깜빡이며 객석으로 퍼짐
  function drawCinemaLight(w) {
    const sc = w.screen, tt = G.t;
    const hue = (tt / 45) % 360;
    const flick = 0.72 + 0.18 * Math.sin(tt / 95) * Math.sin(tt / 241) + 0.1 * Math.sin(tt / 37);
    ctx.save();
    // 1) 전체를 어둡게
    ctx.fillStyle = "rgba(3,1,10,0.62)"; ctx.fillRect(-20, -20, w.W + 40, w.H + 40);
    // 2) 스크린은 다시 밝게 + 영상처럼 색이 바뀌는 빛
    ctx.drawImage(w.ground, sc.x, sc.y, sc.w, sc.h, sc.x, sc.y, sc.w, sc.h);
    World.blitText(ctx, w.ground, 0, 0);
    ctx.globalCompositeOperation = "lighter";
    ctx.fillStyle = `hsla(${hue},75%,62%,${0.22 * flick})`; ctx.fillRect(sc.x, sc.y, sc.w, sc.h);
    for (let k = 0; k < 4; k++) { // 화면 속 움직이는 장면 조각
      const bw = 40 + k * 14, bx = sc.x + ((tt / (28 + k * 9) + k * 77) % (sc.w + bw)) - bw;
      ctx.fillStyle = `hsla(${(hue + k * 70) % 360},85%,60%,${0.16 * flick})`;
      ctx.fillRect(Math.max(sc.x, bx), sc.y + 6 + k * 13, Math.min(bw, sc.x + sc.w - Math.max(sc.x, bx)), 10);
    }
    // 3) 스크린 주변 빛무리
    const halo = ctx.createRadialGradient(sc.x + sc.w / 2, sc.y + sc.h / 2, sc.h * 0.4, sc.x + sc.w / 2, sc.y + sc.h / 2, sc.w * 0.75);
    halo.addColorStop(0, `hsla(${hue},70%,70%,${0.22 * flick})`); halo.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = halo; ctx.fillRect(sc.x - sc.w * 0.4, sc.y - 20, sc.w * 1.8, sc.h + sc.w * 0.8);
    // 4) 객석으로 퍼지는 빛줄기
    const cone = ctx.createLinearGradient(0, sc.y + sc.h, 0, w.H);
    cone.addColorStop(0, `hsla(${hue},65%,75%,${0.2 * flick})`); cone.addColorStop(0.55, `hsla(${hue},60%,70%,${0.06 * flick})`); cone.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = cone; ctx.beginPath(); ctx.moveTo(sc.x + 6, sc.y + sc.h); ctx.lineTo(sc.x + sc.w - 6, sc.y + sc.h); ctx.lineTo(w.W + 30, w.H); ctx.lineTo(-30, w.H); ctx.closePath(); ctx.fill();
    // 5) 통로 바닥 조명 · 비상구 표시
    for (const [lx, ly] of w.aisleLights || []) { const gl = ctx.createRadialGradient(lx, ly, 0, lx, ly, 7); gl.addColorStop(0, "rgba(255,200,110,.55)"); gl.addColorStop(1, "rgba(255,200,110,0)"); ctx.fillStyle = gl; ctx.fillRect(lx - 7, ly - 7, 14, 14); ctx.fillStyle = "rgba(255,230,160,.9)"; ctx.fillRect(lx - 1, ly - 1, 2, 2); }
    const ex = w.exitSign; if (ex) { const gl = ctx.createRadialGradient(ex.x + ex.w / 2, ex.y + ex.h / 2, 2, ex.x + ex.w / 2, ex.y + ex.h / 2, 26); gl.addColorStop(0, "rgba(60,230,110,.35)"); gl.addColorStop(1, "rgba(60,230,110,0)"); ctx.fillStyle = gl; ctx.fillRect(ex.x - 12, ex.y - 18, ex.w + 24, ex.h + 36); }
    ctx.restore();
  }
  // 🌌 오로라 셀레스티얼 가운(10만 코인)의 오로라 불빛 — 몸 뒤로 넘실거리는 빛의 띠 + 떠다니는 빛가루
  const AURORA_COLS = ["126,240,216", "124,200,240", "154,140,240", "200,140,240", "255,159,208"];
  function drawAuroraGlow(x, y, tt) {
    ctx.save();
    // 은은한 빛무리
    const halo = ctx.createRadialGradient(x, y - 22, 4, x, y - 22, 30);
    halo.addColorStop(0, `rgba(${AURORA_COLS[Math.floor(tt / 1600) % 5]},0.35)`); halo.addColorStop(1, "rgba(160,200,255,0)");
    ctx.fillStyle = halo; ctx.beginPath(); ctx.ellipse(x, y - 22, 30, 34, 0, 0, 7); ctx.fill();
    for (let b = 0; b < 3; b++) {
      const col = AURORA_COLS[(b + Math.floor(tt / 1600)) % AURORA_COLS.length], col2 = AURORA_COLS[(b + 2 + Math.floor(tt / 1600)) % AURORA_COLS.length];
      const g = ctx.createLinearGradient(x - 22, 0, x + 22, 0);
      g.addColorStop(0, `rgba(${col},0)`); g.addColorStop(0.5, `rgba(${col2},${0.42 + 0.15 * Math.sin(tt / 500 + b)})`); g.addColorStop(1, `rgba(${col},0)`);
      ctx.fillStyle = g; ctx.beginPath();
      const y0 = y - 52 + b * 9;
      ctx.moveTo(x - 24, y0 + Math.sin(tt / 420 + b) * 3);
      for (let k = 1; k <= 8; k++) { const xx = x - 24 + k * 6; ctx.lineTo(xx, y0 + Math.sin(tt / 420 + b + k * 0.8) * 4); }
      for (let k = 8; k >= 0; k--) { const xx = x - 24 + k * 6; ctx.lineTo(xx, y0 + 14 + Math.sin(tt / 380 + b * 1.7 + k * 0.7) * 4); }
      ctx.closePath(); ctx.fill();
    }
    for (let k = 0; k < 7; k++) {
      const a = tt / 900 + k * 0.9, r = 15 + (k % 3) * 3, px = x + Math.cos(a) * r, py = y - 22 + Math.sin(a * 1.3) * 18;
      ctx.fillStyle = `rgba(${AURORA_COLS[k % AURORA_COLS.length]},${0.6 + 0.35 * Math.sin(tt / 200 + k)})`; ctx.fillRect(px - 1, py - 1, 2, 2); ctx.fillStyle = "rgba(255,255,255,.8)"; ctx.fillRect(px - 0.5, py - 0.5, 1, 1);
    }
    ctx.restore();
  }
  // 둥근 사각형 경로
  function rrect(x, y, w, h, r) { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, r); else ctx.rect(x, y, w, h); }
  // ✨ 분위기 효과: 광장은 꽃잎·반짝이가 바람에 날리고, 팬 라운지는 음표가 둥실둥실
  G.amb = [];
  let ambT = performance.now();
  function drawAmbient(w) {
    const now = performance.now(), dt = Math.min(0.05, (now - ambT) / 1000); ambT = now;
    if (w.id === "sea" || w.id === "cinema" || G.mode !== "world") return;
    const outdoor = w.id === "plaza" || w.id === "meadow" || w.id === "beach";
    const want = outdoor ? 26 : 10;
    while (G.amb.length < want) G.amb.push({ x: Math.random() * VW, y: Math.random() * VH, vx: 0, vy: 0, ph: Math.random() * 6.3, k: G.amb.length % 4, s: 0.6 + Math.random() * 0.8 });
    if (G.amb.length > want) G.amb.length = want;
    ctx.save();
    for (const a of G.amb) {
      a.ph += dt;
      if (outdoor) { a.x += (14 + Math.sin(a.ph * 0.7) * 10) * dt * a.s; a.y += (16 + Math.cos(a.ph) * 6) * dt * a.s; }
      else { a.x += Math.sin(a.ph * 0.8) * 8 * dt; a.y -= 12 * dt * a.s; }
      if (a.x > VW + 10) a.x = -10; if (a.y > VH + 10) a.y = -10; if (a.y < -10) a.y = VH + 10;
      const tw = 0.5 + 0.5 * Math.sin(a.ph * 3);
      if (outdoor) {
        if (a.k === 3) { ctx.globalAlpha = 0.35 + tw * 0.5; ctx.fillStyle = "#fff8d8"; const r = 1.5 * a.s * S / 2; ctx.fillRect(a.x - r * 2, a.y - r / 2, r * 4, r); ctx.fillRect(a.x - r / 2, a.y - r * 2, r, r * 4); }
        else { ctx.globalAlpha = 0.55; ctx.fillStyle = a.k === 0 ? "#ffd1e1" : a.k === 1 ? "#ffb8d0" : "#ffffff"; ctx.save(); ctx.translate(a.x, a.y); ctx.rotate(a.ph * 1.3); const r = 2.2 * a.s * S / 2; ctx.fillRect(-r, -r / 2, r * 2, r); ctx.restore(); }
      } else { ctx.globalAlpha = 0.25 + tw * 0.3; ctx.fillStyle = a.k % 2 ? "#ffd1e6" : "#e2d1ff"; ctx.font = `${Math.round(10 * a.s * S / 2 + 6)}px sans-serif`; ctx.textAlign = "center"; ctx.fillText(a.k % 2 ? "♪" : "♫", a.x, a.y); }
    }
    ctx.restore();
  }
  // 아티스트(조젤리) 전용: 영롱한 푸른 빛 오라 + 반짝이
  // 관리자: 노란(황금빛) 오라
  const AURA = {
    blue: ["rgba(120,215,255,.75)", "rgba(60,150,255,.38)", "rgba(40,110,255,0)", "140,225,255", "80,190,255"],
    gold: ["rgba(255,236,120,.8)", "rgba(255,196,40,.42)", "rgba(255,170,0,0)", "255,230,120", "255,200,40"],
  };
  function drawAura(x, y, tt, gold) {
    const A = gold ? AURA.gold : AURA.blue;
    const pulse = 0.75 + Math.sin(tt / 380) * 0.25;
    ctx.save();
    // 푸른 후광 (밝은 바닥에서도 잘 보이도록 진한 파랑 → 투명)
    const R = 34 * pulse + 8;
    const g = ctx.createRadialGradient(x, y - 18, 3, x, y - 18, R);
    g.addColorStop(0, A[0]);
    g.addColorStop(0.5, A[1]);
    g.addColorStop(1, A[2]);
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.ellipse(x, y - 18, R * 0.8, R * 1.05, 0, 0, Math.PI * 2); ctx.fill();
    // 위로 올라가는 빛기둥
    const g2 = ctx.createLinearGradient(0, y - 66, 0, y);
    g2.addColorStop(0, `rgba(${A[3]},0)`);
    g2.addColorStop(1, `rgba(${A[3]},${0.35 * pulse})`);
    ctx.fillStyle = g2; ctx.fillRect(x - 8, y - 66, 16, 66);
    // 발밑 빛 고리
    ctx.fillStyle = `rgba(${A[4]},${0.55 + 0.35 * pulse})`;
    for (let i = -11; i <= 11; i++) { const h = Math.round(Math.sqrt(121 - i * i) / 3); ctx.fillRect(x + i, y - h + 1, 1, 1); ctx.fillRect(x + i, y + h + 1, 1, 1); }
    ctx.restore();
  }
  function drawSparkles(x, y, tt, gold) {
    ctx.save();
    for (let i = 0; i < 6; i++) {
      const a = tt / 700 + (i * Math.PI) / 3;
      const r = 15 + Math.sin(tt / 300 + i) * 2;
      const sx = Math.round(x + Math.cos(a) * r), sy = Math.round(y - 18 + Math.sin(a) * r * 1.1 - ((tt / 25 + i * 9) % 18) * 0.3);
      const on = (Math.floor(tt / 160) + i) % 3;
      ctx.fillStyle = on === 0 ? "#ffffff" : gold ? (on === 1 ? "#fff3a8" : "#ffc83d") : on === 1 ? "#9fe8ff" : "#5fb8ff";
      ctx.fillRect(sx, sy, 1, 1);
      if (on === 0) { ctx.fillRect(sx - 1, sy, 3, 1); ctx.fillRect(sx, sy - 1, 1, 3); }
    }
    ctx.restore();
  }
  const wrapCache = new Map();
  // ---------------- 💬 말풍선 디자인 (기본 · 젤리젤리샵 7종 · 호스트 · 관리자) ----------------
  // 0 기본 · 1 노랑 · 2 파랑 · 3 초록 (700) · 4 물방울 (1000) · 5 무지개 (1500) · 6 별빛 (2000) · 7 골드 크라운 (3000)
  const BUBBLE_STYLES = {
    0: { border: "#3a2530", bg: "#fff", w: 2 },
    1: { border: "#f2c14e", bg: "#fffbe6", w: 3 },
    2: { border: "#4a90e2", bg: "#eef6ff", w: 3 },
    3: { border: "#3fae5a", bg: "#effbef", w: 3 },
    4: { border: "#ff8fbf", bg: "#fff0f7", w: 3, dots: "#ffd1e6" },
    5: { border: "rainbow", bg: "#ffffff", w: 4 },
    6: { border: "#9fe8ff", bg: "#2b2f6b", w: 3, fg: "#ffffff", stars: true },
    7: { border: "gold", bg: "#fffaf0", w: 4, crown: true, glitter: true },
    host: { border: "#ff6fa8", bg: "#fff0f6", w: 4, hearts: true },
    admin: { border: "#3a2530", bg: "#ffffff", w: 3, bowtie: true },
  };
  function bubbleStyleOf(c) {
    if (!c) return 0;
    if (c.artist && c.id) return "host";
    if (c.admin) return "admin";
    return (c.av && c.av.bubble) | 0;
  }
  function drawBubbleOn(g, X, Y, text, styleKey, tt, fixedBg) {
    const st = fixedBg ? { border: "#3a2530", bg: fixedBg, w: 2 } : BUBBLE_STYLES[styleKey] || BUBBLE_STYLES[0];
    g.save(); g.font = `12px ${FONT}`; g.textAlign = "center"; g.textBaseline = "middle";
    let lines = wrapCache.get(text);
    if (!lines) { lines = wrapPx(text, 150, g).slice(0, 3); if (wrapCache.size > 200) wrapCache.clear(); wrapCache.set(text, lines); }
    const bw = st.w, w = Math.max(...lines.map((l) => g.measureText(l).width)) + 16 + (st.hearts || st.crown ? 6 : 0), h = lines.length * 16 + 8;
    const x = Math.round(X - w / 2), y = Math.round(Y - h);
    // 테두리 색
    let bc = st.border;
    if (bc === "rainbow") { const gr = g.createLinearGradient(x, 0, x + w, 0); ["#ff6f7d", "#ffb347", "#f7e27a", "#7fe0a0", "#6fb8ff", "#a77ce0"].forEach((c2, i) => gr.addColorStop(i / 5, c2)); bc = gr; }
    if (bc === "gold") { const gr = g.createLinearGradient(x, y, x + w, y + h); const sh = ((tt || 0) / 1200) % 1; gr.addColorStop(0, "#c9982c"); gr.addColorStop(Math.max(0, sh - 0.1), "#f2c14e"); gr.addColorStop(sh, "#fff3a8"); gr.addColorStop(Math.min(1, sh + 0.1), "#f2c14e"); gr.addColorStop(1, "#c9982c"); bc = gr; }
    g.fillStyle = "#3a2530"; g.fillRect(x - bw - 1, y - bw - 1, w + bw * 2 + 2, h + bw * 2 + 2); // 바깥 외곽선
    g.fillStyle = bc; g.fillRect(x - bw, y - bw, w + bw * 2, h + bw * 2);
    g.fillRect(X - 5, Y, 10, 5 + bw); // 꼬리
    g.fillStyle = st.bg; g.fillRect(x, y, w, h); g.fillRect(X - 3, Y, 6, 3 + bw - 1);
    if (st.dots) { g.fillStyle = st.dots; for (let yy = y + 3; yy < y + h - 2; yy += 7) for (let xx = x + 3 + ((yy - y) % 14 ? 3 : 0); xx < x + w - 2; xx += 7) g.fillRect(xx, yy, 2, 2); }
    if (st.stars) { const tw = Math.floor((tt || 0) / 250); for (let k = 0; k < 7; k++) { const sx = x + ((k * 37 + 11) % Math.max(10, w - 6)) + 3, sy = y + ((k * 23 + 5) % Math.max(6, h - 4)) + 2; g.fillStyle = (k + tw) % 3 ? "#9fe8ff" : "#fff3a8"; g.fillRect(sx, sy, 1, 1); }
      for (let k = 0; k < 4; k++) { const on = (k + tw) % 2; if (!on) continue; const sx = [x - bw - 3, x + w + bw + 1, x + w * 0.3, x + w * 0.75][k], sy = [y + 3, y + h - 4, y - bw - 4, y + h + bw + 1][k]; g.fillStyle = "#fff3a8"; g.fillRect(sx - 1, sy, 3, 1); g.fillRect(sx, sy - 1, 1, 3); } }
    if (st.hearts) { // 테두리에 박힌 하트
      const heart = (hx, hy) => { g.fillStyle = "#ff2f7f"; g.fillRect(hx - 2, hy - 1, 2, 2); g.fillRect(hx + 1, hy - 1, 2, 2); g.fillRect(hx - 2, hy, 5, 2); g.fillRect(hx - 1, hy + 2, 3, 1); g.fillRect(hx, hy + 3, 1, 1); g.fillStyle = "#ffd1e6"; g.fillRect(hx - 1, hy - 1, 1, 1); };
      for (let hx = x + 4; hx < x + w - 2; hx += 14) { heart(hx, y - bw + 1); heart(hx + 7, y + h + 1); }
      for (let hy = y + 6; hy < y + h - 2; hy += 12) { heart(x - bw + 2, hy); heart(x + w + 1, hy); }
    }
    if (st.crown) { // 골드 크라운 + 반짝이
      const cx = x - 2, cy = y - bw - 7;
      g.fillStyle = "#3a2530"; g.fillRect(cx - 1, cy - 1, 16, 9);
      g.fillStyle = "#f2c14e"; g.fillRect(cx, cy + 3, 14, 4); g.fillRect(cx, cy, 3, 3); g.fillRect(cx + 5, cy - 1, 4, 4); g.fillRect(cx + 11, cy, 3, 3);
      g.fillStyle = "#d8434e"; g.fillRect(cx + 6, cy + 4, 2, 2); g.fillStyle = "#6fb8ff"; g.fillRect(cx + 2, cy + 4, 2, 2); g.fillRect(cx + 10, cy + 4, 2, 2);
      const tw = (tt || 0) / 300;
      for (let k = 0; k < 3; k++) { const a = Math.sin(tw + k * 2); if (a < 0.3) continue; const sx = [x + w + bw + 2, x + w * 0.5, x - bw - 4][k], sy = [y - 2, y + h + bw + 3, y + h - 2][k]; g.fillStyle = "#fff3a8"; g.fillRect(sx - 2, sy, 5, 1); g.fillRect(sx, sy - 2, 1, 5); }
    }
    if (st.bowtie) { // 왼쪽 위 빨간 나비넥타이
      const bx = x + 2, by = y - bw - 3;
      g.fillStyle = "#3a2530"; g.fillRect(bx - 1, by - 1, 15, 9);
      g.fillStyle = "#d8434e"; g.fillRect(bx, by, 5, 7); g.fillRect(bx + 8, by, 5, 7); g.fillRect(bx + 5, by + 2, 3, 3);
      g.fillStyle = "#a82a36"; g.fillRect(bx + 5, by + 2, 3, 3); g.fillStyle = "#ff8f9f"; g.fillRect(bx + 1, by + 1, 2, 1); g.fillRect(bx + 9, by + 1, 2, 1);
    }
    g.fillStyle = st.fg || "#3a2530";
    lines.forEach((l, i) => g.fillText(l, X, y + 12 + i * 16));
    g.restore();
  }
  function drawBubble(X, Y, text, bg, style) { drawBubbleOn(ctx, X, Y, text, style ?? 0, G.t, bg); }
  // 말풍선 줄바꿈 (영어는 단어 단위, 한/일은 글자 단위)
  function wrapPx(text, maxW, g = ctx) {
    const out = []; let line = "";
    const tokens = String(text).match(/\S+\s*|\s+/g) || [];
    const push = (tok) => {
      if (g.measureText(line + tok).width <= maxW) { line += tok; return; }
      if (line) { out.push(line.trim()); line = ""; }
      if (g.measureText(tok).width <= maxW) { line = tok; return; }
      for (const ch of tok) { if (g.measureText(line + ch).width > maxW) { out.push(line); line = ""; } line += ch; }
    };
    tokens.forEach(push);
    if (line.trim()) out.push(line.trim());
    if (out.length > 3) out[2] = out[2].slice(0, -1) + "…";
    return out.length ? out : [""];
  }

  // ---------------- 미니맵 ----------------
  let mmBase = null;
  function buildMinimap() {
    const w = scene();
    const mm = $("#minimap");
    const sc = w.id === "plaza" || w.id === "meadow" || w.id === "beach" ? 0.25 : w.id === "lounge" ? 0.3 : 0.4;
    mm.width = Math.round(w.W * sc); mm.height = Math.round(w.H * sc);
    const c = document.createElement("canvas");
    c.width = w.W; c.height = w.H;
    const cx = c.getContext("2d"); cx.imageSmoothingEnabled = false;
    cx.drawImage(w.ground, 0, 0);
    [...w.objects].sort((a, b) => a.y - b.y).forEach((o) => o.draw(cx, 0));
    mmBase = { c, sc };
  }
  function drawMinimapFrame() {
    const mm = $("#minimap"), m = mm.getContext("2d"), w = scene();
    if (!mmBase) return;
    m.imageSmoothingEnabled = true;
    m.drawImage(mmBase.c, 0, 0, mm.width, mm.height);
    const sc = mmBase.sc;
    for (const ic of w.icons) { m.font = "13px sans-serif"; m.textAlign = "center"; m.textBaseline = "middle"; m.fillStyle = "#fff8ea"; m.beginPath(); m.arc(ic.x * sc, ic.y * sc + 10, 9, 0, 7); m.fill(); m.fillText(ic.icon, ic.x * sc, ic.y * sc + 11); }
    const dot = (x, y, col, r) => { m.fillStyle = "#3a2530"; m.beginPath(); m.arc(x * sc, y * sc, r + 1.5, 0, 7); m.fill(); m.fillStyle = col; m.beginPath(); m.arc(x * sc, y * sc, r, 0, 7); m.fill(); };
    for (const o of G.others.values()) dot(o.rx, o.ry, "#9d7cf0", 2.5);
    if (w.artist) dot(w.artist.x, w.artist.y, "#ffd34d", 3);
    if (Math.floor(G.t / 400) % 2 === 0 || G.player.moving) dot(G.player.x, G.player.y, "#e0304e", 3.5);
    m.strokeStyle = "rgba(255,255,255,.8)"; m.lineWidth = 1.5;
    m.strokeRect(G.cam.x * sc, G.cam.y * sc, (VW / S) * sc, (VH / S) * sc);
  }
  $("#minimap-wrap").addEventListener("click", () => $("#minimap-wrap").classList.toggle("big"));

  // ---------------- 상호작용 ----------------
  function interact() {
    if (Fishing.active) return Fishing.tap(); // 🎣 낚시 중: 행동 버튼 = 낚시 버튼
    if (G.mode !== "world" || G.modalOpen || G.frozen || G.quizOpen) return;
    if (G.zone) runZone(G.zone.id);
  }
  function seatTaken(id) { for (const o of G.others.values()) if (o.seat === id) return true; return false; }
  function sitDown(st) {
    if (seatTaken(st.id)) return;
    G.seat = st.id; G.seatObj = st; G.target = null; G.pendingZone = null;
    G.player.x = st.x; G.player.y = st.y; G.player.dir = st.dir; G.player.moving = false;
    G.zone = null; kickSync();
    if (st.watch) setTimeout(() => { if (G.seat === st.id && !G.modalOpen) openCinema(); }, 350); // 🎬 영화관 좌석에 앉으면 영상 팝업
    if (st.id === "throne" && G.user.role === "artist") {
      celebrate(st);
    }
  }
  // ---------------- 👑 호스트 등장: 빵빠레 + 폭죽 + 배너 ----------------
  G.fx = [];
  function celebrate(st) {
    const w = scene(); if (!w || w.id !== "plaza") return;
    try { Piano.fanfare(); } catch {}
    const cx = st.x, cy = st.y - 20;
    const cols = ["#ff5f9f", "#ffd34d", "#7fe3ff", "#a77ce0", "#8fe07a", "#ffffff", "#ff9f43"];
    const burst = (bx, by, n, col2) => { for (let i = 0; i < n; i++) { const a = (i / n) * Math.PI * 2 + Math.random() * 0.2, sp = 50 + Math.random() * 70; G.fx.push({ x: bx, y: by, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, life: 1.2 + Math.random() * 0.6, max: 1.8, col: i % 3 ? col2 : "#ffffff", s: Math.random() < 0.3 ? 3.5 : 2.5, g: 40 }); } };
    for (let k = 0; k < 9; k++) {
      setTimeout(() => {
        const bx = cx + (Math.random() - 0.5) * 150, by = cy - 50 - Math.random() * 70;
        // 올라가는 불꽃 꼬리
        for (let j = 0; j < 8; j++) G.fx.push({ x: bx + (Math.random() - 0.5) * 2, y: by + 60 + j * 5, vx: 0, vy: -140, life: 0.35 - j * 0.03, max: 0.4, col: "#fff3a8", s: 2.5, g: 0 });
        setTimeout(() => burst(bx, by, 46, cols[k % cols.length]), 380);
      }, k * 450 + (k === 0 ? 0 : Math.random() * 200));
    }
    // 의자 주변 반짝이 분수
    for (let k = 0; k < 40; k++) setTimeout(() => { for (const sx of [-26, 26]) G.fx.push({ x: cx + sx, y: cy + 16, vx: sx * 0.6 + (Math.random() - 0.5) * 30, vy: -90 - Math.random() * 60, life: 1, max: 1, col: cols[(Math.random() * cols.length) | 0], s: 2.5, g: 140 }); }, k * 90);
  }
  function drawFx(dt) {
    if (!G.fx.length) return;
    for (const f of G.fx) { f.x += f.vx * dt; f.y += f.vy * dt; f.vy += f.g * dt; f.vx *= 0.985; f.life -= dt; }
    G.fx = G.fx.filter((f) => f.life > 0);
    ctx.save(); ctx.globalCompositeOperation = "lighter";
    for (const f of G.fx) { ctx.globalAlpha = Math.max(0, Math.min(1, f.life / (f.max * 0.6))); ctx.fillStyle = f.col; ctx.fillRect(f.x - f.s / 2, f.y - f.s / 2, f.s, f.s); }
    ctx.restore();
  }
  function drawBanner() {
    const b = G.banner; if (!b) return;
    const left = b.until - performance.now(); if (left <= 0) { G.banner = null; return; }
    const a = Math.min(1, left / 600, (4500 - left) / 300);
    ctx.save(); ctx.globalAlpha = a;
    const size = Math.min(44, VW / 12);
    ctx.font = `bold ${size}px ${FONT}`; ctx.textAlign = "center"; ctx.textBaseline = "middle";
    const Y = VH * 0.28 + Math.sin(performance.now() / 200) * 3, tw = ctx.measureText(b.text).width + 50;
    const g = ctx.createLinearGradient(VW / 2 - tw / 2, 0, VW / 2 + tw / 2, 0);
    g.addColorStop(0, "#ff7fae"); g.addColorStop(0.5, "#a77ce0"); g.addColorStop(1, "#5fb8ff");
    ctx.fillStyle = "#3a2530"; ctx.fillRect(VW / 2 - tw / 2 - 4, Y - size * 0.8 - 4, tw + 8, size * 1.6 + 8);
    ctx.fillStyle = g; ctx.fillRect(VW / 2 - tw / 2, Y - size * 0.8, tw, size * 1.6);
    ctx.fillStyle = "#3a2530"; ctx.fillText(b.text, VW / 2 + 3, Y + 3);
    ctx.fillStyle = "#fff"; ctx.fillText(b.text, VW / 2, Y);
    ctx.restore();
  }
  function standUp() {
    const st = G.seatObj; G.seat = null; G.seatObj = null;
    if (st) { G.player.x = st.ax; G.player.y = st.ay; }
    G.zone = null; kickSync();
  }
  async function runTrigger(id) {
    if (id === "soonN" || id === "soonW") { G.keys.clear(); G.target = null; return openPushSetup({ icon: "🚧", title: t("soonTitle"), intro: t("soonMsg") }); }
    if (id === "toBeach") { await fade(true); setScene("beach", { x: G.worlds.beach.W - 44, y: 450, dir: "left" }); await fade(false); toast(t("enteredBeach"), 4500); return; } // 🏖️ 광장 서쪽 → 젤리 해변 ("오늘은 물고기가 많아 보입니다")
    if (id === "toPlazaW") { await fade(true); setScene("plaza", { x: 40, y: 500, dir: "right" }); await fade(false); return; }
    if (id === "cave") { G.keys.clear(); G.target = null; G.player.y += 6; try { SFX.beat(); setTimeout(() => SFX.beat(), 350); } catch {} return openPushSetup({ icon: "👁️", title: t("caveTitle"), intro: t("caveMsg"), spooky: true }); }
    if (id === "toMeadow") { await fade(true); setScene("meadow", { x: 34, y: 450, dir: "right" }); await fade(false); toast(t("enteredMeadow")); return; }
    if (id === "toPlaza") { await fade(true); setScene("plaza", { x: 1236, y: 500, dir: "left" }); await fade(false); return; }
  }
  async function runZone(id) {
    if (id === "cave") return runTrigger("cave");
    if (id === "seat" && G.zone && G.zone.seat) return sitDown(G.zone.seat);
    if (id === "stand") return standUp();
    if (id === "cast") return startFishing();
    if (id.startsWith("sit:")) { // 의자를 눌러서 왔으면 바로 앉기
      const st = (scene().seats || []).find((x) => x.id === id.slice(4));
      if (!st) return;
      if (seatTaken(st.id)) return toast(t("seatTaken"));
      return sitDown(st);
    }
    if (id === "whaleboard") return openWhaleHall();
    if (id === "guestbook") return openGuestbook();
    if (id === "cafe") return openCafe();
    if (id === "gallery") return openGallery();
    if (id === "albums") return openAlbums();
    if (id === "cinema") { await fade(true); setScene("cinema"); await fade(false); showCinemaGuide(); return; }
    if (id === "watch") return openCinema();
    if (id === "exitCinema") { const b = G.worlds.plaza.buildings.find((x) => x.id === "cinema"); await fade(true); setScene("plaza", { x: b.door.x, y: b.door.y + 22, dir: "down" }); await fade(false); return; }
    if (id === "profile") return openProfile();
    if (id === "guide") return openGuide();
    if (id === "shop") { await fade(true); setScene("shop"); await fade(false); toast(t("enteredShop")); return; }
    if (id === "clerk") return openShop();
    if (id === "exitShop") { const b = G.worlds.plaza.buildings.find((x) => x.id === "shop"); await fade(true); setScene("plaza", { x: b.door.x, y: b.door.y + 22, dir: "down" }); await fade(false); return; }
    if (id === "piano") return openPiano(G.scene === "plaza");
    if (id === "recboard") return openRecBoard();
    if (id === "rankboard") return openRankBoard();
    if (id === "game") return openGame();
    if (id === "art") return openArt();
    if (id === "fountain") return diveIn();
    if (id === "chest") return openChest();
    if (id === "surface") return surface(false);
    if (id === "lounge") { await fade(true); setScene("lounge"); await fade(false); toast(t("enteredLounge")); return; }
    if (id === "exit") { const b = G.worlds.plaza.buildings.find((x) => x.id === "lounge"); await fade(true); setScene("plaza", { x: b.door.x, y: b.door.y + 22, dir: "down" }); await fade(false); }
  }

  // ---------------- 🎣 젤리 해변 낚시 ----------------
  // 의자에 앉기 → "낚시줄 던지기" → 찌가 둥실 → 입질(버튼이 빨개짐) → 바늘이 노란 칸에 올 때 누르기(Great!) → 어항으로
  G.fish = null; // { stage: "cast" | "wait" | "fight", at, seat }
  const FISH_DAY = 15; // 서버 FISH_DAY 와 같게 (하루 미끼)
  const fishName = (sp) => (Fishing.BY[sp] ? L(Fishing.BY[sp].name) : sp);
  // 한국어 조사: 받침이 있으면 "을", 없으면 "를" (한글이 아니면 "을(를)")
  const eul = (w) => { const c = String(w).trim().slice(-1).charCodeAt(0); return c >= 0xac00 && c <= 0xd7a3 ? ((c - 0xac00) % 28 ? "을" : "를") : "을(를)"; };
  const fishState = () => (G.fish ? (G.fish.stage === "fight" ? 2 : 1) : 0); // 다른 사람에게 보이는 모습
  const baitText = () => t("fishBait", { n: (G.user.bait | 0) >= 99 ? "∞" : G.user.bait | 0, max: FISH_DAY });
  function castZone() {
    const label = `${t("fishCast")} · 🪱 ${baitText()}`;
    if (!G.castZone || G.castZone.label !== label) G.castZone = { id: "cast", label };
    return G.castZone;
  }
  async function startFishing() {
    const st = G.seatObj;
    if (G.fish || !st || !st.fish) return;
    if ((G.user.bait | 0) <= 0 && G.baitDay === kstDay()) return toast(t("e_fishNoBait")); // (자정이 지나면 서버에 다시 물어봄)
    G.fish = { stage: "cast", at: performance.now(), seat: st.id };
    G.frozen = true; G.keys.clear(); G.target = null; G.zone = null; renderPrompt();
    try { SFX.cast(); } catch {}
    kickSync();
    let r;
    try { r = await API.fishCast(); } catch (e) { toast(e.message); if (e.code === "fishNoBait") { G.user.bait = 0; G.baitDay = kstDay(); } return endFishing(); }
    setUser(r.user); G.baitDay = kstDay();
    if (!G.fish || G.seat !== st.id || G.modalOpen) { API.fishEnd(r.cast.id, false).catch(() => {}); if (G.fish) endFishing(); return; } // 그새 그만뒀으면
    setTimeout(() => { try { SFX.plop(); } catch {} }, 420);
    G.fish.stage = "wait"; kickSync();
    const res = await Fishing.start(r.cast, { t, title: "🎣 " + t("fishTitle"), sfx: (k) => { try { SFX[k] && SFX[k](); } catch {} }, onBite: () => { if (G.fish) { G.fish.stage = "fight"; kickSync(); } } });
    if (res.cancel) { endFishing(); API.fishEnd(r.cast.id, false).catch(() => {}); return; }
    let out;
    try { out = await API.fishEnd(r.cast.id, !!res.ok); } catch (e) { toast(e.message); return endFishing(); }
    setUser(out.user);
    endFishing();
    showFishResult(out);
  }
  function endFishing(silent) {
    if (Fishing.active) Fishing.cancel();
    const was = !!G.fish; G.fish = null; G.frozen = false; G.zone = null;
    if (was && !silent) kickSync();
  }
  // 낚싯대 · 낚싯줄 · 찌 (나와 다른 사람 모두) — 월드 좌표로 그림
  function drawFishingLines(w) {
    const items = [];
    const seatOf = (id) => w.seats.find((x) => x.id === id);
    for (const o of G.others.values()) if (o.seat && o.fs) { const st = seatOf(o.seat); if (st && st.fish) items.push({ st, fs: o.fs }); }
    if (G.fish && G.seatObj && G.seatObj.fish) items.push({ st: G.seatObj, fs: fishState(), castT: G.fish.stage === "cast" ? G.fish.at : 0 });
    for (const { st, fs, castT } of items) {
      const hx = st.x - 7, hy = st.y - 12, tipX = hx - 20, tipY = hy - 24; // 손 → 낚싯대 끝 (바다 쪽)
      const k = castT ? Math.min(1, (performance.now() - castT) / 450) : 1;
      const bx = st.bob.x, by = st.bob.y, px = tipX + (bx - tipX) * k, py = tipY + (by - tipY) * k - Math.sin(k * Math.PI) * 26;
      const bite = fs === 2, dip = bite ? (Math.sin(G.t / 60) > 0.1 ? 3 : 0) : Math.sin(G.t / 420) * 1.2;
      ctx.save(); ctx.lineCap = "round";
      ctx.strokeStyle = "#3a2530"; ctx.lineWidth = 2.6; ctx.beginPath(); ctx.moveTo(hx, hy); ctx.lineTo(tipX, tipY); ctx.stroke();
      ctx.strokeStyle = "#d9a06a"; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(hx, hy); ctx.lineTo(tipX, tipY); ctx.stroke();
      ctx.strokeStyle = "rgba(255,255,255,.85)"; ctx.lineWidth = 0.7; ctx.beginPath(); ctx.moveTo(tipX, tipY);
      ctx.quadraticCurveTo((tipX + px) / 2, Math.max(tipY, py) + (bite ? 1 : k < 1 ? 0 : 12), px, py + dip); ctx.stroke();
      if (k >= 1) {
        const rr = 4 + ((G.t / 90) % 8); ctx.strokeStyle = `rgba(255,255,255,${0.6 - rr / 20})`; ctx.lineWidth = 1; ctx.beginPath(); ctx.ellipse(px, py + 3, rr, rr * 0.35, 0, 0, 7); ctx.stroke();
        if (bite) { ctx.fillStyle = "rgba(255,255,255,.8)"; for (let q = 0; q < 4; q++) { const a = G.t / 120 + q * 1.6; ctx.fillRect(px + Math.cos(a) * 6, py + 1 + Math.sin(a) * 2 - Math.abs(Math.sin(G.t / 90 + q)) * 4, 1.5, 1.5); } }
        ctx.fillStyle = "#3a2530"; ctx.fillRect(px - 2.5, py + dip - 3, 5, 6.5);
        ctx.fillStyle = "#ff4d6d"; ctx.fillRect(px - 1.5, py + dip - 2, 3, 2.2); ctx.fillStyle = "#ffffff"; ctx.fillRect(px - 1.5, py + dip + 0.4, 3, 2.2);
        if (bite) { ctx.font = `bold 9px ${FONT}`; ctx.textAlign = "center"; ctx.fillStyle = "#3a2530"; ctx.fillText("!", px + 0.6, py - 7.4); ctx.fillStyle = "#ffd34d"; ctx.fillText("!", px, py - 8); }
      }
      ctx.restore();
    }
  }
  function showFishResult(out) {
    const sp = Fishing.BY[out.sp]; if (!sp) return;
    const stars = "★".repeat(Math.min(6, sp.stars)) + "☆".repeat(Math.max(0, 6 - sp.stars));
    if (!out.ok) {
      try { SFX.aww(); } catch {}
      openModal("💦 " + t("fishLostTitle"), `<div class="fish-res lost"><canvas class="fr-fish" width="260" height="140"></canvas><h3>${esc(t("fishEscaped", { name: fishName(out.sp), eul: eul(fishName(out.sp)) }))}</h3>
        <p class="fr-stars">${stars}</p><p class="fr-desc">${esc(t("fishLostTip"))}</p>
        <p class="fr-btns"><button class="btn pink" id="fr-again">🎣 ${esc(t("fishAgain"))}</button></p></div>`, (el) => mountFishResult(el, out, true));
      return;
    }
    const have = ((G.user.fish && G.user.fish.have) || {})[out.sp] | 0;
    if (sp.boss) whaleParty(); else try { SFX.catchFish(); } catch {}
    openModal((sp.boss ? "👑 " : "🎉 ") + t("fishGotTitle"), `<div class="fish-res${sp.boss ? " boss" : ""}"><canvas class="fr-fish" width="260" height="140"></canvas>
      <h3>${esc(t("fishGot", { name: L(sp.name), eul: eul(L(sp.name)) }))}</h3><p class="fr-stars">${stars}</p><p class="fr-desc">${esc(L(sp.desc))}</p>
      <div class="fr-meta"><span>📏 ${esc(t("fishSize", { n: out.size.toLocaleString() }))}${out.best ? ` <b class="fr-best">🏅 ${esc(t("fishBest"))}</b>` : ""}</span><span>🪙 ${esc(t("fishPrice", { n: sp.price.toLocaleString() }))}</span></div>
      <p class="fr-tank">🐠 ${esc(t("fishToTank", { n: have }))}</p>
      ${sp.boss ? `<p class="fr-hall">🏆 ${esc(t("whaleHallYou", { n: out.hallN || 1 }))}</p>` : ""}
      <p class="fr-btns"><button class="btn pink" id="fr-again">🎣 ${esc(t("fishAgain"))}</button> <button class="btn sm grape" id="fr-tank">🐠 ${esc(t("aquaBtn"))}</button></p></div>`, (el) => mountFishResult(el, out, false));
  }
  function mountFishResult(el, out, lost) {
    const cv = el.querySelector(".fr-fish"), x = cv.getContext("2d"); let raf = 0;
    const loop = (now) => {
      x.clearRect(0, 0, cv.width, cv.height);
      const g = x.createRadialGradient(130, 70, 10, 130, 70, 130); g.addColorStop(0, lost ? "rgba(120,160,220,.35)" : "rgba(255,240,170,.75)"); g.addColorStop(1, "rgba(255,255,255,0)");
      x.fillStyle = g; x.fillRect(0, 0, cv.width, cv.height);
      const wdt = Math.min(230, 120 + Fishing.BY[out.sp].stars * 18);
      if (lost) { const k = (now % 2400) / 2400; x.globalAlpha = 0.75 * (1 - k); Fishing.draw(x, out.sp, 150 - k * 190, 74 + Math.sin(now / 160) * 3, wdt * 0.7, now, false); x.globalAlpha = 1; } // 꼬리를 흔들며 멀리 도망감
      else Fishing.draw(x, out.sp, 130, 72, wdt, now, false);
      if (!lost) for (let k = 0; k < 8; k++) { const a = now / 600 + k * 0.8; if (Math.sin(a * 3) < 0.4) continue; x.fillStyle = "#fff3a8"; x.fillRect(130 + Math.cos(a) * 110, 70 + Math.sin(a * 1.3) * 55, 3, 3); }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    G.modalCleanup = () => cancelAnimationFrame(raf);
    const again = el.querySelector("#fr-again"); if (again) again.addEventListener("click", () => { closeModal(); if (G.seatObj && G.seatObj.fish) startFishing(); });
    const tank = el.querySelector("#fr-tank"); if (tank) tank.addEventListener("click", () => openAquarium());
  }
  // 👑 털보고래를 낚으면: 빵빠레 + 폭죽 + 배너
  function whaleParty() {
    try { Piano.fanfare(); } catch {}
    G.banner = { text: t("whaleCaughtBanner"), until: performance.now() + 4500 };
    const cols = ["#ff5f9f", "#ffd34d", "#7fe3ff", "#a77ce0", "#8fe07a", "#ffffff"];
    for (let k = 0; k < 8; k++) setTimeout(() => {
      const bx = G.player.x + (Math.random() - 0.5) * 140, by = G.player.y - 60 - Math.random() * 60;
      for (let i = 0; i < 40; i++) { const a = (i / 40) * Math.PI * 2, sp = 40 + Math.random() * 70; G.fx.push({ x: bx, y: by, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, life: 1.3, max: 1.3, col: cols[(k + i) % cols.length], s: 2.5, g: 40 }); }
    }, k * 380);
    loadWhaleHall(true);
  }
  // ---------------- 🐠 어항 (내가 낚은 물고기) ----------------
  function openAquarium() {
    const f = G.user.fish || {}, have = f.have || {}, total = f.total || {}, best = f.best || {};
    const SP = Fishing.SPECIES, nHave = Object.values(have).reduce((a, b) => a + (b | 0), 0), found = SP.filter((s2) => total[s2.id] > 0).length;
    const card = (sp) => total[sp.id] > 0
      ? `<div class="aqua-card${sp.boss ? " boss" : ""}"><canvas width="140" height="70" data-sp="${sp.id}"></canvas><b>${esc(L(sp.name))}</b><small class="st">${"★".repeat(Math.min(6, sp.stars))}</small>
        <span>${esc(t("aquaHave", { n: have[sp.id] | 0 }))} · ${esc(t("aquaTotal", { n: total[sp.id] | 0 }))}</span><span>📏 ${esc(t("aquaBest", { n: (best[sp.id] | 0).toLocaleString() }))} · 🪙 ${sp.price.toLocaleString()}</span><p>${esc(L(sp.desc))}</p></div>`
      : `<div class="aqua-card unknown"><canvas width="140" height="70" data-sp="${sp.id}" data-dark="1"></canvas><b>???</b><small class="st">${"★".repeat(Math.min(6, sp.stars))}</small><span>${esc(t("aquaUnknown"))}</span></div>`;
    openModal("🐠 " + t("aquaTitle"), `<div class="aqua"><canvas class="aqua-tank"></canvas>
      <p class="aqua-sum">${esc(t("aquaSum", { n: nHave, d: found, m: SP.length }))} · 🪱 ${esc(baitText())}</p>
      ${nHave ? "" : `<p class="gb-empty">${esc(t("aquaEmpty"))}</p>`}<p class="aqua-sell">${esc(t("aquaSellHint"))}</p>
      <div class="aqua-grid">${SP.map(card).join("")}</div></div>`, (el) => {
      el.querySelectorAll(".aqua-card canvas").forEach((c) => { const x = c.getContext("2d"); Fishing.draw(x, c.dataset.sp, 70, 36, Math.min(124, 60 + Fishing.BY[c.dataset.sp].stars * 11), 0, false); if (c.dataset.dark) { x.globalCompositeOperation = "source-atop"; x.fillStyle = "#3a3448"; x.fillRect(0, 0, 140, 70); x.globalCompositeOperation = "source-over"; } });
      // 어항 속 물고기들이 헤엄침
      const cv = el.querySelector(".aqua-tank"), x = cv.getContext("2d"), dpr = Math.min(2, window.devicePixelRatio || 1);
      const Wd = cv.clientWidth || 600, Hd = 170; cv.width = Wd * dpr; cv.height = Hd * dpr; x.scale(dpr, dpr);
      const swimmers = [];
      SP.forEach((sp) => { const n = Math.min(3, have[sp.id] | 0); for (let i = 0; i < n; i++) swimmers.push({ id: sp.id, x: Math.random() * Wd, y: 30 + Math.random() * (Hd - 70), v: (14 + Math.random() * 20) * (Math.random() < 0.5 ? -1 : 1), w: Math.min(110, 34 + sp.stars * 11), ph: Math.random() * 6 }); });
      const weeds = Array.from({ length: 7 }, (_, i) => ({ x: 20 + i * (Wd / 7) + Math.random() * 30, h: 30 + Math.random() * 40 }));
      let raf = 0, last = performance.now();
      const loop = (now) => {
        const dt = Math.min(0.05, (now - last) / 1000); last = now;
        const g = x.createLinearGradient(0, 0, 0, Hd); g.addColorStop(0, "#7fd6ef"); g.addColorStop(1, "#2a7fb8"); x.fillStyle = g; x.fillRect(0, 0, Wd, Hd);
        x.fillStyle = "rgba(255,255,255,.12)"; for (let k = 0; k < 4; k++) { const lx = ((now / 40 + k * 170) % (Wd + 120)) - 60; x.beginPath(); x.moveTo(lx, 0); x.lineTo(lx + 40, 0); x.lineTo(lx - 20, Hd); x.lineTo(lx - 60, Hd); x.closePath(); x.fill(); }
        x.fillStyle = "#e8cd92"; x.fillRect(0, Hd - 18, Wd, 18); x.fillStyle = "#d4b47a"; for (let k = 0; k < Wd; k += 9) x.fillRect(k, Hd - 18 + (k % 3), 4, 2);
        for (const wd of weeds) { x.strokeStyle = "#3f9a55"; x.lineWidth = 4; x.beginPath(); x.moveTo(wd.x, Hd - 16); for (let k = 1; k <= 5; k++) x.lineTo(wd.x + Math.sin(now / 700 + k + wd.x) * 5, Hd - 16 - (wd.h * k) / 5); x.stroke(); }
        for (const s2 of swimmers) {
          s2.x += s2.v * dt; if (s2.x < s2.w / 2) { s2.x = s2.w / 2; s2.v = Math.abs(s2.v); } if (s2.x > Wd - s2.w / 2) { s2.x = Wd - s2.w / 2; s2.v = -Math.abs(s2.v); }
          Fishing.draw(x, s2.id, s2.x, s2.y + Math.sin(now / 900 + s2.ph) * 6, s2.w, now + s2.ph * 300, s2.v > 0);
        }
        x.fillStyle = "rgba(255,255,255,.7)"; for (let k = 0; k < 12; k++) { const bx = (k * 73) % Wd, by = Hd - ((now / 18 + k * 47) % Hd); x.beginPath(); x.arc(bx + Math.sin(now / 300 + k) * 3, by, 2 + (k % 3), 0, 7); x.fill(); }
        if (!swimmers.length) { x.font = `bold 13px ${FONT}`; x.textAlign = "center"; x.fillStyle = "rgba(255,255,255,.9)"; x.fillText("🎣 " + t("aquaGoFish"), Wd / 2, Hd / 2); }
        raf = requestAnimationFrame(loop);
      };
      raf = requestAnimationFrame(loop);
      G.modalCleanup = () => cancelAnimationFrame(raf);
    }, true);
  }
  // ---------------- 🛍️ 젤리젤리샵: 물고기 팔기 ----------------
  function renderSellFish(grid) {
    const have = (G.user.fish && G.user.fish.have) || {};
    const list = Fishing.SPECIES.filter((sp) => (have[sp.id] | 0) > 0);
    const intro = `<p class="sell-intro">🎣 ${esc(t("sellIntro"))}</p>`;
    if (!list.length) { grid.innerHTML = intro + `<p class="gb-empty sell-empty">${esc(t("sellNone"))}</p>`; return; }
    const total = list.reduce((a, sp) => a + (sp.boss ? 0 : sp.price * (have[sp.id] | 0)), 0);
    grid.innerHTML = intro + (total ? `<div class="sell-all"><button class="btn pink" data-all="1">🐟 ${esc(t("sellEverything", { n: total.toLocaleString() }))}</button>${have.furwhale ? `<small>${esc(t("sellWhaleKept"))}</small>` : ""}</div>` : "")
      + list.map((sp) => `<div class="shop-item sell-item${sp.boss ? " t4 t6" : sp.stars >= 4 ? " t4" : sp.stars >= 3 ? " t3" : ""}" data-sp="${sp.id}"><span class="kind">${"★".repeat(Math.min(6, sp.stars))}</span>
        <canvas width="120" height="66"></canvas><b>${esc(L(sp.name))}</b><span class="price">🪙 ${sp.price.toLocaleString()} × ${have[sp.id] | 0}</span>
        <div class="sell-btns"><button class="btn sm pink" data-n="1">${esc(t("sellOne"))}</button>${(have[sp.id] | 0) > 1 ? `<button class="btn sm grape" data-n="${have[sp.id] | 0}">${esc(t("sellAllKind", { n: have[sp.id] | 0 }))}</button>` : ""}</div></div>`).join("");
    grid.querySelectorAll(".sell-item canvas").forEach((c) => { const sp = c.closest(".sell-item").dataset.sp; Fishing.draw(c.getContext("2d"), sp, 60, 34, Math.min(110, 56 + Fishing.BY[sp].stars * 9), 0, false); });
    const doSell = async (b, body) => {
      const sp = body.sp && Fishing.BY[body.sp];
      if (sp && sp.boss && !b.classList.contains("sure")) { b.classList.add("sure"); b.dataset.label = b.textContent; b.textContent = t("sellSure"); setTimeout(() => { if (b.isConnected) { b.classList.remove("sure"); b.textContent = b.dataset.label; } }, 4000); return; }
      b.disabled = true;
      try { const r = await API.fishSell(body); setUser(r.user); try { SFX.coin(); } catch {} toast(t("sellDone", { n: r.earned.toLocaleString(), c: r.sold })); const cEl = $("#shop-coins"); if (cEl) cEl.textContent = (G.user.coins | 0).toLocaleString(); renderShop(); }
      catch (e) { toast(e.message); b.disabled = false; }
    };
    grid.querySelectorAll(".sell-item [data-n]").forEach((b) => b.addEventListener("click", () => doSell(b, { sp: b.closest(".sell-item").dataset.sp, n: +b.dataset.n })));
    const all = grid.querySelector("[data-all]"); if (all) all.addEventListener("click", () => doSell(all, { all: true }));
  }
  // ---------------- 🐋 털보고래 명예의 전당 (광장 서쪽 전광판) ----------------
  let hallAt = 0;
  function loadWhaleHall(force) {
    if (!force && Date.now() - hallAt < 60000) return Promise.resolve();
    hallAt = Date.now();
    return API.fishHall().then((r) => { World.whaleHall = r.hall || []; }).catch(() => { hallAt = 0; });
  }
  setInterval(() => { if (G.mode === "world" && G.scene === "plaza" && !document.hidden) loadWhaleHall(); }, 120000);
  function openWhaleHall() {
    const fmtD = (ts) => { const d = new Date(ts); return `${d.getFullYear()}.${String(d.getMonth() + 1).padStart(2, "0")}.${String(d.getDate()).padStart(2, "0")}`; };
    const listHTML = () => { const list = World.whaleHall || []; return list.length ? `<div class="wh-list">${list.map((e) => `<div class="wh-row${G.user && e.id === G.user.id ? " me" : ""}"><span class="wh-n">${esc(t("whaleNth", { n: e.n }))}</span><canvas width="32" height="26" data-av='${esc(JSON.stringify(e.avatar || null))}'></canvas><b>${esc(e.name)}</b><span class="wh-meta">🐋 ${(e.size || 0).toLocaleString()}cm · ${fmtD(e.ts)}</span></div>`).join("")}</div>`
      : `<p class="gb-empty">${esc(t("whaleNone"))}</p>`; };
    const faces = (el) => el.querySelectorAll("canvas[data-av]").forEach((c) => { try { const av = JSON.parse(c.dataset.av); const x = c.getContext("2d"); x.imageSmoothingEnabled = false; if (av) Avatar.face(x, av, 32, 26); } catch {} });
    openModal("🐋 " + t("whaleBoardZ"), `<div class="whale-hall"><canvas class="wh-fish" width="300" height="120"></canvas><p class="wh-intro">${esc(t("whaleHallIntro"))}</p><div class="wh-box">${listHTML()}</div></div>`, (el) => {
      faces(el);
      // 최신 명단을 받아 오면 다시 그림
      loadWhaleHall(true).then(() => { const box = el.querySelector(".wh-box"); if (box && box.isConnected) { box.innerHTML = listHTML(); faces(box); } });
      const cv = el.querySelector(".wh-fish"), x = cv.getContext("2d"); let raf = 0;
      const loop = (now) => { x.clearRect(0, 0, 300, 120); const g = x.createLinearGradient(0, 0, 0, 120); g.addColorStop(0, "#2a6fb0"); g.addColorStop(1, "#123a68"); x.fillStyle = g; x.fillRect(0, 0, 300, 120); Fishing.draw(x, "furwhale", 150, 62, 230, now, false); raf = requestAnimationFrame(loop); };
      raf = requestAnimationFrame(loop); G.modalCleanup = () => cancelAnimationFrame(raf);
    }, true);
  }

  // ---------------- 😊 이모티콘 반응 (머리 위로 떠오름 · 모두에게 보임) ----------------
  const EMOTES = ["👏", "❤️", "🎉", "😂", "😭", "😍", "👍", "🎵"];
  function drawEmote(X, Y, emo, now, hasBubble) {
    const age = now - emo.at, left = emo.until - now;
    const pop = Math.min(1, age / 180), a = Math.min(1, left / 500);
    const size = Math.round(24 * (0.6 + 0.4 * pop) + (age < 300 ? Math.sin((age / 300) * Math.PI) * 6 : 0));
    const yy = Y - (hasBubble ? 58 : 30) - (age / 3500) * 14;
    ctx.save(); ctx.globalAlpha = a;
    ctx.fillStyle = "#fff8ea"; ctx.strokeStyle = "#3a2530"; ctx.lineWidth = 2.5;
    ctx.beginPath(); ctx.arc(X, yy, size * 0.72, 0, 7); ctx.fill(); ctx.stroke();
    ctx.font = `${size}px sans-serif`; ctx.textAlign = "center"; ctx.textBaseline = "middle"; ctx.fillText(EMOTES[emo.e] || "❤️", X, yy + 1);
    ctx.restore();
  }
  let emoLast = 0;
  function sendEmote(e) {
    if (G.mode !== "world") return;
    const now = Date.now(); if (now - emoLast < 1200) return; emoLast = now;
    G.myEmo = { e, at: now, until: now + 3500 };
    G.sendEmo = { e, k: Math.random().toString(36).slice(2, 10) };
    kickSync(); scheduleSync(60);
    $("#emo-pop").classList.add("hidden");
  }
  (function emotePicker() {
    const pop = $("#emo-pop");
    pop.innerHTML = EMOTES.map((e, i) => `<button type="button" class="emo" data-e="${i}">${e}</button>`).join("");
    pop.querySelectorAll(".emo").forEach((b) => b.addEventListener("click", (ev) => { ev.stopPropagation(); sendEmote(+b.dataset.e); }));
    const toggle = (ev) => { ev.preventDefault(); ev.stopPropagation(); pop.classList.toggle("hidden"); };
    $("#btn-emo").addEventListener("click", toggle);
    $("#emo-fab").addEventListener("click", toggle);
    document.addEventListener("pointerdown", (ev) => { if (!pop.classList.contains("hidden") && !pop.contains(ev.target) && ev.target.id !== "btn-emo" && ev.target.id !== "emo-fab") pop.classList.add("hidden"); });
    window.addEventListener("keydown", (ev) => { if (G.mode === "world" && !G.modalOpen && !G.quizOpen && ev.target.tagName !== "INPUT" && ev.target.tagName !== "TEXTAREA" && /^Digit[1-8]$/.test(ev.code)) sendEmote(+ev.code.slice(5) - 1); });
  })();

  // ---------------- 🫧 분수대 → 바닷속 보물상자 ----------------
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const FOUNTAIN_FRONT = { x: 640, y: 268, dir: "down" };
  function fmtLeft(ms) { const m = Math.ceil(ms / 60000), h = Math.floor(m / 60); return h ? t("hm", { h, m: m % 60 }) : t("mOnly", { m }); }
  async function diveIn() {
    if (G.dive || G.diving) return;
    G.diving = true;
    let r;
    try { r = await API.seaDive(); } catch (e) { G.diving = false; return toast(e.message); }
    try { SFX.splash(); } catch {}
    // 풍덩! 물보라
    for (let i = 0; i < 40; i++) { const a = -Math.PI * Math.random(), sp = 40 + Math.random() * 70; G.fx.push({ x: G.player.x, y: G.player.y - 6, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, life: 0.8, max: 0.8, col: i % 2 ? "#c7f1fa" : "#ffffff", s: 2.5, g: 160 }); }
    await sleep(350);
    await fade(true);
    const w = G.worlds.sea, locked = r.lockLeft > 0;
    w.placeChest(); // 🎲 들어갈 때마다 보물상자 위치가 바뀜
    w.sea.chestOpen = false; w.sea.locked = locked; w.icons[0].icon = locked ? "🔒" : "❓";
    setScene("sea", { ...w.spawn, dir: "down" });
    G.fx = [];
    try { Chip.play("sea"); } catch {}
    G.dive = { t0: performance.now(), o2: r.o2 || 15000, need: r.need || 2, ok: 0, coins: r.coins || 400, lockUntil: locked ? Date.now() + r.lockLeft : 0, done: false, beat: 0, bub: 0 };
    renderO2();
    $("#o2").classList.remove("hidden");
    G.diving = false;
    await fade(false);
    toast(locked ? t("seaLockedToast", { time: fmtLeft(r.lockLeft) }) : t("seaHint", { n: G.dive.need, c: G.dive.coins }));
  }
  function o2Left() { const d = G.dive; return d ? Math.max(0, d.o2 - (performance.now() - d.t0)) : 0; }
  function renderO2() {
    const d = G.dive; if (!d) return;
    const left = d.done && d.frozenLeft !== undefined ? d.frozenLeft : o2Left(), k = left / d.o2;
    $("#o2-fill").style.width = (k * 100).toFixed(1) + "%";
    $("#o2").classList.toggle("low", k <= 0.3);
    $("#o2-txt").textContent = (left / 1000).toFixed(1);
    $("#o2-score").textContent = `🧰 ${d.ok}/${d.need}`;
    $("#o2-dark").style.opacity = d.done ? 0 : Math.max(0, (0.35 - k) / 0.35) * 0.9;
  }
  function updateDive(dt) {
    const d = G.dive; if (!d || G.scene !== "sea") return;
    renderO2();
    // 입에서 뽀글뽀글 물방울
    d.bub -= dt; if (d.bub <= 0) { d.bub = 0.5 + Math.random() * 0.5; G.fx.push({ x: G.player.x + (G.player.dir === "left" ? -3 : 3), y: G.player.y - 30, vx: (Math.random() - 0.5) * 8, vy: -28, life: 1.6, max: 1.6, col: "#dff8ff", s: 2, g: -6 }); }
    if (d.done) return;
    const left = o2Left();
    if (left <= 5000) { d.beat -= dt; if (d.beat <= 0) { d.beat = left <= 2500 ? 0.5 : 0.9; try { SFX.beat(); } catch {} } }
    if (left <= 0) suffocate();
  }
  function endDive() {
    G.dive = null; closeQuiz();
    $("#o2").classList.add("hidden"); $("#o2-dark").style.opacity = 0;
    try { Chip.stop(); } catch {}
  }
  async function suffocate() {
    const d = G.dive; if (!d || d.done) return;
    d.done = true; d.frozenLeft = 0;
    closeQuiz(); G.frozen = true; G.target = null; G.keys.clear();
    try { Chip.stop(); SFX.choke(); } catch {}
    const ch = $("#choke"); $("#choke-txt").textContent = t("seaChoke");
    ch.classList.remove("out"); ch.classList.add("on");
    await sleep(2600);
    endDive();
    setScene("plaza", FOUNTAIN_FRONT);
    await sleep(500);
    ch.classList.add("out"); ch.classList.remove("on");
    G.frozen = false;
    await sleep(1200);
    ch.classList.remove("out");
    toast(t("seaRespawn"));
  }
  async function surface(win) {
    const d = G.dive; if (!d || G.surfacing) return;
    if (!d.done) { d.done = true; d.frozenLeft = o2Left(); }
    G.surfacing = true;
    closeQuiz();
    try { SFX.splash(); } catch {}
    await fade(true);
    endDive();
    setScene("plaza", FOUNTAIN_FRONT);
    await fade(false);
    G.surfacing = false;
    if (!win) toast(t("seaUp"));
  }
  function openChest() {
    const d = G.dive; if (!d || d.done) return;
    if (d.lockUntil > Date.now()) return toast(t("seaLockedToast", { time: fmtLeft(d.lockUntil - Date.now()) }));
    G.quizOpen = true; G.keys.clear(); G.joy.x = G.joy.y = 0; G.target = null;
    $("#quiz").classList.remove("hidden");
    $("#quiz-msg").textContent = "";
    nextQuestion();
  }
  function closeQuiz() { G.quizOpen = false; $("#quiz").classList.add("hidden"); }
  let quizBusy = false;
  async function nextQuestion() {
    const d = G.dive; if (!d || d.done || !G.quizOpen) return;
    $("#quiz-score").textContent = `${d.ok}/${d.need}`;
    $("#quiz-q").textContent = "…"; $("#quiz-choices").innerHTML = "";
    let q;
    try { q = await API.seaQ(I.lang); } catch (e) { if (e.code === "seaTimeout") return suffocate(); toast(e.message); return closeQuiz(); }
    if (!G.dive || G.dive.done || !G.quizOpen) return;
    $("#quiz-q").textContent = q.q;
    const box = $("#quiz-choices");
    box.innerHTML = q.choices.map((c, i) => `<button class="btn qc" data-i="${i}"><b>${"ABCD"[i]}</b> ${esc(c)}</button>`).join("");
    quizBusy = false;
    box.querySelectorAll(".qc").forEach((b) => b.addEventListener("click", () => answer(+b.dataset.i)));
  }
  async function answer(i) {
    const d = G.dive; if (!d || d.done || quizBusy) return;
    quizBusy = true;
    const btns = [...document.querySelectorAll("#quiz-choices .qc")]; btns.forEach((b) => (b.disabled = true));
    let r;
    try { r = await API.seaAnswer(i); } catch (e) { if (e.code === "seaTimeout") return suffocate(); toast(e.message); quizBusy = false; btns.forEach((b) => (b.disabled = false)); return; }
    if (!G.dive || G.dive.done) return;
    if (btns[r.answer]) btns[r.answer].classList.add("right");
    if (!r.correct && btns[i]) btns[i].classList.add("wrong");
    d.ok = r.ok;
    $("#quiz-score").textContent = `${d.ok}/${d.need}`;
    renderO2();
    if (r.correct) { try { SFX.right(); } catch {} $("#quiz-msg").textContent = t("quizRight"); }
    else { try { SFX.wrong(); } catch {} $("#quiz-msg").textContent = t("quizWrong"); }
    if (r.opened) return chestOpened(r);
    await sleep(r.correct ? 650 : 1000);
    $("#quiz-msg").textContent = "";
    nextQuestion();
  }
  async function chestOpened(r) {
    const d = G.dive; d.done = true; d.frozenLeft = o2Left();
    const w = G.worlds.sea; w.sea.chestOpen = true; w.sea.locked = true; w.icons[0].icon = "✨";
    if (r.user) setUser(r.user);
    try { SFX.chest(); } catch {}
    $("#quiz-q").textContent = t("seaWin", { n: r.coins });
    $("#quiz-choices").innerHTML = `<div class="quiz-win">🧰✨ +${r.coins} 🪙</div>`;
    $("#quiz-msg").textContent = t("seaAgain");
    const cx = w.chest.x, cy = w.chest.y - 22;
    for (let k = 0; k < 60; k++) setTimeout(() => G.fx.push({ x: cx + (Math.random() - 0.5) * 20, y: cy, vx: (Math.random() - 0.5) * 90, vy: -60 - Math.random() * 90, life: 1.4, max: 1.4, col: k % 3 ? "#ffd34d" : "#fff3a8", s: 3, g: 90 }), k * 25);
    renderO2();
    await sleep(3200);
    surface(true);
    toast(t("seaWinToast", { n: r.coins }));
  }
  $("#quiz-close").addEventListener("click", closeQuiz);
  window.addEventListener("keydown", (ev) => {
    if (!G.quizOpen) return;
    if (ev.key === "Escape") { closeQuiz(); ev.preventDefault(); return; }
    const k = { Digit1: 0, Digit2: 1, Digit3: 2, Digit4: 3, Numpad1: 0, Numpad2: 1, Numpad3: 2, Numpad4: 3 }[ev.code];
    if (k !== undefined) { const b = document.querySelectorAll("#quiz-choices .qc")[k]; if (b && !b.disabled) b.click(); ev.preventDefault(); }
  }, true);

  // ---------------- 🎨 젤리에게 그려줘! (그림판 + 갤러리) ----------------
  const ART_COLORS = ["#ff3b30", "#ff9500", "#ffd60a", "#34c759", "#0a84ff", "#1f2a7a", "#9b51e0", "#1a1a1a", "#ffffff"];
  const ART_W = 320, ART_H = 240;
  const art = { sort: "new", page: 0, color: 0, size: 1, fill: false, draft: null, title: "" };
  function openArt() {
    openModal("🎨 " + t("artBoard"), `<div class="art-top"><div class="chips"><button class="chip" data-sort="new">🆕 ${esc(t("artNew"))}</button><button class="chip" data-sort="top">❤️ ${esc(t("artTop"))}</button></div>
      <button class="btn sm pink" id="art-draw">🖌 ${esc(t("artDraw"))}</button></div>
      <p class="art-intro">${esc(t("artIntro"))}</p>
      <div class="art-grid" id="art-grid"><p class="gb-empty">…</p></div><div class="art-pager" id="art-pager"></div>`, (el) => {
      el.querySelectorAll("[data-sort]").forEach((b) => b.addEventListener("click", () => { art.sort = b.dataset.sort; art.page = 0; loadArt(); }));
      el.querySelector("#art-draw").addEventListener("click", openDraw);
      loadArt();
    }, true);
  }
  async function loadArt() {
    const grid = $("#art-grid"); if (!grid) return;
    document.querySelectorAll(".art-top [data-sort]").forEach((b) => b.classList.toggle("on", b.dataset.sort === art.sort));
    let r;
    try { r = await API.artList(art.page, art.sort); } catch (e) { grid.innerHTML = `<p class="gb-empty">${esc(e.message)}</p>`; return; }
    art.items = r.items || []; art.left = r.left;
    if (!$("#art-grid")) return;
    grid.innerHTML = art.items.length ? art.items.map((it, i) => `<div class="art-card" data-i="${i}"><img src="${esc(API.artImg(it))}" alt="" loading="lazy"><div class="art-meta"><b title="${esc(it.title || "")}">${esc(it.title ? trPick(it.title, it.titleTr) : t("artUntitled"))}</b><small>${esc(it.name)} · <span class="${it.liked ? "liked" : ""}">❤️ ${it.likes}</span></small></div></div>`).join("") : `<p class="gb-empty">${esc(t("artEmpty"))}</p>`;
    grid.querySelectorAll(".art-card").forEach((c) => c.addEventListener("click", () => openArtView(art.items[+c.dataset.i])));
    const pages = Math.max(1, Math.ceil((r.total || 0) / 12)), pg = $("#art-pager");
    pg.innerHTML = pages > 1 ? `<button class="btn sm" id="ap-prev" ${art.page ? "" : "disabled"}>◀</button><span>${art.page + 1} / ${pages}</span><button class="btn sm" id="ap-next" ${art.page + 1 < pages ? "" : "disabled"}>▶</button>` : "";
    if (pages > 1) { pg.querySelector("#ap-prev").addEventListener("click", () => { art.page--; loadArt(); }); pg.querySelector("#ap-next").addEventListener("click", () => { art.page++; loadArt(); }); }
  }
  function openArtView(it) {
    const canDel = it.uid === G.user.id || staff(G.user.role);
    openModal("🎨 " + (it.title ? trPick(it.title, it.titleTr) : t("artUntitled")), `<div class="art-view"><img src="${esc(API.artImg(it))}" alt="">
      <div class="art-by"><canvas width="32" height="26" id="av-face"></canvas><div><b>${esc(it.name)}</b>${it.role === "artist" ? " 👑" : it.role === "admin" ? " ★" : ""}<br><small>${esc(fmtTime(it.ts))}</small></div>
      <button class="btn sm ${it.liked ? "pink" : ""}" id="av-like">❤️ ${it.likes}</button></div>
      <div class="art-view-foot"><button class="btn sm" id="av-back">◀ ${esc(t("artBack"))}</button>${canDel ? `<button class="btn sm kick" id="av-del">${esc(t("del"))}</button>` : ""}</div></div>`, (el) => {
      try { if (it.avatar) Avatar.face(el.querySelector("#av-face").getContext("2d"), it.avatar, 32, 26); } catch {}
      el.querySelector("#av-back").addEventListener("click", openArt);
      el.querySelector("#av-like").addEventListener("click", async (e) => {
        e.target.disabled = true;
        try { const r = await API.artLike(it.id); Object.assign(it, r.item); e.target.textContent = `❤️ ${it.likes}`; e.target.classList.toggle("pink", it.liked); if (it.liked) { try { SFX.coin(); } catch {} } }
        catch (x) { toast(x.message); } finally { e.target.disabled = false; }
      });
      const del = el.querySelector("#av-del");
      if (del) del.addEventListener("click", async () => {
        if (!del.classList.contains("sure")) { del.classList.add("sure"); del.textContent = t("adminKickSure"); return; }
        try { await API.artDelete(it.id); toast(t("artDeleted")); openArt(); } catch (x) { toast(x.message); }
      });
    }, true);
  }
  function openDraw() {
    openModal("🖌 " + t("artDraw"), `<div class="draw">
      <input class="inp" id="dr-title" maxlength="30" placeholder="${esc(t("artTitlePh"))}" value="${esc(art.title)}">
      <div class="dr-wrap"><canvas id="dr-cv" width="${ART_W}" height="${ART_H}"></canvas></div>
      <div class="dr-pal">${ART_COLORS.map((c, i) => `<button class="sw" data-c="${i}" style="background:${c}" title="${esc((t("artColors") || [])[i] || "")}"></button>`).join("")}</div>
      <div class="dr-tools">
        <span class="dr-sizes">${[0, 1, 2].map((i) => `<button class="btn sm" data-s="${i}"><i style="width:${[4, 8, 14][i]}px;height:${[4, 8, 14][i]}px"></i></button>`).join("")}</span>
        <button class="btn sm" id="dr-fill">🪣 ${esc(t("artFill"))}</button>
        <button class="btn sm" id="dr-undo">↩ ${esc(t("artUndo"))}</button>
        <button class="btn sm" id="dr-clear">🗑 ${esc(t("artClear"))}</button>
      </div>
      <div class="dr-foot"><small id="dr-left"></small><button class="btn sm" id="dr-gal">🖼 ${esc(t("artGallery"))}</button><button class="btn pink" id="dr-post">📌 ${esc(t("artPost"))}</button></div></div>`, (el) => {
      const cv = el.querySelector("#dr-cv"), g = cv.getContext("2d", { willReadFrequently: true });
      g.imageSmoothingEnabled = false;
      if (art.draft) g.putImageData(art.draft, 0, 0); else { g.fillStyle = "#ffffff"; g.fillRect(0, 0, ART_W, ART_H); }
      const undo = [];
      const snap = () => { undo.push(g.getImageData(0, 0, ART_W, ART_H)); if (undo.length > 25) undo.shift(); };
      const saveDraft = () => { art.draft = g.getImageData(0, 0, ART_W, ART_H); art.dirty = true; };
      const R = [1, 3, 6];
      const stamp = (x, y) => {
        const r = R[art.size]; g.fillStyle = ART_COLORS[art.color];
        for (let dy = -r; dy <= r; dy++) { const w = Math.floor(Math.sqrt(r * r - dy * dy + r * 0.8)); g.fillRect(x - w, y + dy, w * 2 + 1, 1); }
      };
      const line = (x0, y0, x1, y1) => { const n = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0), 1); for (let i = 0; i <= n; i++) stamp(Math.round(x0 + ((x1 - x0) * i) / n), Math.round(y0 + ((y1 - y0) * i) / n)); };
      const flood = (sx, sy) => {
        const img = g.getImageData(0, 0, ART_W, ART_H), d = img.data;
        const hexc = ART_COLORS[art.color], nr = parseInt(hexc.slice(1, 3), 16), ng = parseInt(hexc.slice(3, 5), 16), nb = parseInt(hexc.slice(5, 7), 16);
        const i0 = (sy * ART_W + sx) * 4, tr = d[i0], tg = d[i0 + 1], tb = d[i0 + 2];
        if (tr === nr && tg === ng && tb === nb) return;
        const same = (p) => d[p] === tr && d[p + 1] === tg && d[p + 2] === tb;
        const stack = [[sx, sy]];
        while (stack.length) {
          let [x, y] = stack.pop(); let p = (y * ART_W + x) * 4;
          while (x > 0 && same(p - 4)) { x--; p -= 4; }
          let up = false, dn = false;
          while (x < ART_W && same(p)) {
            d[p] = nr; d[p + 1] = ng; d[p + 2] = nb; d[p + 3] = 255;
            if (y > 0) { const q = p - ART_W * 4; if (same(q)) { if (!up) { stack.push([x, y - 1]); up = true; } } else up = false; }
            if (y < ART_H - 1) { const q = p + ART_W * 4; if (same(q)) { if (!dn) { stack.push([x, y + 1]); dn = true; } } else dn = false; }
            x++; p += 4;
          }
        }
        g.putImageData(img, 0, 0);
      };
      const pos = (e) => { const r = cv.getBoundingClientRect(); return [Math.max(0, Math.min(ART_W - 1, Math.floor(((e.clientX - r.left) / r.width) * ART_W))), Math.max(0, Math.min(ART_H - 1, Math.floor(((e.clientY - r.top) / r.height) * ART_H)))]; };
      let drawing = null;
      cv.addEventListener("pointerdown", (e) => {
        e.preventDefault(); const [x, y] = pos(e); snap();
        if (art.fill) { flood(x, y); saveDraft(); return; }
        try { cv.setPointerCapture(e.pointerId); } catch {}
        drawing = { id: e.pointerId, x, y }; stamp(x, y);
      });
      cv.addEventListener("pointermove", (e) => { if (!drawing || e.pointerId !== drawing.id) return; e.preventDefault(); const [x, y] = pos(e); line(drawing.x, drawing.y, x, y); drawing.x = x; drawing.y = y; });
      const end = () => { if (drawing) { drawing = null; saveDraft(); } };
      cv.addEventListener("pointerup", end); cv.addEventListener("pointercancel", end); cv.addEventListener("lostpointercapture", end);
      const refresh = () => {
        el.querySelectorAll(".dr-pal .sw").forEach((b) => b.classList.toggle("on", +b.dataset.c === art.color));
        el.querySelectorAll("[data-s]").forEach((b) => b.classList.toggle("on", +b.dataset.s === art.size && !art.fill));
        el.querySelector("#dr-fill").classList.toggle("on", art.fill);
      };
      el.querySelectorAll(".dr-pal .sw").forEach((b) => b.addEventListener("click", () => { art.color = +b.dataset.c; refresh(); }));
      el.querySelectorAll("[data-s]").forEach((b) => b.addEventListener("click", () => { art.size = +b.dataset.s; art.fill = false; refresh(); }));
      el.querySelector("#dr-fill").addEventListener("click", () => { art.fill = !art.fill; refresh(); });
      el.querySelector("#dr-undo").addEventListener("click", () => { const im = undo.pop(); if (im) { g.putImageData(im, 0, 0); saveDraft(); } });
      el.querySelector("#dr-clear").addEventListener("click", (e) => {
        const b = e.currentTarget; if (!b.classList.contains("sure")) { b.classList.add("sure"); b.textContent = t("adminKickSure"); setTimeout(() => { if (b.isConnected) { b.classList.remove("sure"); b.textContent = "🗑 " + t("artClear"); } }, 3000); return; }
        snap(); g.fillStyle = "#ffffff"; g.fillRect(0, 0, ART_W, ART_H); art.draft = null; art.dirty = false; b.classList.remove("sure"); b.textContent = "🗑 " + t("artClear");
      });
      el.querySelector("#dr-title").addEventListener("input", (e) => (art.title = e.target.value));
      el.querySelector("#dr-gal").addEventListener("click", openArt);
      const leftEl = el.querySelector("#dr-left");
      const showLeft = (n) => { leftEl.textContent = n >= 99 ? "" : t("artLeft", { n }); };
      if (art.left !== undefined) showLeft(art.left);
      API.artList(0, "new").then((r) => { art.left = r.left; if (leftEl.isConnected) showLeft(r.left); }).catch(() => {});
      el.querySelector("#dr-post").addEventListener("click", async (e) => {
        if (!art.dirty) return toast(t("artEmptyDraw"));
        const b = e.currentTarget; b.disabled = true;
        try {
          const r = await API.artPost(cv.toDataURL("image/png"), art.title.trim());
          if (r.user) setUser(r.user);
          art.draft = null; art.dirty = false; art.title = ""; art.left = r.left; art.sort = "new"; art.page = 0;
          toast(r.gained ? t("artPostedCoins", { n: r.gained }) : t("artPosted"));
          try { SFX.star(); } catch {}
          openArt();
        } catch (x) { toast(x.message); b.disabled = false; }
      });
      refresh();
    }, true);
  }

  // ---------------- 모달 콘텐츠 ----------------
  function openModal(title, html, onMount, wide) {
    if (Fishing.active) Fishing.cancel(); // 🎣 낚시 중에 다른 창을 열면 낚싯줄을 감고 그만둠
    if (G.modalCleanup) { const f = G.modalCleanup; G.modalCleanup = null; try { f(); } catch {} }
    document.querySelector("#modal .modal").classList.toggle("wide", !!wide);
    document.querySelector("#modal .modal").classList.remove("game", "piano");
    $("#modal-close-big").textContent = t("close");
    $("#modal-title").textContent = title;
    $("#modal-body").innerHTML = html;
    $("#modal").classList.remove("hidden");
    $("#modal-body").scrollTop = 0;
    G.modalOpen = true; G.keys.clear(); G.joy.x = G.joy.y = 0;
    onMount && onMount($("#modal-body"));
  }
  function closeModal() {
    if (G.modalCleanup) { const f = G.modalCleanup; G.modalCleanup = null; try { f(); } catch {} }
    $("#modal").classList.add("hidden"); $("#modal-body").innerHTML = ""; G.modalOpen = false;
  }
  $("#modal-close").addEventListener("click", closeModal);
  $("#modal-close-big").addEventListener("click", closeModal);
  $("#modal").addEventListener("click", (e) => { if (e.target.id === "modal") closeModal(); });

  function openGallery() {
    const html = `<p style="margin-top:0">${esc(t("galleryIntro"))} <button class="btn sm grape" data-go="profile">${esc(t("seeProfile"))}</button></p>
      <div class="gallery">${CFG.photos.map((p, i) => `<div class="polaroid${p.isNew ? " new" : ""}" data-i="${i}">${p.isNew ? '<span class="new-badge">NEW</span>' : ""}<img src="${esc(p.src)}" alt="${esc(L(p.caption))}" loading="lazy"><p>${esc(L(p.caption))}</p></div>`).join("")}</div>`;
    openModal("📷 " + t("bGallery"), html, (el) => { el.querySelector("[data-go=profile]").addEventListener("click", openProfile); el.querySelectorAll(".polaroid").forEach((d) => d.addEventListener("click", () => {
      const i = +d.dataset.i, p = CFG.photos[i], n = CFG.photos.length;
      openModal("📷 " + t("bGallery"), `<div class="lightbox"><img src="${esc(p.src)}" alt=""><p>${esc(L(p.caption))} <small>(${i + 1}/${n})</small></p>
        <p class="lb-nav"><button class="btn sm" id="prev">◀</button><button class="btn sm" id="back">${esc(t("back"))}</button><button class="btn sm" id="next">▶</button></p></div>`, (e2) => {
        e2.querySelector("#back").addEventListener("click", openGallery);
        const go = (j) => openGalleryAt((j + n) % n);
        e2.querySelector("#prev").addEventListener("click", () => go(i - 1));
        e2.querySelector("#next").addEventListener("click", () => go(i + 1));
      });
    })); });
  }
  function openGalleryAt(i) { openGallery(); $("#modal-body").querySelector(`.polaroid[data-i="${i}"]`).click(); }
  function openAlbums() {
    const meta = (k, v) => (v ? `<div><span>${esc(t(k))}</span><b>${esc(L(v))}</b></div>` : "");
    const html = `<p style="margin-top:0">${esc(t("albumsIntro"))}</p>` + CFG.albums.map((a, i) => `
      <div class="album">
        <div class="album-top">
          <img src="${esc(a.cover)}" alt="" class="cover">
          <div class="album-info">
            <span class="tag">${esc(L(a.type))}</span>
            <h3>${esc(L(a.title))}</h3>
            <div class="artist-line">Jo Jelly</div>
            <div class="meta">${meta("albRelease", a.date || a.year)}${meta("albGenre", a.genre)}${meta("albLabel", a.label)}${meta("albAgency", a.agency)}</div>
            ${a.link ? `<a class="btn sm pink" href="${esc(a.link)}" target="_blank" rel="noopener">${esc(t("listen"))}</a>` : ""}
          </div>
        </div>
        ${a.tracks && a.tracks.length ? `<h4>${esc(t("albTracks"))}</h4><ol class="tracks">${a.tracks.map((tr) => `<li>${esc(L(tr))}</li>`).join("")}</ol>` : ""}
        ${a.desc ? `<h4>${esc(t("albAbout"))}</h4><p class="desc">${esc(L(a.desc)).replace(/\n/g, "<br>")}</p>` : ""}
        ${a.credits && a.credits.length ? `<details class="credits"${i === 0 ? "" : ""}><summary>${esc(t("albCredits"))}</summary><dl>${a.credits.map(([r, n]) => `<dt>${esc(r)}</dt><dd>${esc(n)}</dd>`).join("")}</dl></details>` : ""}
      </div>`).join("");
    openModal("💿 " + t("bAlbums"), html);
  }
  // 🎬 젤리 시네마 입장 안내: 자리에 앉으면 영상을 볼 수 있어요
  function showCinemaGuide() {
    G.banner = { text: t("cinemaBanner"), until: performance.now() + 4500 };
    toast(t("cinemaGuide"));
    setTimeout(() => { if (G.scene === "cinema" && !G.seat) toast(t("cinemaGuide")); }, 2600);
  }
  function openCinema(idx = 0) {
    const vs = CFG.videos;
    if (!vs.length) return openModal("🎬 " + t("bCinema"), `<p>${esc(t("noVideo"))}</p>`);
    const v = vs[idx];
    const yt = CFG.artist.links.find((l) => l.label === "YouTube");
    const thumb = (x) => (x.file ? x.poster : `https://i.ytimg.com/vi/${encodeURIComponent(x.id)}/hqdefault.jpg`);
    const html = `<div class="player">${videoTag(v, false)}</div>
      <h3 style="margin:12px 0 0">${esc(L(v.title))}</h3>
      <div class="vlist">${vs.map((x, i) => `<div class="vitem ${i === idx ? "on" : ""}" data-i="${i}">${x.isNew ? '<span class="new-badge">NEW</span>' : ""}<img src="${esc(thumb(x))}" alt="" loading="lazy"><p>${esc(L(x.title))}</p></div>`).join("")}</div>
      ${yt ? `<p style="text-align:center"><a class="btn sm" href="${esc(yt.url)}" target="_blank" rel="noopener">${esc(t("ytChannel"))}</a></p>` : ""}`;
    openModal("🎬 " + t("bCinema"), html, (el) => { el.querySelectorAll(".vitem").forEach((d) => d.addEventListener("click", () => openCinema(+d.dataset.i))); hookVideo(el); });
  }
  // 영상 태그: 직접 올린 파일은 <video>, 나머지는 유튜브
  function videoTag(v, autoplay) {
    if (v.file) return `<video src="${esc(v.file)}" poster="${esc(v.poster || "")}" controls playsinline preload="metadata"${autoplay ? " autoplay" : ""}></video>`;
    return `<iframe src="https://www.youtube-nocookie.com/embed/${encodeURIComponent(v.id)}?rel=0&playsinline=1" title="${esc(L(v.title))}" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen" allowfullscreen></iframe>`;
  }
  // 영상이 재생되는 동안은 배경음악을 끄고, 창을 닫으면 다시 켬
  function hookVideo(el) {
    const vid = el.querySelector("video"), yt = el.querySelector("iframe");
    if (!vid && !yt) return;
    if (vid) vid.addEventListener("play", () => { try { stopMusic(); } catch {} });
    // 유튜브 영상: 영상 화면을 누르면(재생) 배경음악을 끔 — 창 포커스가 영상 쪽으로 넘어가는 걸로 알아챔
    const onBlur = () => setTimeout(() => { if (yt && document.activeElement === yt) { try { stopMusic(); } catch {} } }, 0);
    if (yt) window.addEventListener("blur", onBlur);
    const prev = G.modalCleanup;
    G.modalCleanup = () => { try { vid && vid.pause(); } catch {} if (yt) window.removeEventListener("blur", onBlur); if (prev) try { prev(); } catch {} if (!G.gameOpen) sceneMusic(G.scene); };
  }
  // ---------------- 🎬 영상 팝업 (정해진 날짜까지 접속할 때마다) ----------------
  function promoActive() { const p = CFG.promo; return !!(p && Date.now() < Date.parse(p.until) && CFG.videos[p.video]); }
  // "오늘 하루 보지 않기"는 계정마다 따로 (같은 기기에서 다른 계정으로 들어와도 영상이 보이게)
  const promoSkipKey = (p) => "jl_promo_skip_" + p.id + "_" + ((G.user && G.user.id) || "");
  // retry: 다른 창이 열려 있으면 4초 뒤 다시 시도할 횟수
  function showPromo(retry = 0) {
    const p = CFG.promo; if (!promoActive() || G.mode !== "world") return false;
    G.promoDay = kstDay(); // 오늘 영상 팝업을 확인했음 (날짜가 바뀌면 다시 띄움)
    try { if (localStorage.getItem(promoSkipKey(p)) === kstDay()) return false; } catch {}
    if (G.modalOpen || G.dive || G.gameOpen || G.quizOpen) { if (retry > 0) setTimeout(() => showPromo(retry - 1), 4000); return false; }
    const v = CFG.videos[p.video];
    openModal(L(p.title), `<div class="promo"><div class="player">${videoTag(v, false)}</div>
      <p class="promo-text">${esc(L(p.text))}</p>
      <div class="promo-cd" id="promo-cd"></div>
      <p class="promo-foot"><label><input type="checkbox" id="promo-skip"> ${esc(t("promoSkipToday"))}</label><button class="btn sm grape" id="promo-cinema">🎬 ${esc(t("bCinema"))}</button></p></div>`, (el) => {
      hookVideo(el);
      const cd = el.querySelector("#promo-cd"), end = Date.parse(p.until);
      const tick = () => {
        if (!cd.isConnected) return clearInterval(timer);
        const ms = Math.max(0, end - Date.now()), d = Math.floor(ms / 864e5), h = Math.floor(ms / 36e5) % 24, m = Math.floor(ms / 6e4) % 60, s = Math.floor(ms / 1e3) % 60;
        cd.innerHTML = `${esc(t("promoUntil"))} <b>${d ? t("promoDays", { n: d }) + " " : ""}${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}</b>`;
      };
      const timer = setInterval(tick, 1000); tick();
      el.querySelector("#promo-skip").addEventListener("change", (e) => { try { if (e.target.checked) localStorage.setItem(promoSkipKey(p), kstDay()); else localStorage.removeItem(promoSkipKey(p)); } catch {} });
      el.querySelector("#promo-cinema").addEventListener("click", () => openCinema(p.video));
    }, true);
    return true;
  }
  function openProfile() {
    const a = CFG.artist;
    const html = `<div class="profile"><img src="${esc(a.photo)}" alt="${esc(L(a.name))}"><div>
      <h2>${esc(L(a.name))} <span class="en">${esc(L(a.nameEn))}</span></h2><div class="role">🎹 ${esc(L(a.title))}</div>
      ${a.bio.map((b) => `<p>${esc(L(b))}</p>`).join("")}
      <div class="links">${a.links.map((l) => `<a class="btn sm ${l.label === "YouTube" ? "pink" : l.label === "Instagram" ? "grape" : "mint"}" href="${esc(l.url)}" target="_blank" rel="noopener">${esc(L(l.label))} ↗</a>`).join("")}</div>
      <div class="links"><button class="btn sm" data-go="gallery">${esc(t("gGallery"))}</button><button class="btn sm" data-go="albums">${esc(t("gAlbums"))}</button><button class="btn sm" data-go="cinema">${esc(t("gVideo"))}</button></div>
    </div></div>`;
    openModal("🎹 " + t("zProfile"), html, (el) => el.querySelectorAll("[data-go]").forEach((b) => b.addEventListener("click", () => runZone(b.dataset.go))));
  }
  // ---------------- 젤리코인 ----------------
  const SHOP = window.JELLY_SHOP || [];
  const isHost = () => !!(G.user && G.user.role === "artist");
  const owns = (it) => isHost() || (it.staff && G.user && staff(G.user.role)) || !!(G.user && (G.user.inv || []).includes(it.id));
  const shopItem = (kind, idx) => SHOP.find((x) => x.kind === kind && x.idx === idx);
  const kstDay = () => new Date(Date.now() + 9 * 3600 * 1000).toISOString().slice(0, 10);
  function setUser(u) { if (!u) return; G.user = { ...G.user, ...u }; refreshMe(); }
  function renderCoins() {
    const el = $("#coin-pill"); if (!el || !G.user) return;
    const n = G.user.coins | 0, old = +el.dataset.n || 0;
    el.textContent = "🪙 " + n.toLocaleString();
    if (n > old && el.dataset.n !== undefined) { el.classList.remove("bump"); void el.offsetWidth; el.classList.add("bump"); }
    el.dataset.n = n;
    const sc = $("#shop-coins"); if (sc) sc.textContent = n.toLocaleString();
  }
  let dailyBusy = false;
  async function checkDaily() {
    if (!G.user || G.mode !== "world" || dailyBusy) return;
    if (G.user.daily === kstDay() && G.user.welcomedChecked) return;
    dailyBusy = true;
    try {
      const r = await API.daily();
      setUser(r.user); G.user.welcomedChecked = true;
      const msgs = [];
      if (r.gained && r.gained.welcome) msgs.push(t("coinWelcome", { n: r.gained.welcome }));
      if (r.gained && r.gained.daily) msgs.push(t("coinDaily", { n: r.gained.daily }));
      msgs.forEach((m, i) => setTimeout(() => toast(m), 2600 + i * 2500));
    } catch {} finally { dailyBusy = false; }
  }
  document.addEventListener("visibilitychange", () => { if (!document.hidden && G.user && G.user.daily !== kstDay()) checkDaily(); });
  $("#coin-pill").addEventListener("click", () => toast(`🪙 ${t("myCoins")}: ${(G.user.coins | 0).toLocaleString()}`));

  // ---------------- ☕ 젤리 카페 (팬 라운지) ----------------
  // 음료 10종 · 모두 5코인 · 4분 동안 손에 들고 다님 (따뜻한 음료는 김이 모락모락)
  const CAFE_DRINKS = [
    { hot: 1, liq: "#6b3e22", top: "#e8c39a", mug: "#ffffff" },            // 따뜻한 젤리커피
    { liq: "#8a5a36", top: "#f2e2cc", jelly: "#ff8fb8" },                 // 아이스 젤리커피
    { liq: "#ffb347", top: "#fff3c4", jelly: "#ffd34d" },                 // 망고젤리 스무디
    { liq: "#ff7fae", top: "#fff0f5", jelly: "#d8434e" },                 // 딸기젤리 스무디
    { hot: 1, liq: "#5a3a26", top: "#c98b5a", mug: "#ffd1e1" },            // 흑당초코라떼
    { hot: 1, liq: "#6b3a2a", top: "#ffffff", mug: "#ffe8a3" },            // 젤리 핫초코
    { liq: "#7fa8ff", jelly: "#4a3a9f", ice: 1 },                          // 블루베리젤리 에이드
    { liq: "#7fe08a", top: "#ffffff", jelly: "#ff5a5a", ice: 1 },          // 메론젤리 소다
    { liq: "#ffb08a", jelly: "#ffd1a8", ice: 1 },                          // 복숭아젤리 아이스티
    { hot: 1, liq: "#8fc76a", top: "#f4f9e8", mug: "#c8ecdf" },            // 말차젤리 라떼
  ];
  // 컵 그리기: (x, y) = 컵 바닥 가운데 (월드 픽셀 단위)
  function drawCupAt(g, k, x, y, tt) {
    const D = CAFE_DRINKS[k] || CAFE_DRINKS[0];
    x = Math.round(x); y = Math.round(y);
    const R = (a, b, w, h, c) => { g.fillStyle = c; g.fillRect(a, b, w, h); };
    if (D.hot) { // 머그컵
      R(x - 4, y - 7, 8, 8, "#3a2530"); R(x - 3, y - 6, 6, 6, D.mug);
      R(x - 3, y - 6, 6, 2, D.liq); R(x - 2, y - 6, 3, 1, D.top);
      R(x + 4, y - 5, 2, 4, "#3a2530"); R(x + 4, y - 4, 1, 2, D.mug);
      R(x - 3, y - 2, 6, 1, "#ff8fb8");
      // 김이 모락모락: 동글동글한 김이 피어오르며 커지고 옅어짐
      for (let i = 0; i < 4; i++) {
        const ph = ((tt / 1300) + i / 4) % 1;
        const sx = x + Math.sin(tt / 300 + i * 1.7 + ph * 5) * 1.6, sy = y - 8 - ph * 13, r = 0.9 + ph * 1.8;
        g.globalAlpha = (1 - ph) * 0.35; g.fillStyle = "#8a7f9e"; g.beginPath(); g.arc(sx + 0.4, sy + 0.4, r + 0.5, 0, 7); g.fill();
        g.globalAlpha = (1 - ph) * 0.9; g.fillStyle = "#ffffff"; g.beginPath(); g.arc(sx, sy, r, 0, 7); g.fill();
      }
      g.globalAlpha = 1;
    } else { // 투명 컵 + 빨대
      R(x - 4, y - 11, 8, 12, "#3a2530"); R(x - 3, y - 10, 6, 10, "#eaf8ff");
      R(x - 3, y - 8, 6, 8, D.liq);
      if (D.top) R(x - 3, y - 9, 6, 2, D.top);
      if (D.ice || !D.top) { g.globalAlpha = 0.75; R(x - 2, y - 7, 2, 2, "#ffffff"); R(x + 1, y - 5, 2, 2, "#ffffff"); g.globalAlpha = 1; }
      if (D.jelly) { R(x - 2, y - 2, 1, 1, D.jelly); R(x, y - 1, 1, 1, D.jelly); R(x + 2, y - 2, 1, 1, D.jelly); R(x - 1, y - 3, 1, 1, D.jelly); }
      R(x - 4, y - 12, 8, 1, "#3a2530"); R(x + 1, y - 16, 1, 5, "#ff5f9f"); R(x + 2, y - 16, 2, 1, "#ff5f9f");
      R(x + 2, y - 10, 1, 4, "rgba(255,255,255,.7)"); // 반짝
    }
  }
  function drawHeldDrink(c, dk) {
    const handY = (c.sit ? c.y - 29 : c.y - 38) + 27;
    const dx = c.dir === "right" ? 5 : c.dir === "left" ? -5 : c.dir === "up" ? -7 : 7;
    drawCupAt(ctx, dk.k, c.x + dx, handY + (c.frame && !c.sit ? 1 : 0), G.t + (c.x | 0) * 13);
  }
  function cafeTick() {
    const u = G.user;
    if (u && u.drink && !(u.drink.until > serverNow_())) { u.drink = null; if (G.mode === "world") toast(t("cafeDone")); kickSync(); }
    if (G.mode !== "world") return;
    const st = scene() && scene().staff; if (!st) return;
    if (!st.next || G.t > st.next) { const L = t(st.linesKey || "cafeLines"); st.say = L[(Math.random() * L.length) | 0]; st.sayUntil = G.t + 4200; st.next = G.t + 8000 + Math.random() * 4000; }
    const d = Math.hypot(G.player.x - st.x, G.player.y - st.y - 44);
    if (d < 60 && !st.greeted) { st.greeted = true; st.say = t(st.welcomeKey || "cafeWelcome"); st.sayUntil = G.t + 3200; st.next = G.t + 7000; }
    if (d > 140) st.greeted = false;
  }
  function leftText(ms) { const s = Math.max(0, Math.ceil(ms / 1000)); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`; }
  function openCafe() {
    const names = t("cafeMenu");
    const html = `<div class="shop-top"><div class="coin-big">🪙 <b id="cafe-coins">${(G.user.coins | 0).toLocaleString()}</b> <small>${esc(t("coinName"))}</small></div>
      <p>${esc(t("cafeIntro"))}</p><p class="cafe-now" id="cafe-now"></p></div>
      <div class="cafe-grid">${CAFE_DRINKS.map((D, k) => `<div class="cafe-item" data-k="${k}"><span class="cafe-tag ${D.hot ? "hot" : "ice"}">${esc(t(D.hot ? "cafeHot" : "cafeIce"))}</span>
        <canvas width="72" height="84"></canvas><b>${esc(names[k])}</b><button class="btn sm pink">🪙 5 ${esc(t("cafeOrder"))}</button></div>`).join("")}</div>`;
    openModal("☕ " + t("cafeTitle"), html, (el) => {
      const cvs = [...el.querySelectorAll(".cafe-item canvas")];
      let raf = 0;
      const paint = () => {
        const tt = performance.now();
        cvs.forEach((c, k) => { const x = c.getContext("2d"); x.setTransform(1, 0, 0, 1, 0, 0); x.clearRect(0, 0, c.width, c.height); x.imageSmoothingEnabled = false; x.setTransform(4, 0, 0, 4, 0, 0); drawCupAt(x, k, 9, 19, tt + k * 300); });
        const now = el.querySelector("#cafe-now"), dk = G.user.drink;
        if (now) now.textContent = dk && dk.until > serverNow_() ? t("cafeNow", { name: names[dk.k], left: leftText(dk.until - serverNow_()) }) : "";
        raf = requestAnimationFrame(paint);
      };
      paint();
      G.modalCleanup = () => cancelAnimationFrame(raf);
      el.querySelectorAll(".cafe-item button").forEach((b) => b.addEventListener("click", async () => {
        const k = +b.closest(".cafe-item").dataset.k;
        if ((G.user.coins | 0) < 5) return toast(t("e_coins"));
        b.disabled = true;
        try {
          const r = await API.cafeBuy(k);
          setUser(r.user); G.user.drink = r.user.drink || { k, until: serverNow_() + 240000 };
          try { SFX.coin(); } catch {}
          const st = scene() && scene().staff; if (st) { st.say = t("cafeThanks"); st.sayUntil = G.t + 3500; st.next = G.t + 8000; }
          closeModal(); toast(t("cafeBought", { name: names[k] })); kickSync();
        } catch (e) { toast(e.message); b.disabled = false; }
      }));
    }, true);
  }

  // ---------------- 🛍️ 젤리젤리샵 ----------------
  let shopTab = "all";
  function previewAv(it) {
    const av = { ...(G.user.avatar || Avatar.random()) };
    av[it.kind] = it.idx;
    if (it.kind === "outfit" && av.wand) av.wand = av.wand; // 마법봉은 그대로
    return av;
  }
  function openShop() {
    const html = `<div class="shop-top"><div class="coin-big">🪙 <b id="shop-coins">${(G.user.coins | 0).toLocaleString()}</b> <small>${esc(t("coinName"))}</small></div>
      <p>${esc(t("shopIntro"))}</p><p class="shop-how">${esc(t("shopHow"))}</p></div>
      <div class="chips shop-tabs">${["all", "hair", "outfit", "wand", "bubble", "fish"].map((k) => `<button class="chip ${k === shopTab ? "on" : ""}${k === "fish" ? " sell" : ""}" data-k="${k}">${esc(t({ all: "kAll", hair: "kHair", outfit: "kOutfit", wand: "kWand", bubble: "kBubble", fish: "sellTab" }[k]))}</button>`).join("")}</div>
      <div class="shop-grid" id="shop-grid"></div>`;
    openModal("🛍️ " + t("bShop"), html, (el) => {
      el.querySelectorAll(".shop-tabs .chip").forEach((b) => b.addEventListener("click", () => { shopTab = b.dataset.k; el.querySelectorAll(".shop-tabs .chip").forEach((x) => x.classList.toggle("on", x === b)); renderShop(); }));
      renderShop();
    }, true);
  }
  function renderShop() {
    const grid = $("#shop-grid"); if (!grid) return;
    grid.classList.toggle("sell-grid", shopTab === "fish");
    if (shopTab === "fish") return renderSellFish(grid); // 🐟 물고기 팔기
    const av = G.user.avatar || {};
    const KO = { hair: 0, outfit: 1, wand: 2, bubble: 3 };
    const list = SHOP.filter((it) => !it.staff && (shopTab === "all" || it.kind === shopTab)) // 관리자 전용 의상은 팔지 않음
      .sort((a, b) => KO[a.kind] - KO[b.kind] || a.price - b.price); // 종류별 · 가격순
    grid.innerHTML = list.map((it) => {
      const own = owns(it), on = (av[it.kind] | 0) === it.idx;
      const tier = it.price >= 100000 ? "t4 t6" : it.price >= 30000 ? "t4 t5" : it.price >= 12000 ? "t4" : it.price >= 5000 ? "t3" : it.price >= 1200 ? "t2" : "t1";
      const btn = !own ? `<button class="btn sm pink buy ${(G.user.coins | 0) < it.price ? "poor" : ""}" data-act="buy">🪙 ${it.price.toLocaleString()} ${esc(t("buy"))}</button>`
        : on ? (it.kind === "wand" ? `<button class="btn sm" data-act="off">${esc(t("unequip"))}</button>` : `<button class="btn sm on" disabled>${esc(t("equipped"))}</button>`)
        : `<button class="btn sm grape" data-act="wear">${esc(t("equip"))}</button>`;
      return `<div class="shop-item ${tier}${own ? " own" : ""}" data-id="${it.id}">
        <span class="kind">${esc(t({ hair: "kHair", outfit: "kOutfit", wand: "kWand", bubble: "kBubble" }[it.kind]))}</span>${own ? `<span class="owned">${esc(t("owned"))}</span>` : ""}
        <canvas width="96" height="96"></canvas><b>${esc(L(it.name))}</b><span class="price">🪙 ${it.price.toLocaleString()}</span>${btn}</div>`;
    }).join("");
    grid.querySelectorAll(".shop-item").forEach((card) => {
      const it = SHOP.find((x) => x.id === card.dataset.id);
      const c = card.querySelector("canvas"), x = c.getContext("2d");
      x.imageSmoothingEnabled = false;
      const pv = previewAv(it);
      let dirI = 0;
      const drawPv = it.kind === "bubble"
        ? () => { x.clearRect(0, 0, 96, 96); x.save(); x.scale(0.8, 0.8); drawBubbleOn(x, 60, 58, t("bubbleSample"), it.idx, performance.now()); x.restore(); x.drawImage(Avatar.sprite(pv, "down", 0), 12, 10, 26, 30, 30, 62, 36, 40); }
        : () => { x.clearRect(0, 0, 96, 96); x.drawImage(Avatar.sprite(pv, ["down", "right", "up", "left"][dirI % 4], 0), 0, 0, 96, 96); };
      drawPv();
      c.addEventListener("click", () => { dirI++; drawPv(); });
      const b = card.querySelector("[data-act]");
      if (!b) return;
      b.addEventListener("click", async () => {
        const act = b.dataset.act;
        if (act === "buy") {
          if ((G.user.coins | 0) < it.price) return toast(t("e_coins"));
          if (!b.classList.contains("sure")) { b.classList.add("sure"); b.textContent = t("buySure") + " 🪙" + it.price.toLocaleString(); setTimeout(() => { if (b.isConnected && b.classList.contains("sure")) { b.classList.remove("sure"); b.textContent = `🪙 ${it.price.toLocaleString()} ${t("buy")}`; } }, 3500); return; }
          b.disabled = true;
          try { const r = await API.buy(it.id); setUser(r.user); toast(t("bought", { name: L(it.name) })); { const st = scene() && scene().staff; if (st && st.thanksKey) { st.say = t(st.thanksKey); st.sayUntil = G.t + 3500; st.next = G.t + 8000; } } await wear(it); }
          catch (e) { toast(e.message); }
          renderShop();
          return;
        }
        b.disabled = true;
        try { await wear(it, act === "off"); } catch (e) { toast(e.message); }
        renderShop();
      });
    });
  }
  async function wear(it, off) {
    const av = { ...(G.user.avatar || Avatar.random()) };
    av[it.kind] = off ? 0 : it.idx;
    const u = await API.saveAvatar(G.user.nickname, av);
    setUser(u); kickSync();
    if (!off) toast(t("wearing", { name: L(it.name) }));
  }

  // ---------------- 🎹 피아노 연주 ----------------
  function openPiano(recordable) {
    stopMusic(); // 연주하는 동안 배경음악은 잠시 멈춤
    openModal(t("pianoTitle"), `<div id="pn-root"></div>`, (el) => {
      const pn = Piano.mount(el.querySelector("#pn-root"), {
        t, lang: I.lang, record: !!recordable, compact: IS_TOUCH && window.innerWidth < 1000, // 📱 휴대폰은 한 옥타브만 크게
        onPost: async (notes, title) => { try { const r = await API.recPost(notes, title); toast(t("recDone")); return r; } catch (e) { toast(e.message); throw e; } },
        onBoard: () => openRecBoard(),
      });
      G.modalCleanup = () => { pn.destroy(); sceneMusic(G.scene); };
      if (recordable) API.recList(0).then((r) => { const x = el.querySelector(".rc-left"); if (x) x.textContent = t("recLeft", { n: r.left > 3 ? "∞" : r.left }); }).catch(() => {});
    }, true);
    document.querySelector("#modal .modal").classList.add("piano");
  }

  // ---------------- 📼 젤리에게 들려줘! (피아노 녹음 게시판) ----------------
  let recStop = null;
  function openRecBoard(page = 0) {
    stopMusic();
    openModal("📼 " + t("recBoard"), `<p class="rec-intro">${esc(t("recBoardIntro"))}</p>
      <div class="rec-list" id="rec-list"><p class="gb-empty">…</p></div><div class="gb-pager" id="rec-pager"></div>
      <p style="text-align:center"><button class="btn sm pink" id="rec-go-piano">🎹 ${esc(t("recGoPiano"))}</button></p>`, (el) => {
      el.querySelector("#rec-go-piano").addEventListener("click", () => openPiano(true));
      G.modalCleanup = () => { if (recStop) { recStop(); recStop = null; } sceneMusic(G.scene); };
      loadRec(page);
    }, true);
  }
  async function loadRec(page) {
    const list = $("#rec-list"), pager = $("#rec-pager"); if (!list) return;
    try {
      const r = await API.recList(page);
      if (!r.entries.length) { list.innerHTML = `<p class="gb-empty">${esc(t("recEmptyList"))}</p>`; pager.innerHTML = ""; return; }
      list.innerHTML = r.entries.map((e, i) => `<div class="rec-item${e.role === "artist" ? " host" : ""}" data-key="${esc(e.key)}">
        <button class="btn rec-play" title="▶">▶</button>
        <canvas width="32" height="26" data-av='${esc(JSON.stringify(e.avatar || null))}'></canvas>
        <div class="rec-info"><b>${e.role === "artist" ? "✦ " : e.role === "admin" ? "★ " : ""}${esc(e.name)}</b>${e.title ? ` <span class="rec-title" title="${esc(e.title)}">「${esc(trPick(e.title, e.titleTr))}」</span>` : ""}<br>
          <small>🎵 ${e.notes.length} · ⏱ ${(Math.min(60000, e.len + 500) / 1000).toFixed(1)}s · ${fmtTime(e.ts)}</small></div>
        ${G.user && staff(G.user.role) ? `<button class="gb-del" title="${esc(t("del"))}">✕</button>` : ""}</div>`).join("");
      list.querySelectorAll("canvas[data-av]").forEach((c) => { try { const av = JSON.parse(c.dataset.av); if (av) Avatar.face(c.getContext("2d"), av, 32, 26); } catch {} });
      list.querySelectorAll(".rec-item").forEach((row, i) => {
        const e = r.entries[i], btn = row.querySelector(".rec-play");
        btn.addEventListener("click", () => {
          const playing = btn.classList.contains("on");
          if (recStop) { recStop(); recStop = null; }
          if (playing) return;
          btn.classList.add("on"); btn.textContent = "⏹";
          recStop = Piano.playSeq(e.notes, null, () => { btn.classList.remove("on"); btn.textContent = "▶"; });
        });
        const del = row.querySelector(".gb-del");
        if (del) del.addEventListener("click", async () => { try { await API.recDelete(e.key); loadRec(page); } catch (x) { toast(x.message); } });
      });
      const pages = Math.ceil(r.total / 15);
      pager.innerHTML = pages > 1 ? Array.from({ length: pages }, (_, i) => `<button class="chip ${i === page ? "on" : ""}" data-p="${i}">${i + 1}</button>`).join("") : "";
      pager.querySelectorAll("[data-p]").forEach((b) => b.addEventListener("click", () => { if (recStop) { recStop(); recStop = null; } loadRec(+b.dataset.p); }));
    } catch (x) { list.innerHTML = `<p class="gb-empty">${esc(x.message)}</p>`; }
  }

  // ---------------- 🏆 랭킹 1위 게시판 ----------------
  async function refreshRankTop() {
    if (!G.user) return;
    try { const r = await API.gameTop("all"); World.rankTops = { jump: r.jump || null, up: r.up || null, tet: r.tet || null, jx: r.jx || null }; } catch {}
  }
  setInterval(() => { if (G.mode === "world" && G.scene === "plaza" && !document.hidden) refreshRankTop(); }, 60000);
  function openRankBoard() {
    openModal("🏆 " + t("rankBoardZ"), `<div class="chips shop-tabs rk-tabs"><button class="chip on" data-g="jump">🏃 ${esc(t("gameTitle"))}</button><button class="chip" data-g="up">⬆️ ${esc(t("upTitle"))}</button><button class="chip" data-g="tet">🧱 ${esc(t("tgTitle"))}</button><button class="chip" data-g="jx">🍬 ${esc(t("jxTitle"))}</button></div>
      <div id="jg-rank" class="jg-rank rank-modal"><div class="rk-list"><p class="rk-empty">…</p></div></div>
      <p style="text-align:center"><button class="btn sm pink" id="rk-go-game">🎮 ${esc(t("bGame"))}</button></p>`, (el) => {
      let g = "jump";
      const load = () => (rankGame = g, API.gameTop(g)).then((r) => renderRank(r.top || [])).catch(() => renderRank([]));
      el.querySelectorAll(".rk-tabs .chip").forEach((b) => b.addEventListener("click", () => { g = b.dataset.g; el.querySelectorAll(".rk-tabs .chip").forEach((x) => x.classList.toggle("on", x === b)); el.querySelector(".rk-list").innerHTML = "<p class='rk-empty'>…</p>"; load(); }));
      el.querySelector("#rk-go-game").addEventListener("click", () => openGame());
      load();
    });
  }

  // ---------------- 🔮 오늘의 운세 ----------------
  function fortuneBox(el, openNow) {
    const box = document.createElement("div"); box.className = "ft-box";
    let saved = ""; try { saved = localStorage.getItem("jl_birth") || ""; } catch {}
    box.innerHTML = `<button class="btn pink ft-open">${esc(t("ftBtn"))}</button>
      <div class="ft-form hidden"><label>${esc(t("ftBirth"))}</label><input type="date" class="inp ft-date" min="1900-01-01" max="${Fortune.today()}" value="${esc(saved)}"><button class="btn grape ft-go">${esc(t("ftGo"))}</button></div>
      <div class="ft-result hidden"></div>`;
    el.appendChild(box);
    if (openNow) { box.querySelector(".ft-open").classList.add("hidden"); box.querySelector(".ft-form").classList.remove("hidden"); }
    const form = box.querySelector(".ft-form"), res = box.querySelector(".ft-result"), inp = box.querySelector(".ft-date");
    box.querySelector(".ft-open").addEventListener("click", () => { form.classList.toggle("hidden"); res.classList.add("hidden"); if (!form.classList.contains("hidden")) box.scrollIntoView({ block: "nearest", behavior: "smooth" }); });
    box.querySelector(".ft-go").addEventListener("click", () => {
      const v = inp.value;
      if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) return toast(t("ftNeed"));
      try { localStorage.setItem("jl_birth", v); } catch {}
      const f = Fortune.make(v, I.lang);
      const star = (n) => "★".repeat(n) + "☆".repeat(5 - n);
      res.innerHTML = `<h3>${esc(t("ftTitle"))}</h3><p class="ft-for">${esc(t("ftFor", { date: Fortune.today(), sign: f.sign, animal: f.animal }))}</p>
        <p class="ft-msg">${esc(f.msg)}</p>
        <div class="ft-grid"><span>${esc(t("ftTotal"))}</span><b>${star(f.total)}</b><span>${esc(t("ftLove"))}</span><b>${star(f.love)}</b>
        <span>${esc(t("ftMoney"))}</span><b>${star(f.money)}</b><span>${esc(t("ftHealth"))}</span><b>${star(f.health)}</b></div>
        <div class="ft-lucky"><div><small>${esc(t("ftLuckyColor"))}</small><b><i style="background:${f.color}"></i>${esc(f.colorName)}</b></div>
        <div><small>${esc(t("ftLuckyNum"))}</small><b>${f.num}</b></div><div><small>${esc(t("ftLuckySong"))}</small><b>🎹 ${esc(f.song)}</b></div></div>`;
      res.classList.remove("hidden"); form.classList.add("hidden");
      box.querySelector(".ft-open").textContent = t("ftAgain"); box.querySelector(".ft-open").classList.remove("hidden");
      res.scrollIntoView({ block: "nearest", behavior: "smooth" });
    });
  }

  // ---------------- 🎮 젤리게임월드: 점프점프 젤리월드 ----------------
  // 기록 저장이 실패하면(인터넷 끊김 등) 휴대폰에 보관했다가 다음에 다시 보내요
  function savePendingRun(run, m) { try { const a = JSON.parse(localStorage.getItem("jl_pending_runs") || "[]"); a.push({ run, m, uid: G.user.id }); localStorage.setItem("jl_pending_runs", JSON.stringify(a.slice(-10))); } catch {} }
  async function flushPendingRuns() {
    let a = []; try { a = JSON.parse(localStorage.getItem("jl_pending_runs") || "[]"); } catch {}
    if (!a.length || !G.user) return;
    const keep = [];
    for (const p of a) {
      if (p.uid !== G.user.id) { keep.push(p); continue; }
      try { const r = await API.gameFinish(p.run, p.m); if (r.user) setUser(r.user); if (r.rank) toast(t("rankNew", { n: r.rank })); }
      catch (e) { if (e.status !== 400 && e.status !== 403) keep.push(p); }
    }
    try { localStorage.setItem("jl_pending_runs", JSON.stringify(keep)); } catch {}
    refreshRankTop();
  }
  // 젤리게임월드: 게임 선택 → 점프점프 젤리월드 / 올라올라 / 오늘의 운세
  function openGame(pick) {
    G.gameOpen = true;
    stopMusic(); BGM.play("minigame");
    openModal("🎮 " + t("bGame"), `<div id="gw-root"></div>`, (el) => {
      let cur = null;
      const root = el.querySelector("#gw-root");
      const stop = () => { if (cur) { cur.destroy(); cur = null; } };
      G.modalCleanup = () => { stop(); Chip.stop(); G.gameOpen = false; sceneMusic(G.scene); };
      const setTitle = (s2) => ($("#modal-title").textContent = s2);
      function menu() {
        stop(); setTitle("🎮 " + t("bGame"));
        Chip.stop(); BGM.play("minigame"); // 선택 화면: 미니게임 BGM
        document.querySelector("#modal .modal").classList.remove("up");
        root.innerHTML = `<p class="gw-intro">${esc(t("gwIntro"))}</p><div class="gw-menu">
          <button class="gw-card jump" data-g="jump"><span class="gw-ico">🏃</span><b>${esc(t("gameTitle"))}</b><small>${esc(t("gwJump"))}</small></button>
          <button class="gw-card up" data-g="up"><span class="gw-ico">⬆️</span><b>${esc(t("upTitle"))}</b><small>${esc(t("gwUp"))}</small></button>
          <button class="gw-card tet" data-g="tet"><span class="gw-ico">🧱</span><b>${esc(t("tgTitle"))}</b><small>${esc(t("gwTet"))}</small></button>
          <button class="gw-card jx" data-g="jx"><span class="gw-ico">🍬</span><b>${esc(t("jxTitle"))}</b><small>${esc(t("gwJx"))}</small></button>
          <button class="gw-card lucky" data-g="slot"><span class="gw-ico">🎰</span><b>${esc(t("slTitle"))}</b><small>${esc(t("gwSlot"))}</small></button>
          <button class="gw-card ft" data-g="fortune"><span class="gw-ico">🔮</span><b>${esc(t("ftBtn").replace(/^🔮\s*/, ""))}</b><small>${esc(t("gwFortune"))}</small></button></div>
          <p class="gw-day">🪙 ${esc(t("gameDayLeft", { n: G.user.gameLeft ?? 600 }))}</p>`;
        root.querySelectorAll("[data-g]").forEach((b) => b.addEventListener("click", () => go(b.dataset.g)));
      }
      const backBtn = () => `<p class="gw-back"><button class="btn sm" id="gw-back">◀ ${esc(t("gwBack"))}</button></p>`;
      function go(g) {
        stop();
        BGM.stop(); Chip.play(g); // 게임마다 전용 BGM (광장·미니게임 BGM 은 끔)
        if (g === "fortune") {
          setTitle(t("ftTitle"));
          root.innerHTML = backBtn() + `<div id="gw-play"></div>`;
          root.querySelector("#gw-back").addEventListener("click", menu);
          fortuneBox(root.querySelector("#gw-play"), true);
          return;
        }
        if (g === "slot") {
          setTitle("🎰 " + t("slTitle"));
          root.innerHTML = backBtn() + `<div id="gw-play"></div>`;
          root.querySelector("#gw-back").addEventListener("click", menu);
          cur = LuckyJelly.mount(root.querySelector("#gw-play"), {
            t, toast, coins: () => G.user.coins | 0, left: () => (G.user.slotLeft ?? 20),
            onSpin: async () => { const r = await API.slotSpin(); G.user.coins = (r.user.coins | 0) - (r.payout | 0); G.user.slotLeft = r.user.slotLeft; renderCoins(); G._slotUser = r.user; return r; },
            onResult: () => { if (G._slotUser) { setUser(G._slotUser); G._slotUser = null; } },
          });
          return;
        }
        const up = g === "up", tet = g === "tet", jx = g === "jx";
        setTitle((jx ? "🍬 " : tet ? "🧱 " : up ? "⬆️ " : "🏃 ") + t(jx ? "jxTitle" : tet ? "tgTitle" : up ? "upTitle" : "gameTitle"));
        document.querySelector("#modal .modal").classList.toggle("up", up || tet || jx);
        root.innerHTML = backBtn() + `<div id="gw-play"></div><div id="jg-rank" class="jg-rank"><h3>${esc(t(jx ? "jxRankTitle" : tet ? "tgRankTitle" : up ? "upRankTitle" : "rankTitle"))}</h3><div class="rk-list"><p class="rk-empty">…</p></div></div>`;
        root.querySelector("#gw-back").addEventListener("click", menu);
        rankGame = g;
        const Game = jx ? JellyXGame : tet ? TetrisGame : up ? UpGame : JumpGame;
        cur = Game.mount(root.querySelector("#gw-play"), {
          t, avatar: () => G.user.avatar, dayLeft: G.user.gameLeft,
          onStart: () => API.gameStart(g),
          onFinish: async (run, m) => {
            let r;
            try { r = await API.gameFinish(run, m); }
            catch (e) { if (e.status !== 400 && e.status !== 403) { savePendingRun(run, m); toast(t("gameSaveLater")); } throw e; }
            if (r.user) setUser(r.user);
            if (r.top) { renderRank(r.top); World.rankTops = World.rankTops || {}; World.rankTops[g] = r.top[0] || null; }
            if (r.rank) setTimeout(() => toast(t("rankNew", { n: r.rank })), 600);
            return r;
          },
        });
        API.gameTop(g).then((r) => renderRank(r.top || [])).catch(() => renderRank([]));
      }
      if (pick) go(pick); else menu();
    }, true);
    document.querySelector("#modal .modal").classList.add("game");
  }

  // 랭킹 TOP 10 (점프점프·올라올라는 m, 젤리 블록은 점)
  let rankGame = "jump";
  const rankUnit = (g) => (g === "tet" || g === "jx" ? " " + t("ptsUnit") : " m");
  function renderRank(top) {
    const list = document.querySelector("#jg-rank .rk-list"); if (!list) return;
    if (!top.length) { list.innerHTML = `<p class="rk-empty">${esc(t("rankEmpty"))}</p>`; return; }
    const medal = ["🥇", "🥈", "🥉"];
    list.innerHTML = top.map((e, i) => `<div class="rk-row${G.user && e.id === G.user.id ? " me" : ""}${e.role === "artist" ? " host" : ""}">
      <span class="rk-no">${medal[i] || i + 1}</span><canvas width="32" height="26" data-av='${esc(JSON.stringify(e.avatar || null))}'></canvas>
      <b>${e.role === "artist" ? "✦ " : ""}${esc(e.name)}</b><span class="rk-m">${Number(e.m).toLocaleString()}${rankUnit(rankGame)}</span></div>`).join("");
    list.querySelectorAll("canvas[data-av]").forEach((c) => { try { Avatar.face(c.getContext("2d"), JSON.parse(c.dataset.av), 32, 26); } catch {} });
  }

  // ---------------- ✉️ 쪽지함 ----------------
  let mailUnread = 0, mailBox = [];
  async function loadMail(first) {
    if (!G.user || G.mode !== "world") return;
    try {
      const r = await API.mail();
      mailBox = r.box || [];
      const n = r.unread | 0;
      if (n > mailUnread && !first) { toast(t("mailNew")); API.me().then((u) => setUser(u)).catch(() => {}); }
      else if (n > 0 && first) setTimeout(() => toast(t("mailNew")), 8000);
      mailUnread = n; renderMailBadge();
      if (document.querySelector("#mail-list")) renderMailList();
    } catch {}
  }
  setInterval(() => { if (!document.hidden) loadMail(); }, 60000);
  function renderMailBadge() { for (const b of [$("#mail-badge"), $("#menu-badge")]) { b.textContent = mailUnread > 9 ? "9+" : mailUnread; b.classList.toggle("hidden", !mailUnread); } }
  // ---------------- ☰ 메뉴 (코인 · 📸 · 🔊 빼고 전부 이 안에) ----------------
  function toggleMenu(open) {
    const l = $("#menu-list"), on = open ?? l.classList.contains("hidden");
    l.classList.toggle("hidden", !on); $("#btn-menu").setAttribute("aria-expanded", on); $("#btn-menu").classList.toggle("on", on);
  }
  $("#btn-menu").addEventListener("click", (e) => { e.stopPropagation(); toggleMenu(); });
  $("#menu-list").addEventListener("click", (e) => { if (e.target.closest("button")) toggleMenu(false); });
  document.addEventListener("pointerdown", (e) => { if (!e.target.closest(".menu-wrap")) toggleMenu(false); });
  window.addEventListener("keydown", (e) => { if (e.key === "Escape") toggleMenu(false); });
  function openMail() {
    openModal(t("mailTitle"), `<div id="mail-list" class="mail-list"></div>`, () => {
      renderMailList();
      if (mailUnread) { API.mailRead().catch(() => {}); mailUnread = 0; renderMailBadge(); }
      loadMail();
    }, true);
  }
  function renderMailList() {
    const el = $("#mail-list"); if (!el) return;
    if (!mailBox.length) { el.innerHTML = `<p class="gb-empty">${esc(t("mailEmpty"))}</p>`; return; }
    el.innerHTML = mailBox.map((m) => `<div class="mail-item${m.read ? "" : " unread"}" data-ts="${m.ts}">
      <div class="mail-head"><b class="${m.fromRole === "artist" ? "host" : "adm"}">${m.fromRole === "artist" ? "✦" : "★"} ${esc(m.from)}</b>
      <span class="role">${esc(t(m.fromRole === "artist" ? "roleArtist" : "roleAdmin"))}${m.all ? " · " + esc(t("mailAll")) : ""}</span>
      <span class="when">${fmtTime(m.ts)}</span><button class="gb-del" title="${esc(t("del"))}">✕</button></div>
      <div class="mail-text">${trBlock(m.text, m.tr)}</div></div>`).join("");
    el.querySelectorAll(".mail-item .gb-del").forEach((b) => b.addEventListener("click", async () => {
      const ts = +b.closest(".mail-item").dataset.ts;
      try { const r = await API.mailDelete(ts); mailBox = r.box || []; renderMailList(); } catch (e) { toast(e.message); }
    }));
  }
  $("#btn-mail").addEventListener("click", openMail);
  $("#btn-aqua").addEventListener("click", () => openAquarium()); // 🐠 내 어항

  // ---------------- 🛠 관리자: 회원관리 ----------------
  let adminUsers = [];
  function openAdmin() {
    if (!G.user || !staff(G.user.role)) return;
    openModal(t("adminTitle"), `<div class="adm-top"><input class="inp" id="adm-q" placeholder="${esc(t("adminSearch"))}"><span id="adm-count"></span>
      <button class="btn sm grape" id="adm-all">${esc(t("adminAll"))}</button><button class="btn sm" id="adm-pwreq">🔑 ${esc(t("pwReqBtn"))} <span class="badge hidden" id="adm-pwreq-n">0</span></button></div>
      <div class="adm-pwreq hidden" id="adm-pwreq-box"></div>
      <div class="adm-compose hidden" id="adm-compose-all"><textarea id="adm-all-text" maxlength="500" rows="3" placeholder="${esc(t("adminMsgPh"))}"></textarea><button class="btn sm pink" id="adm-all-send">${esc(t("adminSend"))}</button></div>
      <div class="adm-list" id="adm-list"><p class="gb-empty">…</p></div>`, (el) => {
      el.querySelector("#adm-q").addEventListener("input", renderAdmin);
      el.querySelector("#adm-all").addEventListener("click", () => el.querySelector("#adm-compose-all").classList.toggle("hidden"));
      el.querySelector("#adm-all-send").addEventListener("click", async (e) => {
        const ta = el.querySelector("#adm-all-text"), text = ta.value.trim(); if (!text) return;
        e.target.disabled = true;
        try { const r = await API.adminMail("all", text); ta.value = ""; el.querySelector("#adm-compose-all").classList.add("hidden"); toast(t("adminSent", { n: r.sent })); loadMail(); }
        catch (x) { toast(x.message); } finally { e.target.disabled = false; }
      });
      el.querySelector("#adm-pwreq").addEventListener("click", () => { const b = el.querySelector("#adm-pwreq-box"); b.classList.toggle("hidden"); if (!b.classList.contains("hidden")) loadPwReqs(); });
      loadPwReqs(true);
      API.adminUsers().then((r) => { adminUsers = r.users || []; renderAdmin(); }).catch((x) => { el.querySelector("#adm-list").innerHTML = `<p class="gb-empty">${esc(x.message)}</p>`; });
    }, true);
  }
  // 🔑 비밀번호 찾기 요청 (본인 확인 후 승인 → 요청한 기기에서 새 비밀번호 설정)
  async function loadPwReqs(countOnly) {
    let r; try { r = await API.adminPwResets(); } catch (x) { if (!countOnly) toast(x.message); return; }
    const reqs = r.requests || [], pending = reqs.filter((q) => q.status === "pending").length;
    const nb = $("#adm-pwreq-n"); if (nb) { nb.textContent = pending; nb.classList.toggle("hidden", !pending); }
    if (countOnly) return;
    const box = $("#adm-pwreq-box"); if (!box) return;
    const stName = (s) => t(s === "pending" ? "pwStPending" : s === "approved" ? "pwStApproved" : "pwStRejected");
    box.innerHTML = `<p class="adm-pw-tip">${esc(t("pwReqTip"))}</p>` + (reqs.length ? reqs.map((q, i) => {
      const match = q.account && q.account.nickname === q.nick;
      return `<div class="adm-pw-row st-${q.status}" data-i="${i}">
        <div><b>${esc(q.nick)}</b> · <small>${esc(q.email)}</small> <span class="adm-pw-st">${esc(stName(q.status))}</span><br>
        <small>${q.account ? `${esc(t("pwReqAccount"))}: <b>${esc(q.account.nickname || "—")}</b> ${match ? "✅" : "⚠️ " + esc(t("pwReqMismatch"))}` : "❌ " + esc(t("pwReqNoAcc"))} · ${esc(fmtTime(q.ts))}</small>
        ${q.note ? `<div class="adm-pw-note">💬 ${trBlock(q.note, q.noteTr)}</div>` : ""}
        ${(q.sameNick || []).map((a, j) => `<div class="adm-pw-same" data-j="${j}">👤 ${esc(t("pwSameNick"))}: <b>${esc(a.email)}</b> <small>(${a.createdAt ? esc(fmtTime(a.createdAt).slice(0, 10)) : "-"})</small>
          ${!q.account ? `<button class="btn sm grape" data-s="mv">✉️ ${esc(t("pwFixEmail", { email: q.email }))}</button>` : ""}<button class="btn sm" data-s="tmp">🔑 ${esc(t("pwTempBtn"))}</button><div class="adm-pwout hidden"></div></div>`).join("")}</div>
        <div class="adm-pw-act">${q.status === "pending" && q.account ? `<button class="btn sm pink" data-d="1">${esc(t("pwApprove"))}</button><button class="btn sm" data-d="0">${esc(t("pwReject"))}</button>` : ""}<button class="btn sm kick" data-d="del">✕</button></div></div>`;
    }).join("") : `<p class="gb-empty">${esc(t("pwReqEmpty"))}</p>`);
    // 같은 닉네임 계정: 아이디(이메일)를 요청한 이메일로 고치거나, 바로 임시 비밀번호 만들기
    box.querySelectorAll(".adm-pw-same [data-s]").forEach((b) => b.addEventListener("click", async () => {
      const q = reqs[+b.closest(".adm-pw-row").dataset.i], wrap = b.closest(".adm-pw-same"), a = q.sameNick[+wrap.dataset.j];
      if (!b.classList.contains("sure")) { b.classList.add("sure"); b.dataset.label = b.textContent; b.textContent = t("adminKickSure"); setTimeout(() => { if (b.isConnected) { b.classList.remove("sure"); b.textContent = b.dataset.label; } }, 4000); return; }
      b.disabled = true;
      try {
        if (b.dataset.s === "mv") { await API.adminEmail(a.id, q.email); toast(t("pwEmailFixed", { email: q.email })); loadPwReqs(); API.adminUsers().then((r) => { adminUsers = r.users || []; renderAdmin(); }).catch(() => {}); return; }
        const r = await API.adminTempPw(a.id);
        showTempPw(wrap.querySelector(".adm-pwout"), q.nick, r);
        b.classList.remove("sure"); b.textContent = b.dataset.label;
      } catch (x) { toast(x.message); } finally { b.disabled = false; }
    }));
    box.querySelectorAll(".adm-pw-row [data-d]").forEach((b) => b.addEventListener("click", async () => {
      const q = reqs[+b.closest(".adm-pw-row").dataset.i], d = b.dataset.d;
      b.disabled = true;
      try { await API.adminPwDecide(q.email, d === "del" ? "delete" : d === "1"); toast(d === "1" ? t("pwApproved", { name: q.nick }) : d === "0" ? t("pwRejectedT") : t("del")); loadPwReqs(); }
      catch (x) { toast(x.message); b.disabled = false; }
    }));
  }
  function showTempPw(out, name, r) {
    out.innerHTML = `${esc(t("pwTempDone", { name }))}<div class="pw-code"><span>${esc(t("pwLoginId"))}</span><code class="id">${esc(r.email)}</code></div><div class="pw-code"><span>${esc(t("password"))}</span><code>${esc(r.password)}</code><button class="btn sm" type="button">${esc(t("copy"))}</button></div><small>${esc(t("pwTempHint"))}</small>`;
    out.classList.remove("hidden");
    out.querySelector("button").addEventListener("click", () => { try { navigator.clipboard.writeText(`${r.email} / ${r.password}`); toast(t("copied")); } catch {} });
  }
  function renderAdmin() {
    const el = $("#adm-list"); if (!el) return;
    const q = ($("#adm-q").value || "").trim().toLowerCase();
    const list = adminUsers.filter((u) => !q || (u.nickname || "").toLowerCase().includes(q) || (u.email || "").toLowerCase().includes(q));
    $("#adm-count").textContent = t("adminCount", { n: adminUsers.length });
    const roleName = (r) => t(r === "artist" ? "roleArtist" : r === "admin" ? "roleAdmin" : "roleFan");
    el.innerHTML = list.map((u) => `<div class="adm-row" data-id="${esc(u.id)}">
      <canvas width="32" height="26" data-av='${esc(JSON.stringify(u.avatar || null))}'></canvas>
      <div class="adm-info"><b>${esc(u.nickname || "—")}</b> <span class="adm-role r-${u.role}">${esc(roleName(u.role))}</span><br>
        <small>${esc(u.email)} · ${esc(t("adminJoined"))} ${u.createdAt ? fmtTime(u.createdAt).slice(0, 10) : "-"} · 🪙 ${(u.coins | 0).toLocaleString()}<br>🏃 ${(u.best | 0).toLocaleString()}m · 🪜 ${(u.bestUp | 0).toLocaleString()}m · 🧱 ${(u.bestTet | 0).toLocaleString()}${esc(t("ptsUnit"))}</small></div>
      <div class="adm-act"><button class="btn sm coin" data-act="coin">${esc(t("adminCoin"))}</button><button class="btn sm" data-act="rank">${esc(t("adminRank"))}</button><button class="btn sm" data-act="msg">${esc(t("adminMsg"))}</button><button class="btn sm" data-act="pw">🔑</button>${staff(u.role) ? "" : `<button class="btn sm" data-act="email" title="${esc(t("pwEmailBtn"))}">✉️ ID</button>`}${staff(u.role) ? "" : `<button class="btn sm kick" data-act="kick">${esc(t("adminKick"))}</button>`}</div>
      <div class="adm-pwout hidden"></div>
      <div class="adm-email hidden"><input class="inp" type="email" autocapitalize="off" value="${esc(u.email)}"><button class="btn sm pink" data-em="save">${esc(t("pwEmailSave"))}</button><small>${esc(t("pwEmailHint"))}</small></div>
      <div class="adm-coin hidden"><input class="inp" type="number" min="0" step="10" inputmode="numeric" placeholder="${esc(t("adminCoinPh"))}">
        <button class="btn sm pink" data-mode="add">${esc(t("adminCoinAdd"))}</button><button class="btn sm" data-mode="sub">${esc(t("adminCoinSub"))}</button><button class="btn sm grape" data-mode="set">${esc(t("adminCoinSet"))}</button></div>
      <div class="adm-rank hidden"><select class="inp"><option value="jump">🏃 ${esc(t("rkJump"))}</option><option value="up">🪜 ${esc(t("upTitle"))}</option><option value="tet">🧱 ${esc(t("tgTitle"))}</option><option value="jx">🍬 ${esc(t("jxTitle"))}</option></select>
        <input class="inp" type="number" min="0" step="1" inputmode="numeric" placeholder="${esc(t("adminRankPh"))}" value="${u.best | 0}">
        <button class="btn sm pink" data-rk="save">${esc(t("adminRankSave"))}</button><button class="btn sm kick" data-rk="remove">${esc(t("adminRankDel"))}</button></div>
      <div class="adm-compose hidden"><textarea maxlength="500" rows="3" placeholder="${esc(t("adminMsgPh"))}"></textarea><button class="btn sm pink" data-act="send">${esc(t("adminSend"))}</button></div></div>`).join("");
    el.querySelectorAll("canvas[data-av]").forEach((c) => { try { const av = JSON.parse(c.dataset.av); if (av) Avatar.face(c.getContext("2d"), av, 32, 26); } catch {} });
    el.querySelectorAll(".adm-row").forEach((row) => {
      const u = adminUsers.find((x) => x.id === row.dataset.id);
      row.querySelector("[data-act=msg]").addEventListener("click", () => row.querySelector(".adm-compose").classList.toggle("hidden"));
      row.querySelector("[data-act=coin]").addEventListener("click", () => { row.querySelector(".adm-coin").classList.toggle("hidden"); row.querySelector(".adm-coin input").focus(); });
      row.querySelectorAll(".adm-coin [data-mode]").forEach((b) => b.addEventListener("click", async () => {
        const n = Math.floor(+row.querySelector(".adm-coin input").value || 0); if (!n && b.dataset.mode !== "set") return;
        const mode = b.dataset.mode === "set" ? "set" : "add", amount = b.dataset.mode === "sub" ? -Math.abs(n) : Math.abs(n);
        b.disabled = true;
        try {
          const r = await API.adminCoins(u.id, mode, amount);
          u.coins = r.coins; if (r.user) setUser(r.user);
          toast(t("adminCoinDone", { name: u.nickname || u.email, n: r.coins.toLocaleString() })); renderAdmin();
        } catch (x) { toast(x.message); b.disabled = false; }
      }));
      const rk = row.querySelector(".adm-rank"), rkSel = rk.querySelector("select"), rkIn = rk.querySelector("input");
      row.querySelector("[data-act=rank]").addEventListener("click", () => { rk.classList.toggle("hidden"); rkIn.focus(); });
      const BK = { jump: "best", up: "bestUp", tet: "bestTet", jx: "bestJx" };
      rkSel.addEventListener("change", () => { rkIn.value = u[BK[rkSel.value]] | 0; });
      rk.querySelectorAll("[data-rk]").forEach((b) => b.addEventListener("click", async () => {
        const game = rkSel.value, remove = b.dataset.rk === "remove";
        const m = Math.floor(+rkIn.value || 0); if (!remove && !(m >= 0)) return;
        if (remove && !b.classList.contains("sure")) { b.classList.add("sure"); b.textContent = t("adminKickSure"); setTimeout(() => { if (b.isConnected) { b.classList.remove("sure"); b.textContent = t("adminRankDel"); } }, 4000); return; }
        b.disabled = true;
        try {
          const r = await API.adminRank(game, u.id, m, remove ? "remove" : undefined);
          u[BK[game]] = r.m;
          if (u.id === G.user.id) { try { setUser(await API.me()); } catch {} }
          if (typeof refreshRankTop === "function") refreshRankTop();
          toast(t(r.m > 0 ? "adminRankDone" : "adminRankRemoved", { name: u.nickname || u.email, game: t(game === "jx" ? "jxTitle" : game === "tet" ? "tgTitle" : game === "up" ? "upTitle" : "rkJump"), m: r.m.toLocaleString() + (game === "tet" || game === "jx" ? t("ptsUnit") : "m"), r: r.rank || "-" }));
          renderAdmin();
        } catch (x) { toast(x.message); b.disabled = false; }
      }));
      row.querySelector("[data-act=send]").addEventListener("click", async (e) => {
        const ta = row.querySelector("textarea"), text = ta.value.trim(); if (!text) return;
        e.target.disabled = true;
        try { await API.adminMail(u.id, text); ta.value = ""; row.querySelector(".adm-compose").classList.add("hidden"); toast(t("adminSent", { n: 1 })); }
        catch (x) { toast(x.message); } finally { e.target.disabled = false; }
      });
      // ✉️ 로그인 아이디(이메일) 바꾸기
      const eb = row.querySelector("[data-act=email]");
      if (eb) {
        eb.addEventListener("click", () => row.querySelector(".adm-email").classList.toggle("hidden"));
        row.querySelector("[data-em=save]").addEventListener("click", async (e) => {
          const v = row.querySelector(".adm-email input").value.trim().toLowerCase(); if (!v || v === u.email) return;
          e.target.disabled = true;
          try { await API.adminEmail(u.id, v); u.email = v; toast(t("pwEmailFixed", { email: v })); renderAdmin(); }
          catch (x) { toast(x.message); e.target.disabled = false; }
        });
      }
      // 🔑 임시 비밀번호 만들기 (두 번 눌러 확인)
      const pb = row.querySelector("[data-act=pw]");
      pb.title = t("pwTempBtn");
      pb.addEventListener("click", async () => {
        if (!pb.classList.contains("sure")) { pb.classList.add("sure"); pb.textContent = "🔑 " + t("pwTempSure"); setTimeout(() => { if (pb.isConnected) { pb.classList.remove("sure"); pb.textContent = "🔑"; } }, 4000); return; }
        pb.disabled = true;
        try {
          const r = await API.adminTempPw(u.id);
          showTempPw(row.querySelector(".adm-pwout"), u.nickname || u.email, r);
          pb.classList.remove("sure"); pb.textContent = "🔑";
        } catch (x) { toast(x.message); } finally { pb.disabled = false; }
      });
      const kb = row.querySelector("[data-act=kick]");
      if (kb) kb.addEventListener("click", async () => {
        if (!kb.classList.contains("sure")) { kb.classList.add("sure"); kb.textContent = t("adminKickSure"); setTimeout(() => { if (kb.isConnected) { kb.classList.remove("sure"); kb.textContent = t("adminKick"); } }, 4000); return; }
        kb.disabled = true;
        try { await API.adminDelete(u.id); adminUsers = adminUsers.filter((x) => x.id !== u.id); toast(t("adminKicked", { name: u.nickname || u.email })); renderAdmin(); }
        catch (x) { toast(x.message); kb.disabled = false; }
      });
    });
  }
  $("#btn-admin").addEventListener("click", openAdmin);

  // ---------------- ✨ 새 버전 알림 ----------------
  async function checkVersion() {
    try {
      const r = await fetch("version.json?" + Date.now(), { cache: "no-store" });
      const d = await r.json();
      if (d && d.v && String(d.v) !== APP_VERSION) showUpdateBar();
    } catch {}
  }
  function showUpdateBar() {
    if ($("#update-bar")) return;
    const b = document.createElement("div"); b.id = "update-bar"; b.className = "win";
    b.innerHTML = `<span>${esc(t("newVersion"))}</span><button class="btn sm pink">${esc(t("reload"))}</button>`;
    b.querySelector("button").addEventListener("click", () => location.reload());
    document.body.appendChild(b);
  }
  setInterval(() => { if (!document.hidden) checkVersion(); }, 120000);
  document.addEventListener("visibilitychange", () => { if (!document.hidden) checkVersion(); });

  // ---------------- 🔔 푸시 알림 (조젤리 입장 · 새 쪽지) ----------------
  const pushSupported = () => "serviceWorker" in navigator && "PushManager" in window && "Notification" in window;
  const b64ToBytes = (s) => { const p = "=".repeat((4 - (s.length % 4)) % 4), b = atob((s + p).replace(/-/g, "+").replace(/_/g, "/")); return Uint8Array.from(b, (c) => c.charCodeAt(0)); };
  async function subscribePush() {
    const reg = await navigator.serviceWorker.ready;
    let sub = await reg.pushManager.getSubscription();
    if (!sub) {
      const { key } = await API.pushKey(); if (!key) throw new Error("demo");
      sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64ToBytes(key) });
    }
    await API.pushSub(sub.toJSON());
  }
  async function pushOnEnter() {
    if (API.demo) return;
    // 호스트가 들어오면 알림을 켠 모든 회원에게 "Jo Jelly 등장!" (서버에서 30분에 한 번만)
    if (G.user.role === "artist") API.pushHost().catch(() => {});
    if (!pushSupported()) return;
    if (Notification.permission === "granted") { subscribePush().catch(() => {}); return; } // 이 계정으로 다시 연결
    // 홈 화면 앱(또는 안드로이드)에서 아직 안 물어봤으면 알림 켜기 안내
    const ios = document.body.classList.contains("ios");
    let asked = false; try { asked = !!localStorage.getItem("jl_push_asked"); } catch {}
    if (Notification.permission === "default" && !asked && IS_TOUCH && (isStandalone() || !ios)) setTimeout(() => { if (!G.modalOpen && G.mode === "world") openPushSetup(); }, 12000);
  }
  function openPushSetup(custom) {
    try { localStorage.setItem("jl_push_asked", "1"); } catch {}
    const ios = document.body.classList.contains("ios");
    let state = "ok", note = "";
    if (!pushSupported()) { state = "no"; note = ios && !isStandalone() ? t("pushNeedInstall") : t("pushUnsupported"); }
    else if (Notification.permission === "denied") { state = "denied"; note = t("pushDenied"); }
    else if (Notification.permission === "granted") note = t("pushAlready");
    openModal(custom ? custom.title : t("pushTitle"), `<div class="install${custom && custom.spooky ? " spooky" : ""}"><div class="push-bell">${custom ? custom.icon : "🔔"}</div><p>${esc(custom ? custom.intro : t("pushIntro"))}</p>
      ${state === "ok" ? `<button class="btn pink" id="push-on">${esc(t("pushOn"))}</button>` : ""}
      ${note ? `<p class="push-note">${esc(note)}</p>` : ""}${state === "no" && ios ? `<button class="btn sm" id="push-install">${esc(t("installHelp"))}</button>` : ""}</div>`, (el) => {
      const on = el.querySelector("#push-on");
      if (on) on.addEventListener("click", async () => {
        on.disabled = true;
        try {
          const p = await Notification.requestPermission();
          if (p !== "granted") { toast(t("pushDenied")); on.disabled = false; return; }
          await subscribePush(); toast(t("pushDone")); closeModal();
        } catch (e) { toast(e.message === "demo" ? t("pushUnsupported") : t("err")); on.disabled = false; }
      });
      const ib = el.querySelector("#push-install"); if (ib) ib.addEventListener("click", openInstall);
    });
  }

  // ---------------- 📲 홈 화면에 앱 추가 ----------------
  let installEvt = null;
  window.addEventListener("beforeinstallprompt", (e) => { e.preventDefault(); installEvt = e; });
  const isStandalone = () => window.matchMedia("(display-mode: standalone)").matches || window.matchMedia("(display-mode: fullscreen)").matches || navigator.standalone === true;
  function maybeInstallPopup() {
    if (G.dive || G.quizOpen) return void setTimeout(maybeInstallPopup, 15000);
    if (!IS_TOUCH || isStandalone() || G.modalOpen || G.mode !== "world") return;
    try { if (localStorage.getItem("jl_install_shown")) return; localStorage.setItem("jl_install_shown", "1"); } catch {}
    openInstall();
  }
  function openInstall() {
    const ios = document.body.classList.contains("ios");
    const html = `<div class="install"><img src="img/icon-180.png" alt="" class="inst-icon"><p>${esc(t("installIntro"))}</p>
      ${installEvt ? `<button class="btn pink" id="inst-go">${esc(t("installBtn"))}</button>` : ""}
      <div class="inst-steps">${ios ? `<div class="inst-card">${t("installIOS")}</div>` : `<div class="inst-card">${t("installAndroid")}</div><div class="inst-card">${t("installIOS")}</div>`}</div>
      <p class="push-note">${esc(t("installPushHint"))}</p><button class="btn sm" id="inst-later">${esc(t("installLater"))}</button></div>`;
    openModal(t("installTitle"), html, (el) => {
      const go = el.querySelector("#inst-go");
      if (go) go.addEventListener("click", async () => { try { installEvt.prompt(); await installEvt.userChoice; toast(t("installDone")); } catch {} installEvt = null; closeModal(); });
      el.querySelector("#inst-later").addEventListener("click", closeModal);
    });
  }
  if ("serviceWorker" in navigator) window.addEventListener("load", () => navigator.serviceWorker.register("sw.js").catch(() => {}));

  // ---------------- 방명록 ----------------
  const fmtTime = (ts) => { const d = new Date(ts), z = (n) => String(n).padStart(2, "0"); return `${d.getFullYear()}.${z(d.getMonth() + 1)}.${z(d.getDate())} ${z(d.getHours())}:${z(d.getMinutes())}`; };
  async function openGuestbook(page = 0) {
    openModal("📖 " + t("gbTitle"), `<div class="gb-write"><h3>${esc(t("gbWriteTitle"))}</h3><p>${esc(t("gbIntro"))}</p><p class="gb-once">${esc(t("gbOnce"))}</p>
      <form class="gb-form" id="gb-form"><textarea id="gb-text" maxlength="300" rows="4" placeholder="${esc(t("gbPh"))}"></textarea>
      <div class="gb-row"><span id="gb-count">0/300</span><button class="btn pink" type="submit">${esc(t("gbWrite"))}</button></div><div class="err" id="gb-err"></div></form></div>
      <h3 class="gb-list-title">${esc(t("gbListTitle"))}</h3>
      <div class="gb-list" id="gb-list"><p class="gb-empty">…</p></div><div class="gb-pager" id="gb-pager"></div>`, (el) => {
      const ta = el.querySelector("#gb-text");
      ta.addEventListener("input", () => (el.querySelector("#gb-count").textContent = ta.value.length + "/300"));
      el.querySelector("#gb-form").addEventListener("submit", async (e) => {
        e.preventDefault();
        const text = ta.value.trim(); if (!text) return;
        const btn = e.target.querySelector("button"); btn.disabled = true;
        try { const r = await API.gbWrite(text); if (r.user) setUser(r.user); if (r.coins) setTimeout(() => toast(t("coinGb", { n: r.coins })), 900); ta.value = ""; el.querySelector("#gb-count").textContent = "0/300"; toast(t("gbDone")); loadGb(0); }
        catch (err) { el.querySelector("#gb-err").textContent = err.message; }
        finally { btn.disabled = false; }
      });
      loadGb(page);
    }, true);
  }
  // 방명록: 내가 쓴 글은 쓴 그대로, 다른 사람 글은 내 언어로 번역해서 보여 줌 (trBlock)
  async function loadGb(page) {
    const list = $("#gb-list"), pager = $("#gb-pager");
    if (!list) return;
    try {
      const r = await API.gbList(page);
      if (!r.entries.length) { list.innerHTML = `<p class="gb-empty">${esc(t("gbEmpty"))}</p>`; pager.innerHTML = ""; return; }
      list.innerHTML = `<div class="gb-head"><span>${esc(t("gbNo"))}</span><span>${esc(t("gbWriter"))}</span><span>${esc(t("gbContent"))}</span><span>${esc(t("gbDate"))}</span></div>` +
        r.entries.map((e, i) => `<div class="gb-item${e.role === "artist" ? " host" : ""}" data-key="${esc(e.key)}">
          <span class="no">${r.total - page * 20 - i}</span>
          <span class="who"><canvas width="32" height="26" data-av='${esc(JSON.stringify(e.avatar || null))}'></canvas><b>${e.role === "artist" ? "✦ " : ""}${esc(e.name)}</b></span>
          <span class="txt">${trBlock(e.text, e.tr, G.user && e.id === G.user.id)}</span>
          <span class="when">${fmtTime(e.ts)}${G.user && (staff(G.user.role) || G.user.id === e.id) ? ` <button class="gb-del" title="${esc(t("del"))}">✕</button>` : ""}</span></div>`).join("");
      list.querySelectorAll("canvas[data-av]").forEach((c) => { try { const av = JSON.parse(c.dataset.av); const x = c.getContext("2d"); x.imageSmoothingEnabled = false; Avatar.face(x, av, 32, 26); } catch {} });
      list.querySelectorAll(".gb-del").forEach((b) => b.addEventListener("click", async () => {
        const key = b.closest(".gb-item").dataset.key;
        try { await API.gbDelete(key); loadGb(page); } catch (e) { toast(e.message); }
      }));
      const pages = Math.ceil(r.total / 20);
      pager.innerHTML = pages > 1 ? Array.from({ length: pages }, (_, i) => `<button class="chip ${i === page ? "on" : ""}" data-p="${i}">${i + 1}</button>`).join("") : "";
      pager.querySelectorAll("[data-p]").forEach((b) => b.addEventListener("click", () => loadGb(+b.dataset.p)));
    } catch (e) { list.innerHTML = `<p class="gb-empty">${esc(e.message)}</p>`; }
  }

  function openGuide() {
    openModal(t("guideTitle"), `<ul class="guide">${t("guide").map((g) => `<li>${g}</li>`).join("")}</ul><p style="text-align:center"><button class="btn sm grape" id="guide-profile">${esc(t("seeProfile"))}</button> <button class="btn sm pink" id="guide-install">${esc(t("installHelp"))}</button> <button class="btn sm" id="guide-push">${esc(t("pushBtn"))}</button></p>`,
      (el) => { el.querySelector("#guide-install").addEventListener("click", openInstall); el.querySelector("#guide-profile").addEventListener("click", openProfile); el.querySelector("#guide-push").addEventListener("click", openPushSetup); });
  }
  $("#btn-help").addEventListener("click", openGuide);
  // ---------------- 📸 스크린샷 ----------------
  // 컴퓨터: PNG 파일로 바로 저장 (브라우저의 다운로드 폴더 — 바탕화면으로 바꾸는 법은 안내창에)
  // 휴대폰: 공유 창을 띄워 "이미지 저장"(아이폰) / "갤러리·포토에 저장"(안드로이드) 한 번에 선택
  function shotCanvas() {
    const src = $("#game"), c = document.createElement("canvas");
    c.width = src.width; c.height = src.height;
    const x = c.getContext("2d");
    x.drawImage(src, 0, 0);
    // 워터마크
    const k = src.width / VW, d = new Date(), z = (n) => String(n).padStart(2, "0");
    const label = `JELLY LAND ♪  ${d.getFullYear()}.${z(d.getMonth() + 1)}.${z(d.getDate())} ${z(d.getHours())}:${z(d.getMinutes())}`;
    x.font = `bold ${Math.round(13 * k)}px ${FONT}`; x.textAlign = "right"; x.textBaseline = "bottom";
    const tw = x.measureText(label).width, pad = 8 * k;
    x.fillStyle = "rgba(58,37,48,.6)"; x.fillRect(c.width - tw - pad * 3, c.height - 26 * k - pad, tw + pad * 2, 22 * k);
    x.fillStyle = "#fff"; x.fillText(label, c.width - pad * 2, c.height - pad - 7 * k);
    return c;
  }
  function shutter() {
    const f = $("#shot-flash"); f.classList.remove("on"); void f.offsetWidth; f.classList.add("on");
    try { const A = window.AudioContext || window.webkitAudioContext; const a = shutter.ctx || (shutter.ctx = new A()); a.resume && a.resume();
      const b = a.createBuffer(1, a.sampleRate * 0.12, a.sampleRate), dd = b.getChannelData(0); for (let i = 0; i < dd.length; i++) dd[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / dd.length, 3);
      const s2 = a.createBufferSource(), g = a.createGain(); g.gain.value = 0.25; s2.buffer = b; s2.connect(g).connect(a.destination); s2.start(); } catch {}
  }
  function takeScreenshot() {
    if (G.mode !== "world") return;
    shutter();
    let url;
    try { url = shotCanvas().toDataURL("image/png"); } catch { return toast(t("shotFail")); }
    const d = new Date(), z = (n) => String(n).padStart(2, "0");
    const name = `JELLYLAND_${d.getFullYear()}${z(d.getMonth() + 1)}${z(d.getDate())}_${z(d.getHours())}${z(d.getMinutes())}${z(d.getSeconds())}.png`;
    if (IS_TOUCH) {
      // 휴대폰: 공유 창 → 사진첩/갤러리에 저장 (버튼을 누른 순간 바로 열어야 해서 동기로 파일을 만듦)
      try {
        const bin = atob(url.split(",")[1]), arr = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
        const file = new File([arr], name, { type: "image/png" });
        if (navigator.canShare && navigator.canShare({ files: [file] })) {
          navigator.share({ files: [file], title: "JELLY LAND" }).then(() => toast(t("shotSaved"))).catch((e) => { if (e && e.name !== "AbortError") showShot(url, name); });
          return;
        }
      } catch {}
      return showShot(url, name);
    }
    // 컴퓨터: 바로 파일로 저장
    const a = document.createElement("a"); a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
    toast(t("shotPC"));
  }
  function showShot(url, name) {
    openModal("📸 " + t("shotTitle"), `<div class="shot-view"><img src="${url}" alt="screenshot"><p>${esc(t(IS_TOUCH ? "shotHoldSave" : "shotPCHelp"))}</p>
      <a class="btn pink" href="${url}" download="${esc(name)}">📥 ${esc(t("shotDownload"))}</a></div>`, null, true);
  }
  $("#btn-shot").addEventListener("click", takeScreenshot);
  $("#btn-shot").title = "📸";

  function bgmBtn() { $("#btn-bgm").textContent = BGM.on ? "🔊" : "🔇"; $("#btn-bgm").title = t("bgm"); }
  $("#btn-bgm").addEventListener("click", () => { BGM.toggle(); bgmBtn(); });
  bgmBtn();
  $("#btn-gb").addEventListener("click", () => openGuestbook());

  // ---------------- 언어 ----------------
  function langButtons(el, current, onPick) {
    el.innerHTML = I.LANGS.map((l) => `<button type="button" class="chip ${l.code === current ? "on" : ""}" data-l="${l.code}">${l.label}</button>`).join("");
    el.querySelectorAll("[data-l]").forEach((b) => b.addEventListener("click", () => onPick(b.dataset.l)));
  }
  // 언어가 바뀌면 화면의 모든 글자 + 건물 간판을 다시 그림
  function applyLang(l) {
    if (l && l !== I.lang) {
      I.set(l);
      if (G.worlds.plaza) {
        const keep = { x: G.player.x, y: G.player.y, dir: G.player.dir };
        buildWorlds();
        if (G.scene) { buildMinimap(); if (G.mode === "world") { G.player.x = keep.x; G.player.y = keep.y; } }
      }
    } else I.apply();
    renderTitleLang();
    updateSceneLabels();
    renderPrompt();
    if (G.user) refreshMe();
    rerenderChat();
    if (!$("#creator").classList.contains("hidden")) renderCreator();
    $("#btn-enter").textContent = $("#btn-cancel").classList.contains("hidden") ? t("enterBang") : t("save");
    if (G.user && !$("#auth-continue").classList.contains("hidden")) $("#cont-name").textContent = t("welcomeBack", { name: G.user.nickname || G.user.email });
  }
  let signupLang = I.lang;
  function renderTitleLang() {
    langButtons($("#lang-top"), I.lang, (l) => { signupLang = l; applyLang(l); });
    // 로그인 화면 배경음악 켜기/끄기
    const tb = document.createElement("button");
    tb.type = "button"; tb.className = "chip bgm-title"; tb.textContent = BGM.on ? "🔊" : "🔇"; tb.title = t("bgm");
    tb.addEventListener("click", () => { BGM.toggle(); tb.textContent = BGM.on ? "🔊" : "🔇"; bgmBtn(); });
    $("#lang-top").appendChild(tb);
    langButtons($("#lang-pick"), signupLang, (l) => { signupLang = l; applyLang(l); });
  }
  $("#btn-lang").addEventListener("click", () => {
    openModal(t("langTitle"), `<div class="lang-pick big" id="lang-modal"></div>`, (el) => {
      langButtons(el.querySelector("#lang-modal"), I.lang, async (l) => {
        applyLang(l);
        closeModal();
        toast(t("langChanged"));
        try { G.user = await API.saveSettings({ lang: l }); } catch {}
      });
    });
  });

  // ---------------- 네트워크: 위치 + 채팅을 한 번에 (sync) ----------------
  // 주변에 사람이 있거나 내가 움직이면 자주(0.9초), 혼자 가만히 있으면 드물게(5초) 확인 → 빠르고 저렴
  let syncBusy = false, syncTimer = null, lastSync = 0, lastSent = "";
  function nextSyncDelay() {
    if (document.hidden) return 15000;
    let othersMoving = false;
    for (const o of G.others.values()) if (o.vx || o.vy || Date.now() - (o.pathAt || 0) < 2000) { othersMoving = true; break; }
    if (G.player.moving || othersMoving) return RT.ok ? 1000 : 300; // 누군가 움직이는 중: 빠르게 (실시간 서버가 있으면 위치는 그쪽으로)
    if (G.others.size > 0 || Date.now() - G.lastInput < 4000) return 1200; // 주변에 사람만 있을 때
    return 5000;                                                   // 혼자 가만히: 드물게
  }
  function scheduleSync(ms) { clearTimeout(syncTimer); syncTimer = setTimeout(doSync, ms ?? nextSyncDelay()); }
  function kickSync() { const since = Date.now() - lastSync; scheduleSync(since > 250 ? 0 : 250 - since); } // 출발·정지 순간은 늦어도 0.25초 안에 알림
  async function doSync() {
    if (G.mode !== "world") return scheduleSync();
    if (syncBusy) return scheduleSync(G.trail && G.trail.length && G.trail[G.trail.length - 1][0] > (G.trailSent || 0) ? 120 : undefined); // 보낼 길이 남았으면 곧 다시
    syncBusy = true; lastSync = Date.now();
    const room = G.scene;
    const inSea = soloScene(room); // 분수대 속 · 젤리젤리샵 안: 다른 사람에게는 입구 앞에 서 있는 것처럼 보임
    const shopDoor = room === "shop" || room === "cinema" ? (G.worlds.plaza.buildings.find((b) => b.id === room) || {}).door : null;
    const soloX = shopDoor ? Math.round(shopDoor.x) : 640, soloY = shopDoor ? Math.round(shopDoor.y + 22) : 262;
    const emo = G.sendEmo; G.sendEmo = null;
    try {
      // 지난번 이후 새로 걸은 길
      const sendT = Date.now();
      let path = null;
      if (!inSea && G.trail && G.trail.length) {
        const from = G.trailSent || 0;
        const pts = G.trail.filter((q) => q[0] > from);
        // 시간은 서버 시계 기준으로 바꿔 보냄 (매번 같은 기준이라 묶음 사이가 어긋나지 않음)
        if (pts.length) { path = pts.map((q) => [Math.round(q[0] + G.clockOff), q[1], q[2]]); G.trailSent = pts[pts.length - 1][0]; }
      }
      if (path && !G.clockSet) path = path.map((q) => [q[0] - sendT - G.clockOff, q[1], q[2]]); // 아직 서버 시계를 모르면 "몇 ms 전"으로
      const r = await API.sync({ pv: 1, pathAbs: !!(path && G.clockSet), scene: inSea ? "plaza" : room, x: inSea ? soloX : Math.round(G.player.x), y: inSea ? soloY : Math.round(G.player.y), dir: inSea ? (shopDoor ? "down" : "up") : G.player.dir, seat: inSea ? null : G.seat, ...(G.fish && !inSea ? { fs: fishState() } : {}), vx: inSea ? 0 : Math.round(G.player.vx || 0), vy: inSea ? 0 : Math.round(G.player.vy || 0), since: G.chat.since, ...(G.user.drink && G.user.drink.until > serverNow_() ? { drink: G.user.drink } : {}), ...(emo ? { emo } : {}), ...(path ? { path } : {}) });
      if (r.now) { const recvT = Date.now(), off = r.now - (sendT + recvT) / 2; if (!G.clockSet) { G.clockOff = off; G.clockSet = true; } else G.clockOff = G.clockOff * 0.8 + off * 0.2; }
      if (room !== G.scene) return;
      if (!inSea) applyOthers(r.others || [], r.now);
      if (!API.demo) { G.online = r.online || 1; $("#online").textContent = t("online", { n: G.online }); }
      applyChat(r.messages || [], r.notice);
    } catch (e) {
      if (e.status === 401 && e.code === "gone") { toast(t("e_gone")); return logout(); }
      if (e.status === 401) {
        try { G.user = await API.me(); } catch { return logout(); } // 예전 토큰이면 새 토큰으로 교체
      }
    } finally { syncBusy = false; scheduleSync(); }
  }
  // ---------------- ⚡ 실시간 위치 서버 (Cloudflare) ----------------
  // 걷는 위치를 1초에 15번 바로바로 주고받아서, 다른 사람 움직임이 약 0.1~0.2초 만에 보여요.
  // 연결이 안 되면 자동으로 예전 방식(sync 의 지나온 길 재생)으로 돌아가요.
  const RT = G.RT = { ws: null, room: null, ok: false, off: 0, offN: 0, lastSend: 0, chk: 0, retry: 0, blockUntil: 0, lagHist: [], target: 150, delay: 150, pingT: 0, lx: 0, ly: 0 };
  function rtUrl() { return ((window.JELLY_CONFIG || {}).realtimeUrl || "").trim().replace(/\/$/, ""); }
  function rtDrop() { // 실시간 연결이 끊김 → 다른 사람들은 예전 방식으로 다시 그림
    RT.ok = false;
    for (const o of G.others.values()) if (o.rt) { o.rt = false; o.buf = null; o.rtMov = 0; }
  }
  function rtClose() { const ws = RT.ws; RT.ws = null; RT.room = null; rtDrop(); if (ws) try { ws.close(); } catch {} }
  function rtEnsure() {
    const want = !API.demo && rtUrl() && API.token && G.mode === "world" && !soloScene(G.scene) && G.user && Date.now() > RT.blockUntil; // 분수대 속에서는 잠시 끊음 (다른 사람에게는 분수대 앞으로 보이게)
    const room = G.scene;
    if (!want) { if (RT.ws) rtClose(); return; }
    if (RT.ws && RT.room === room) {
      if (RT.ok && Date.now() - RT.pingT > (RT.offN < 4 ? 1500 : 15000)) rtPing();
      return;
    }
    if (RT.ws) rtClose();
    if (RT.wait && Date.now() < RT.wait) return;
    let ws;
    try { ws = new WebSocket(rtUrl().replace(/^http/, "ws") + "/ws?room=" + room); } catch { return; }
    RT.ws = ws; RT.room = room;
    ws.onopen = () => { if (RT.ws === ws) ws.send(JSON.stringify({ t: "auth", token: API.token })); };
    ws.onmessage = (e) => { if (RT.ws === ws) rtMsg(e.data); };
    ws.onclose = (e) => {
      if (RT.ws !== ws) return;
      RT.ws = null; RT.room = null; rtDrop();
      if (e.code === 4001) RT.blockUntil = Date.now() + 120000; // 로그인 확인 실패: 2분 뒤 다시
      RT.wait = Date.now() + Math.min(30000, 1000 * 2 ** RT.retry++);
    };
  }
  function rtPing() { RT.pingT = Date.now(); try { RT.ws.send(JSON.stringify({ t: "ping", c: RT.pingT })); } catch {} }
  function rtSend(m) {
    RT.lastSend = Date.now();
    const p = G.player;
    RT.lx = p.x; RT.ly = p.y;
    try { RT.ws.send(JSON.stringify({ t: "p", x: Math.round(p.x), y: Math.round(p.y), d: p.dir, m, ...(RT.offN ? { c: Math.round(Date.now() + RT.off) } : {}) })); } catch {}
  }
  function rtMsg(raw) {
    let m; try { m = JSON.parse(raw); } catch { return; }
    const now = Date.now();
    if (m.t === "ok") { RT.ok = true; RT.retry = 0; if (!RT.offN) RT.off = m.s - now; rtPing(); return; }
    if (m.t === "pong") { // 실시간 서버 시계와의 차이
      const off = m.s - (m.c + now) / 2;
      RT.off = RT.offN ? RT.off * 0.7 + off * 0.3 : off; RT.offN++;
      return;
    }
    if (m.t === "join") { if (!G.others.has(m.id)) kickSync(); return; } // 같은 방에 누가 들어옴 → 바로 불러오기
    if (m.t === "bye") { const o = G.others.get(m.id); if (o && o.rt) { o.rt = false; o.buf = null; o.rtMov = 0; } return; }
    if (m.t !== "p" || soloScene(G.scene) || RT.room !== G.scene) return;
    const o = G.others.get(m.id);
    if (!o) return; // 아직 sync 로 이름·모습을 못 받은 사람 → 곧 생김
    const rNow = now + RT.off;
    // 얼마나 늦게 왔는지 기록 → 재생 지연을 자동으로 (보통 0.1~0.2초)
    const late = rNow - m.ts;
    if (late > -500 && late < 3000) { RT.lagHist.push(late); if (RT.lagHist.length > 60) RT.lagHist.shift(); }
    if (RT.lagHist.length >= 5) { const sl = [...RT.lagHist].sort((a, b) => a - b); RT.target = Math.max(70, Math.min(600, sl[Math.floor(sl.length * 0.9)] + 45)); }
    const rAt = rNow - RT.delay;
    if (!o.rt) { o.rt = true; o.buf = [[rAt - 1, o.rx, o.ry]]; o.rtLast = 0; } // 지금 보이는 자리에서 이어서
    const b = o.buf, L = b[b.length - 1];
    if (m.ts <= (o.rtLast || 0)) return;
    if (m.ts - (o.rtLast || 0) > 400) { // 새로 걷기 시작: 늦게 왔으면 그만큼 미뤄서 처음부터 같은 속도로
      o.rtShift = Math.max(0, rAt + 20 - m.ts, L[0] + 60 - m.ts);
      if (L[0] < m.ts + o.rtShift - 70) b.push([m.ts + o.rtShift - 70, L[1], L[2]]); // 출발 직전까지는 제자리
    }
    const ts = m.ts + (o.rtShift || 0);
    if (ts <= L[0]) return;
    b.push([ts, m.x, m.y]); o.rtLast = m.ts; o.rtMov = m.m;
    if (!m.m) o.sdir = m.d;
    const cut = rAt - 3000; while (b.length > 2 && b[1][0] < cut) b.shift();
  }

  // 서버 시계 맞추기 (내 기기 시계와의 차이)
  G.clockOff = 0; G.clockSet = false; G.lagHist = []; G.netTarget = 1000; G.netDelay = 1000;
  function serverNow_() { return Date.now() + G.clockOff; }
  function serverNow() { return serverNow_(); }
  function applyOthers(list, serverNow) {
    const now = Date.now();
    for (const o of list) {
      const ex = G.others.get(o.id);
      const upd = { x: o.x, y: o.y, dir: o.dir, name: o.name, avatar: o.avatar, role: o.role, seat: o.seat || null, fs: o.seat ? o.fs | 0 : 0, drink: o.drink || null,
        vx: o.vx || 0, vy: o.vy || 0, pv: !!o.pv, age: serverNow ? Math.max(0, serverNow - o.ts) : 0, recv: now, seen: now };
      if (ex && o.role === "artist" && upd.seat === "throne" && ex.seat !== "throne") { const st = (scene().seats || []).find((x) => x.id === "throne"); if (st) celebrate(st); }
      const tgt = ex || { id: o.id, rx: o.x, ry: o.y };
      if (tgt.rt) { /* 실시간 서버로 받는 중: 길 정보는 건너뜀 */ }
      else if (Array.isArray(o.path) && o.path.length) { // 지나온 길 합치기
        const b = tgt.buf || (tgt.buf = []);
        const rAt = serverNow_() - G.netDelay;
        let added = 0, newest = 0;
        for (const pt0 of o.path) {
          if (pt0[0] <= (tgt.rawLast || 0)) continue; // 이미 받은 점
          while (b.length && b[b.length - 1][3]) b.pop(); // 임시 보정점은 진짜 길이 오면 버림
          const L = b[b.length - 1];
          // 새로 걷기 시작한 순간: 그 길이 늦게 도착해서 재생 시각이 이미 지나갔다면, 이번 걸음 전체를 뒤로 미뤄서 처음부터 같은 속도로 재생
          if (!L || pt0[0] - (tgt.rawLast || 0) > 400) {
            tgt.shift = Math.max(0, rAt + 40 - pt0[0], L ? L[0] + 150 - pt0[0] : 0);
            if (L && L[0] < pt0[0] + tgt.shift - 120) b.push([pt0[0] + tgt.shift - 120, L[1], L[2]]); // 출발 직전까지는 제자리
          }
          const ts = pt0[0] + (tgt.shift || 0);
          if (L && ts <= L[0]) continue;
          b.push([ts, pt0[1], pt0[2]]); tgt.rawLast = pt0[0]; newest = pt0[0];
          added++; tgt.pathAt = Date.now();
        }
        const cut = serverNow_() - 6000; while (b.length > 2 && b[1][0] < cut) b.shift();
        // 새 길이 도착했을 때 그 길이 "얼마나 묵은 것인지" 기록 → 최근 20번 중 가장 늦은 값에 맞춰 재생 지연을 정함
        const fresh = serverNow_() - newest;
        if (added >= 2 && fresh >= 0 && fresh < 4000) { G.lagHist.push(fresh); if (G.lagHist.length > 20) G.lagHist.shift(); }
        if (G.lagHist.length) { const sl = [...G.lagHist].sort((p, q) => p - q), hi = sl[Math.max(0, sl.length - 2)]; G.netTarget = Math.max(700, Math.min(1600, hi + 350)); } // 가끔 튀는 한 번은 무시 (늦게 온 걸음은 위에서 따로 미뤄 재생) // 가장 늦게 온 것보다도 여유 있게
      } else if (!tgt.buf || !tgt.buf.length) tgt.buf = null;
      if (!tgt.rt && tgt.buf && tgt.buf.length && !(Array.isArray(o.path) && o.path.length) && now - (tgt.pathAt || 0) > 1500) { const L = tgt.buf[tgt.buf.length - 1]; if (Math.abs(L[1] - o.x) > 2 || Math.abs(L[2] - o.y) > 2) tgt.buf.push([Math.max(o.ts || 0, L[0] + 300), o.x, o.y, 1]); } // 길 정보가 한동안 없을 때만 위치 보정
      if (ex && !o.seat && o.dir) tgt.sdir = o.dir;
      if (o.emo && o.emo.k && tgt.emoK !== o.emo.k) { tgt.emoK = o.emo.k; if (!serverNow || serverNow - o.emo.t < 4000) tgt.emoShow = { e: o.emo.e, at: now, until: now + 3500 }; }
      if (ex) Object.assign(ex, upd);
      else G.others.set(o.id, Object.assign(tgt, upd));
    }
    // 잠깐 응답에서 빠져도 바로 사라지지 않게 8초 유지 (깜빡임 방지)
    for (const [id, o] of G.others) if (now - o.seen > 8000) G.others.delete(id);
  }
  document.addEventListener("visibilitychange", () => { if (!document.hidden) kickSync(); });
  // 채팅은 5분이 지나면 화면에서 사라짐
  const CHAT_TTL = 5 * 60 * 1000;
  setInterval(() => {
    const cut = Date.now() - CHAT_TTL;
    const keep = [];
    for (const m of G.chat.msgs) { if (m.ts < cut && !m.pending) { m.el && m.el.remove(); } else keep.push(m); }
    G.chat.msgs = keep;
  }, 10000);

  // ---------------- 채팅 (광장 / 팬 라운지, 자동 번역) ----------------
  function resetChat() {
    G.chat = { since: 0, seen: new Set(), msgs: [], notice: null, unread: 0 };
    $("#chat-log").innerHTML = "";
    $("#notice").classList.add("hidden");
    updateBadge();
    kickSync();
  }
  function applyChat(messages, notice) {
    const log = $("#chat-log");
    const atBottom = log.scrollHeight - log.scrollTop - log.clientHeight < 40;
    const first = G.chat.since === 0;
    let sysNew = false;
    for (const m of messages) {
      G.chat.since = Math.max(G.chat.since, m.ts);
      if (m.ts < Date.now() - CHAT_TTL) continue;
      if (G.chat.seen.has(m.key)) continue;
      G.chat.seen.add(m.key);
      // 내가 보낸 메시지(이미 화면에 먼저 표시됨)면 번역본으로 교체만
      const pend = G.chat.msgs.find((x) => x.pending && x.id === m.id && x.text === m.text);
      if (pend) { Object.assign(pend, m, { pending: false }); pend.el && pend.el.replaceWith(makeChatLine(pend)); continue; }
      G.chat.msgs.push(m);
      if (m.role === "system") sysNew = true;
      if (G.chat.msgs.length > 120) G.chat.msgs.shift();
      addChatLine(m);
      if (!first || Date.now() - m.ts < 8000) G.bubbles.set(m.id, { m, until: Date.now() + 6500 });
      if (!first && m.id !== G.user.id && $("#chat").classList.contains("collapsed")) G.chat.unread++;
    }
    if (G.chat.since === 0) G.chat.since = 1;
    if (sysNew) loadWhaleHall(true); // 🐋 누가 털보고래를 낚았다는 알림 → 전광판 바로 새로고침
    if (atBottom || first) log.scrollTop = log.scrollHeight;
    const nKey = notice ? notice.ts : 0, oKey = G.chat.notice ? G.chat.notice.ts : 0;
    if (nKey !== oKey) { G.chat.notice = notice; renderNotice(); }
    updateBadge();
  }

  function renderNotice() {
    const n = $("#notice"), no = G.chat.notice;
    if (!no) return n.classList.add("hidden");
    n.innerHTML = `📢 <b>${esc(t("noticeLabel"))}</b> ${trBlock(no.text, no.tr)}${staff(G.user.role) ? ` <span class="del" id="notice-del">✕</span>` : ""}`;
    n.classList.remove("hidden");
    const d = $("#notice-del");
    if (d) d.addEventListener("click", async () => { try { await API.chatDelete("notice/" + G.scene); G.chat.notice = null; renderNotice(); } catch (e) { toast(e.message); } });
  }
  function addChatLine(m) { $("#chat-log").appendChild(makeChatLine(m)); }
  function makeChatLine(m) {
    const d = document.createElement("div");
    m.el = d;
    d.className = "msg" + (m.role === "artist" ? " artist" : m.role === "admin" ? " admin" : m.role === "system" ? " system" : "") + (m.id === G.user.id ? " mine" : "");
    const time = new Date(m.ts).toLocaleTimeString(I.lang === "en" ? "en-US" : I.lang === "ja" ? "ja-JP" : "ko-KR", { hour: "2-digit", minute: "2-digit" });
    const shown = msgText(m);
    const isTr = shown !== m.text;
    d.innerHTML = `<b>${esc(m.name)}</b> <span class="txt">${esc(shown)}</span>${isTr ? `<span class="tr" title="${esc(m.text)}">🌐</span>` : ""}<span class="t">${time}</span>${staff(G.user.role) ? `<span class="del">✕</span>` : ""}`;
    if (isTr) {
      let orig = false;
      d.querySelector(".tr").addEventListener("click", () => { orig = !orig; d.querySelector(".txt").textContent = orig ? m.text : shown; d.querySelector(".tr").classList.toggle("on", orig); });
    }
    const del = d.querySelector(".del");
    if (del) del.addEventListener("click", async () => { try { await API.chatDelete(m.key); d.remove(); } catch (e) { toast(e.message); } });
    if (m.pending) d.classList.add("pending");
    return d;
  }
  function rerenderChat() {
    if (G.mode !== "world") return;
    $("#chat-log").innerHTML = "";
    G.chat.msgs.forEach(addChatLine);
    $("#chat-log").scrollTop = $("#chat-log").scrollHeight;
    renderNotice();
  }
  function updateBadge() {
    const b = $("#chat-badge");
    b.textContent = G.chat.unread > 99 ? "99+" : G.chat.unread;
    b.classList.toggle("hidden", !G.chat.unread);
  }
  function openChat() { $("#chat").classList.remove("collapsed"); $("#chat-toggle").textContent = "_"; G.chat.unread = 0; updateBadge(); $("#chat-log").scrollTop = $("#chat-log").scrollHeight; }
  function toggleChat() {
    if ($("#chat").classList.contains("collapsed")) openChat();
    else { $("#chat").classList.add("collapsed"); $("#chat-toggle").textContent = "▲"; }
  }
  $("#chat-head").addEventListener("click", toggleChat);
  $("#chat-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const inp = $("#chat-input"), text = inp.value.trim();
    if (!text) { if (!IS_TOUCH) inp.blur(); return; }
    inp.value = "";
    const notice = $("#chat-notice").checked;
    // 보내자마자 내 화면에 바로 표시 (번역은 서버에서 끝나면 자동 반영)
    let temp = null;
    if (!notice) {
      temp = { id: G.user.id, name: G.user.nickname, role: G.user.role, text, ts: Date.now(), key: "tmp" + Math.random(), pending: true };
      G.chat.msgs.push(temp); addChatLine(temp);
      G.bubbles.set(G.user.id, { m: temp, until: Date.now() + 6500 });
      $("#chat-log").scrollTop = $("#chat-log").scrollHeight;
    }
    try {
      const r = await API.chatSend(G.scene === "sea" ? "plaza" : G.scene, text, notice);
      if (notice) { $("#chat-notice").checked = false; toast(t("noticeDone")); G.chat.notice = r.notice; renderNotice(); }
      else if (r.message) { G.chat.seen.add(r.message.key); Object.assign(temp, r.message, { pending: false }); temp.el && temp.el.replaceWith(makeChatLine(temp)); }
      kickSync();
    } catch (err) {
      toast(err.message); inp.value = text;
      if (temp) { temp.el && temp.el.remove(); G.chat.msgs.splice(G.chat.msgs.indexOf(temp), 1); G.bubbles.delete(G.user.id); }
    }
  });

  // ---------------- 캐릭터 만들기 ----------------
  const draft = { nickname: "", avatar: Avatar.random() };
  function chipRow(id, items, key, render) {
    const el = $("#o-" + id);
    el.innerHTML = "";
    items.forEach((it, i) => {
      const v = key === "gender" ? it.v : i;
      const b = document.createElement("button");
      b.type = "button";
      b.className = render === "sw" ? "sw" : "chip";
      if (render === "sw") { b.style.background = it.c; b.title = it.name; b.setAttribute("aria-label", it.name); }
      else b.innerHTML = (it.col ? `<i style="background:${it.col}"></i>` : "") + esc(it.name);
      if (draft.avatar[key] === v) b.classList.add("on");
      b.addEventListener("click", () => { draft.avatar[key] = v; renderCreator(); });
      el.appendChild(b);
    });
  }
  function renderCreator() {
    chipRow("gender", [{ v: "f", name: t("female") }, { v: "m", name: t("male") }], "gender");
    const shopName = (kind, i) => { const it = shopItem(kind, i); return it ? L(it.name) : ""; };
    chipRow("hair", Avatar.HAIRS.map((_, i) => ({ name: t("hairs")[i] || shopName("hair", i) || t("hairsMore")[i - 10] || "?" })), "hair");
    if (draft.avatar.wand === undefined) draft.avatar.wand = 0;
    chipRow("wand", Avatar.WANDS.map((_, i) => ({ name: i ? shopName("wand", i) : t("wandNone") })), "wand");
    if (draft.avatar.bubble === undefined) draft.avatar.bubble = 0;
    chipRow("bubble", Array.from({ length: 8 }, (_, i) => ({ name: i ? shopName("bubble", i) : t("bubbleBasic") })), "bubble");
    chipRow("eye", Avatar.EYES.map((c, i) => ({ c, name: t("eyes")[i] })), "eye", "sw");
    chipRow("hairColor", Avatar.HAIR_COLORS.map((c, i) => ({ ...c, name: t("hairColors")[i] })), "hairColor", "sw");
    chipRow("skin", Avatar.SKINS.map((c, i) => ({ ...c, name: t("skins")[i] })), "skin", "sw");
    const isHost = G.user && G.user.role === "artist";
    const outs = Avatar.OUTFITS.map((o, i) => ({ i, name: t("outfits")[i] || shopName("outfit", i) || o.id, col: o.overall || (o.top === "#f7f5ff" ? o.skirt : o.top), host: !!o.host, staffOnly: !!o.staff }));
    chipRow("outfit", outs, "outfit");
    // 관리자 전용 의상 (젤리 퀸 로열 드레스)
    const amStaff = G.user && staff(G.user.role);
    $("#o-outfit").querySelectorAll(".chip").forEach((el, idx) => {
      if (!outs[idx].staffOnly) return;
      el.classList.add("host-only", "staff-only"); el.insertAdjacentHTML("beforeend", `<small>${amStaff ? "★" : "🔒"} ${esc(t("staffOnly"))}</small>`);
      if (!amStaff) { el.disabled = true; el.title = t("staffOnly"); }
    });
    if (!amStaff && outs[draft.avatar.outfit] && outs[draft.avatar.outfit].staffOnly) draft.avatar.outfit = 0;
    // 호스트 전용 의상: 호스트가 아니면 잠금 표시
    $("#o-outfit").querySelectorAll(".chip").forEach((el, idx) => {
      if (!outs[idx].host) return;
      el.classList.add("host-only"); el.insertAdjacentHTML("beforeend", `<small>${isHost ? "✦" : "🔒"} ${esc(t("hostOnly"))}</small>`);
      if (!isHost) { el.disabled = true; el.title = t("hostOnly"); }
    });
    if (!isHost && outs[draft.avatar.outfit] && outs[draft.avatar.outfit].host) draft.avatar.outfit = 0;
    // 젤리젤리샵 아이템: 산 것만 고를 수 있음
    [["hair", "#o-hair"], ["outfit", "#o-outfit"], ["wand", "#o-wand"], ["bubble", "#o-bubble"]].forEach(([kind, sel]) => {
      $(sel).querySelectorAll(".chip").forEach((el, idx) => {
        const it = shopItem(kind, idx); if (!it) return;
        if (it.staff) { // 왕관 아이템: 관리자(호스트 포함) 전용
          if (kind === "outfit") return; // 의상은 위에서 따로 표시
          el.classList.add("host-only", "staff-only"); el.insertAdjacentHTML("beforeend", `<small>${amStaff ? "★" : "🔒"} ${esc(t("staffOnly"))}</small>`);
          if (!amStaff) { el.disabled = true; el.title = t("staffOnly"); if ((draft.avatar[kind] | 0) === idx) draft.avatar[kind] = 0; }
          return;
        }
        el.classList.add("shop-only");
        if (!owns(it)) { el.disabled = true; el.title = t("shopLock"); el.insertAdjacentHTML("beforeend", `<small>🛍️ ${esc(t("shopLock"))}</small>`); if ((draft.avatar[kind] | 0) === idx) draft.avatar[kind] = 0; }
        else el.insertAdjacentHTML("beforeend", "<small>✦</small>");
      });
    });
  }
  const DIRS = ["down", "right", "up", "left"];
  function drawPreview() {
    const c = $("#preview"), x = c.getContext("2d");
    x.clearRect(0, 0, 48, 50);
    const now = performance.now();
    Avatar.draw(x, draft.avatar, 24, 47, DIRS[Math.floor(now / 1400) % 4], [1, 0, 3, 0][Math.floor(now / 160) % 4]);
  }
  function openCreator(editing) {
    if (G.mode !== "world") G.mode = "creator";
    draft.nickname = G.user.nickname || "";
    draft.avatar = G.user.avatar ? { ...G.user.avatar } : Avatar.random();
    $("#nick").value = draft.nickname;
    $("#c-err").textContent = "";
    $("#btn-cancel").classList.toggle("hidden", !editing);
    $("#btn-enter").textContent = editing ? t("save") : t("enterBang");
    renderCreator();
    $("#title").classList.add("hidden");
    $("#creator").classList.remove("hidden");
    G.modalOpen = !!editing;
  }
  $("#btn-rand").addEventListener("click", () => { draft.avatar = Avatar.random(); renderCreator(); });
  $("#btn-cancel").addEventListener("click", () => { $("#creator").classList.add("hidden"); G.modalOpen = false; });
  $("#btn-enter").addEventListener("click", async () => {
    const nick = $("#nick").value.trim();
    if (!nick) { $("#c-err").textContent = t("needNick"); $("#nick").focus(); return; }
    const btn = $("#btn-enter"); btn.disabled = true;
    try {
      G.user = await API.saveAvatar(nick, draft.avatar);
      $("#creator").classList.add("hidden");
      G.modalOpen = false;
      if (G.mode !== "world") enterWorld(); else { refreshMe(); toast(t("saved")); }
    } catch (e) { $("#c-err").textContent = e.message; }
    finally { btn.disabled = false; }
  });
  $("#btn-edit").addEventListener("click", () => openCreator(true));

  // ---------------- 로그인 / 회원가입 ----------------
  const AUTH_PANELS = { login: "#f-login", signup: "#f-signup", forgot: "#f-forgot", wait: "#fg-wait", newpw: "#f-newpw" };
  function authPanel(name) {
    for (const [k, sel] of Object.entries(AUTH_PANELS)) $(sel).classList.toggle("hidden", k !== name);
    document.querySelectorAll(".tabs button").forEach((x) => x.classList.toggle("on", x.dataset.tab === name));
  }
  document.querySelectorAll(".tabs button").forEach((b) => b.addEventListener("click", () => authPanel(b.dataset.tab)));

  // ---------------- 🔑 비밀번호 찾기 ----------------
  // 요청 → 관리자가 본인 확인 후 승인 → 요청한 이 기기에서 새 비밀번호 정하기 (비밀 토큰은 이 기기에만 저장)
  const RESET_LS = "jl_pwreset";
  const getReset = () => { try { return JSON.parse(localStorage.getItem(RESET_LS) || "null"); } catch { return null; } };
  const setReset = (v) => { try { v ? localStorage.setItem(RESET_LS, JSON.stringify(v)) : localStorage.removeItem(RESET_LS); } catch {} };
  $("#btn-forgot").addEventListener("click", () => { const f = $("#f-forgot"); f.email.value = $("#f-login").email.value || ""; f.querySelector(".err").textContent = ""; authPanel("forgot"); });
  document.querySelectorAll("[data-back=login]").forEach((b) => b.addEventListener("click", () => authPanel("login")));
  $("#f-forgot").addEventListener("submit", async (e) => {
    e.preventDefault();
    const f = e.target, er = f.querySelector(".err"), btn = f.querySelector("button[type=submit]");
    er.textContent = ""; btn.disabled = true;
    try {
      const email = f.email.value.trim().toLowerCase();
      const r = await API.pwResetRequest(email, f.nick.value.trim(), f.note.value.trim(), I.lang);
      setReset({ email, token: r.token, ts: Date.now() });
      showResetWait("pending");
    } catch (x) { er.textContent = x.message; }
    finally { btn.disabled = false; }
  });
  function showResetWait(status) {
    const r = getReset(); if (!r) return authPanel("login");
    $("#fg-wait-err").textContent = "";
    $("#fg-wait-msg").innerHTML = esc(t(status === "rejected" ? "pwRejected" : "pwWaiting", { email: r.email })).replace(/\n/g, "<br>");
    $("#btn-fg-check").classList.toggle("hidden", status === "rejected");
    authPanel("wait");
  }
  async function checkReset(manual) {
    const r = getReset(); if (!r) return false;
    let st;
    try { st = (await API.pwResetStatus(r.email, r.token)).status; } catch (x) { if (manual) $("#fg-wait-err").textContent = x.message; return false; }
    if (st === "approved") { $("#f-newpw").querySelector(".err").textContent = ""; authPanel("newpw"); return true; }
    if (st === "pending") { showResetWait("pending"); if (manual) $("#fg-wait-err").textContent = t("pwStillWaiting"); return true; }
    if (st === "rejected") { showResetWait("rejected"); return true; }
    setReset(null); if (manual) { toast(t("pwExpired")); authPanel("forgot"); } // 만료되었거나 없어진 요청
    return false;
  }
  $("#btn-fg-check").addEventListener("click", () => checkReset(true));
  $("#btn-fg-cancel").addEventListener("click", () => { setReset(null); authPanel("login"); });
  $("#f-newpw").addEventListener("submit", async (e) => {
    e.preventDefault();
    const f = e.target, er = f.querySelector(".err"), btn = f.querySelector("button[type=submit]");
    er.textContent = "";
    if (f.password.value !== f.password2.value) { er.textContent = t("pwMismatch"); return; }
    const r = getReset(); if (!r) return authPanel("login");
    btn.disabled = true;
    try { G.user = await API.pwResetComplete(r.email, r.token, f.password.value); setReset(null); f.reset(); toast(t("pwDone")); afterAuth(); }
    catch (x) { er.textContent = x.message; }
    finally { btn.disabled = false; }
  });

  // ---------------- 🔑 비밀번호 바꾸기 (메뉴) ----------------
  function openPwChange(forced) {
    openModal("🔑 " + t("pwChangeBtn"), `<form class="pw-form" id="pw-form">${forced ? `<p class="fg-intro warn">${esc(t("pwTempWarn"))}</p>` : ""}
      <label class="field"><span>${esc(t("pwCurrent"))}</span><input type="password" name="old" autocomplete="current-password" required></label>
      <label class="field"><span>${esc(t("password6"))}</span><input type="password" name="password" autocomplete="new-password" minlength="6" required></label>
      <label class="field"><span>${esc(t("password2"))}</span><input type="password" name="password2" autocomplete="new-password" minlength="6" required></label>
      <div class="err"></div><button class="btn pink go" type="submit">${esc(t("pwNewGo"))}</button></form>`, (el) => {
      const f = el.querySelector("#pw-form");
      f.addEventListener("submit", async (e) => {
        e.preventDefault();
        const er = f.querySelector(".err"), btn = f.querySelector("button[type=submit]"); er.textContent = "";
        if (f.password.value !== f.password2.value) { er.textContent = t("pwMismatch"); return; }
        btn.disabled = true;
        try { const r = await API.changePassword(f.old.value, f.password.value); if (r.user) setUser(r.user); closeModal(); toast(t("pwDone")); }
        catch (x) { er.textContent = x.message; btn.disabled = false; }
      });
    });
  }
  $("#btn-pw").addEventListener("click", () => openPwChange(false));
  $("#f-login").addEventListener("submit", async (e) => {
    e.preventDefault();
    const f = e.target, er = f.querySelector(".err"), btn = f.querySelector("button[type=submit]");
    er.textContent = ""; btn.disabled = true;
    try { G.user = await API.login(f.email.value, f.password.value); afterAuth(); }
    catch (x) { er.textContent = x.message; }
    finally { btn.disabled = false; }
  });
  $("#f-signup").addEventListener("submit", async (e) => {
    e.preventDefault();
    const f = e.target, er = f.querySelector(".err"), btn = f.querySelector("button[type=submit]");
    er.textContent = "";
    if (f.password.value !== f.password2.value) { er.textContent = t("pwMismatch"); return; }
    // 이메일 도메인 오타 확인 (예: naver.vom → naver.com) — 한 번 물어보고 그래도 그대로 가입하면 통과
    const sug = emailTypo(f.email.value.trim().toLowerCase());
    if (sug && f.dataset.okEmail !== f.email.value) {
      er.innerHTML = `${esc(t("emailTypo", { email: sug }))} <button type="button" class="link-btn inline" id="fix-email">${esc(t("emailTypoFix"))}</button>`;
      er.querySelector("#fix-email").addEventListener("click", () => { f.email.value = sug; er.textContent = ""; });
      f.dataset.okEmail = f.email.value; return;
    }
    btn.disabled = true;
    try { G.user = await API.signup(f.email.value, f.password.value, signupLang); toast(t("signedUp")); afterAuth(); }
    catch (x) { er.textContent = x.message; }
    finally { btn.disabled = false; }
  });
  const MAIL_DOMAINS = ["naver.com", "gmail.com", "daum.net", "hanmail.net", "kakao.com", "nate.com", "icloud.com", "hotmail.com", "outlook.com", "yahoo.com", "me.com", "yahoo.co.jp", "docomo.ne.jp", "ezweb.ne.jp", "softbank.ne.jp"];
  function editDist(a, b) { const d = Array.from({ length: a.length + 1 }, (_, i) => [i]); for (let j = 1; j <= b.length; j++) d[0][j] = j; for (let i = 1; i <= a.length; i++) for (let j = 1; j <= b.length; j++) d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); return d[a.length][b.length]; }
  function emailTypo(email) {
    const at = email.lastIndexOf("@"); if (at < 1) return null;
    const dom = email.slice(at + 1); if (MAIL_DOMAINS.includes(dom)) return null;
    let best = null, bd = 3; for (const d of MAIL_DOMAINS) { const x = editDist(dom, d); if (x < bd) { bd = x; best = d; } }
    return best && bd <= 2 ? email.slice(0, at + 1) + best : null;
  }
  function afterAuth() {
    if (document.activeElement) document.activeElement.blur();
    if (G.user.lang && G.user.lang !== I.lang) applyLang(G.user.lang);
    if (!G.user.avatar || !G.user.nickname) openCreator(false); else enterWorld();
  }
  $("#btn-continue").addEventListener("click", afterAuth);
  $("#btn-switch").addEventListener("click", () => { API.logout(); G.user = null; showAuthForms(); });
  function showAuthForms() { $("#auth-forms").classList.remove("hidden"); $("#auth-continue").classList.add("hidden"); }

  function refreshMe() {
    $("#me-name").textContent = G.user.nickname + (G.user.role === "artist" ? " 👑" : G.user.role === "admin" ? " ★" : "");
    const c = $("#me-face"), x = c.getContext("2d");
    x.clearRect(0, 0, c.width, c.height); x.imageSmoothingEnabled = false;
    Avatar.face(x, G.user.avatar, c.width, c.height);
    $("#chat-opts").classList.toggle("hidden", !staff(G.user.role));
    $("#btn-admin").classList.toggle("hidden", !staff(G.user.role));
    renderCoins();
    $("#online").textContent = API.demo ? t("demoSolo") : G.online > 1 ? t("online", { n: G.online }) : t("onlineShort");
  }

  async function enterWorld() {
    await fade(true);
    $("#title").classList.add("hidden");
    $("#creator").classList.add("hidden");
    $("#hud").classList.remove("hidden");
    G.mode = "world";
    // 모바일은 채팅창을 접은 상태로 시작
    if (IS_TOUCH) { $("#chat").classList.add("collapsed"); $("#chat-toggle").textContent = "▲"; }
    refreshMe();
    setScene("plaza");
    await fade(false);
    toast(t("welcome", { name: G.user.nickname }));
    sceneMusic(G.scene);
    checkDaily();
    loadMail(true);
    refreshRankTop();
    flushPendingRuns();
    pushOnEnter();
    // 알림을 눌러 들어왔으면 그 화면으로 (예: ?go=gallery)
    const goParam = new URLSearchParams(location.search).get("go");
    if (goParam === "gallery") { markAnnounceSeen(); setTimeout(openGallery, 700); setTimeout(() => showPromo(30), 1500); try { history.replaceState(null, "", location.pathname); } catch {} } // 갤러리를 닫으면 영상 팝업
    else if (G.user.tempPw) setTimeout(() => openPwChange(true), 900); // 임시 비밀번호로 들어왔으면 먼저 바꾸기
    else setTimeout(() => { showPromo(3); setTimeout(showAnnounce, 400); }, 1200); // 영상 팝업 → (닫으면) 공지
    setTimeout(maybeInstallPopup, 5500);
  }
  // 📅 앱을 켜 둔 채로 날짜가 바뀐 뒤 돌아오면(휴대폰에서 다음 날 다시 열 때 등) 영상 팝업을 다시 보여 줌
  const promoNewDay = () => { if (G.mode === "world" && G.promoDay && G.promoDay !== kstDay() && document.visibilityState === "visible") showPromo(30); };
  document.addEventListener("visibilitychange", promoNewDay);
  setInterval(promoNewDay, 60 * 1000);
  // ---------------- 📢 로그인 공지 (공지마다 한 번만) ----------------
  function markAnnounceSeen() { const a = CFG.announce; if (!a) return; try { localStorage.setItem("jl_ann_" + a.id, "1"); } catch {} }
  function showAnnounce() {
    const a = CFG.announce; if (!a || G.mode !== "world") return;
    try { if (localStorage.getItem("jl_ann_" + a.id)) return; } catch {}
    if (G.modalOpen || G.dive) return void setTimeout(showAnnounce, 4000);
    markAnnounceSeen();
    const goLabel = a.go === "gallery" ? "📷 " + t("annGoGallery") : "";
    openModal("📢 " + t("annTitle"), `<div class="ann"><div class="ann-pics">${(CFG.photos || []).filter((p) => p.isNew).slice(0, 3).map((p) => `<img src="${esc(p.src)}" alt="">`).join("")}</div>
      <p class="ann-text">${esc(L(a.text))}</p>${goLabel ? `<p style="text-align:center"><button class="btn pink" id="ann-go">${esc(goLabel)}</button></p>` : ""}</div>`, (el) => {
      const b = el.querySelector("#ann-go"); if (b) b.addEventListener("click", () => { if (a.go === "gallery") openGallery(); });
    });
  }
  function logout() {
    if (G.dive) endDive(); if (G.fish) endFishing(true); G.frozen = false;
    API.logout(); G.user = null; G.mode = "title"; G.others.clear(); stopMusic(); BGM.play("title");
    closeModal();
    $("#hud").classList.add("hidden"); $("#creator").classList.add("hidden");
    $("#title").classList.remove("hidden");
    G.scene = "plaza"; buildMinimap();
    showAuthForms();
  }
  $("#btn-logout").addEventListener("click", logout);

  // ---------------- 메인 루프 ----------------
  let last = performance.now();
  function loop(now) {
    const dt = Math.min(0.05, (now - last) / 1000); last = now;
    if (G.scene) { update(dt); render(); }
    if (!$("#creator").classList.contains("hidden")) drawPreview();
    requestAnimationFrame(loop);
  }

  window.__jelly = { G, runZone: (z) => runZone(z), closeModal: () => closeModal() };
  // ---------------- 시작 ----------------
  (async function boot() {
    I.apply();
    renderTitleLang();
    try { await Promise.race([Promise.all([document.fonts.load("11px Galmuri11"), document.fonts.load("bold 13px Galmuri11")]), new Promise((r) => setTimeout(r, 2500))]); } catch {}
    buildWorlds();
    makeNPCs();
    G.scene = "plaza"; buildMinimap();
    BGM.play("title"); // 로그인 화면 배경음악 (첫 터치 후 재생)
    requestAnimationFrame(loop);
    const demo = await API.init();
    if (demo) $("#demo").classList.remove("hidden");
    if (API.hasToken()) {
      try {
        G.user = await API.me();
        if (G.user.lang && G.user.lang !== I.lang) applyLang(G.user.lang);
        $("#cont-name").textContent = t("welcomeBack", { name: G.user.nickname || G.user.email });
        $("#auth-forms").classList.add("hidden"); $("#auth-continue").classList.remove("hidden");
      } catch { API.logout(); }
    }
    if (!API.hasToken() && getReset()) checkReset(false); // 비밀번호 찾기 요청 중이면 그 화면으로
  })();
})();
