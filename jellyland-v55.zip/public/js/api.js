/* JELLY LAND API 클라이언트
   - Netlify 배포 시: /api/* 서버리스 함수 사용 (회원 정보는 Netlify Blobs에 저장)
   - 로컬에서 파일만 열었을 때: 브라우저 저장소를 쓰는 "데모 모드"로 자동 전환 */
(function () {
  const TOKEN_KEY = "jl_token";
  const ls = {
    get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} },
    del(k) { try { localStorage.removeItem(k); } catch {} },
  };

  let token = ls.get(TOKEN_KEY, null);
  let demo = false;

  // 오류 메시지는 사용자 언어로 (i18n.js 의 e_* 키)
  function mkErr(code, status) {
    const T = window.I18N;
    const msg = T ? T.t("e_" + code) : code;
    const e = new Error(msg && !String(msg).startsWith("e_") ? msg : T ? T.t("err") : code);
    e.status = status; e.code = code; return e;
  }
  async function real(path, opts = {}) {
    let res;
    try {
      res = await fetch("/api/" + path, {
      method: opts.method || "GET",
      headers: { "content-type": "application/json", ...(token ? { authorization: "Bearer " + token } : {}) },
      body: opts.body ? JSON.stringify(opts.body) : undefined,
    });
    } catch { throw mkErr("net", 0); }
    let data = {};
    try { data = await res.json(); } catch {}
    if (!res.ok) throw mkErr(data.code || "server", res.status);
    return data;
  }

  // ---------------- 데모 모드 (서버 없이 동작) ----------------
  const sha = async (s) => {
    const b = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s));
    return [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, "0")).join("");
  };
  const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  const fail = (code, s = 400) => { throw mkErr(code, s); };
  const pub = (u) => ({ slotLeft: u.slotDay === new Date(Date.now() + 9 * 3600 * 1000).toISOString().slice(0, 10) ? Math.max(0, 20 - (u.slotCount | 0)) : 20, id: u.id, email: u.email, nickname: u.nickname, avatar: u.avatar, lang: u.lang || "ko", role: u.role || "fan", coins: u.coins | 0, inv: u.inv || [], daily: u.lastDaily || null, tempPw: !!u.tempPw, drink: u.drink && u.drink.until > Date.now() ? u.drink : null, fish: { have: u.fishHave || {}, total: u.fishTotal || {}, best: u.fishBest || {} }, bait: u.fishDay === kstDay() ? Math.max(0, 15 - (u.fishCount | 0)) : 15 });
  const kstDay = () => new Date(Date.now() + 9 * 3600 * 1000).toISOString().slice(0, 10);

  async function mock(path, opts = {}) {
    const b = opts.body || {};
    const users = ls.get("jl_demo_users", {});
    const [route, qs] = path.split("?");
    const q = new URLSearchParams(qs || "");
    if (route === "signup") {
      const email = String(b.email || "").trim().toLowerCase();
      if (!EMAIL_RE.test(email)) fail("email");
      if (String(b.password || "").length < 6) fail("pw6");
      if (users[email]) fail("exists", 409);
      users[email] = { id: "d" + Date.now(), email, pw: await sha(b.password), nickname: "", avatar: null, lang: b.lang || "ko", role: email.startsWith("admin") ? "admin" : "fan" }; // 데모: admin 으로 시작하는 메일은 관리자
      ls.set("jl_demo_users", users);
      return { token: "demo:" + email, user: pub(users[email]) };
    }
    if (route === "login") {
      const email = String(b.email || "").trim().toLowerCase();
      const u = users[email];
      if (!u || u.pw !== (await sha(b.password || ""))) fail("login", 401);
      return { token: "demo:" + email, user: pub(u) };
    }
    // 🔑 데모: 비밀번호 찾기 (브라우저 저장소에 요청 보관)
    if (route.startsWith("pwreset/")) {
      const email = String(b.email || "").trim().toLowerCase(), all = ls.get("jl_demo_resets", {}), r = all[email];
      if (route === "pwreset/request") { const token = Math.random().toString(36).slice(2); all[email] = { email, nick: b.nick, note: b.note || "", tok: token, ts: Date.now(), status: "pending" }; ls.set("jl_demo_resets", all); return { ok: true, token }; }
      const ok = r && r.tok === b.token;
      if (route === "pwreset/status") return { status: ok ? r.status : "none" };
      if (route === "pwreset/complete") { if (!ok || r.status !== "approved") fail("resetNo", 403); if (String(b.password || "").length < 6) fail("pw6"); users[email].pw = await sha(b.password); users[email].tempPw = false; ls.set("jl_demo_users", users); delete all[email]; ls.set("jl_demo_resets", all); return { token: "demo:" + email, user: pub(users[email]) }; }
    }
    const me = token && users[String(token).slice(5)];
    if (!me) fail("auth", 401);
    if (route === "me") return { user: pub(me) };
    if (route === "avatar") {
      const nn = (x) => String(x || "").replace(/\s+/g, "").toLowerCase();
      if (nn(b.nickname) !== nn(me.nickname) && Object.values(users).some((u) => u !== me && nn(u.nickname) === nn(b.nickname))) fail("nickTaken", 409);
      me.nickname = String(b.nickname || "").slice(0, 12); me.avatar = b.avatar;
      ls.set("jl_demo_users", users);
      return { user: pub(me) };
    }
    const save = () => ls.set("jl_demo_users", users);
    if (route === "daily") {
      const gained = {};
      if (!me.welcomed) { me.welcomed = true; me.coins = (me.coins | 0) + 100; gained.welcome = 100; }
      if (me.lastDaily !== kstDay()) { me.lastDaily = kstDay(); me.coins = (me.coins | 0) + 100; gained.daily = 100; }
      save(); return { user: pub(me), gained };
    }
    if (route === "shop/buy") {
      const it = (window.JELLY_SHOP || []).find((x) => x.id === b.item); if (!it) fail("notfound", 404);
      me.inv = me.inv || []; if (me.inv.includes(it.id)) return { user: pub(me) };
      if ((me.coins | 0) < it.price) fail("coins");
      me.coins -= it.price; me.inv.push(it.id); save(); return { user: pub(me) };
    }
    if (route === "cafe/buy") {
      if ((me.coins | 0) < 5) fail("coins");
      me.coins -= 5; me.drink = { k: b.k | 0, until: Date.now() + 240000 }; save(); return { user: pub(me) };
    }
    if (route === "game/start") return { run: Date.now() + ".demo" + (b.game === "up" ? ".up" : b.game === "tet" ? ".tet" : b.game === "jx" ? ".jx" : ""), dayLeft: me.gameDay === kstDay() ? Math.max(0, 600 - (me.gameCoins | 0)) : 600 };
    if (route === "game/finish") {
      if (me.gameDay !== kstDay()) { me.gameDay = kstDay(); me.gameCoins = 0; }
      const coins = Math.min(200, 600 - (me.gameCoins | 0), Math.floor((+b.m || 0) / (/\.(tet|jx)$/.test(String(b.run || "")) ? 1000 : 100)) * 5); me.gameCoins = (me.gameCoins | 0) + coins;
      const gk = String(b.run || "").endsWith(".up") ? "up" : String(b.run || "").endsWith(".tet") ? "tet" : String(b.run || "").endsWith(".jx") ? "jx" : "jump", bk = { jump: "best", up: "bestUp", tet: "bestTet", jx: "bestJx" }[gk], tk = { jump: "jl_demo_top", up: "jl_demo_top_up", tet: "jl_demo_top_tet", jx: "jl_demo_top_jx" }[gk];
      me.coins = (me.coins | 0) + coins; if ((+b.m | 0) > (me[bk] | 0)) me[bk] = +b.m | 0; save();
      let top = ls.get(tk, []).filter((e) => e.id !== me.id);
      top.push({ id: me.id, name: me.nickname, avatar: me.avatar, role: me.role || "fan", m: me[bk] | 0, ts: Date.now() });
      top = top.filter((e) => e.m > 0).sort((a, c) => c.m - a.m).slice(0, 10); ls.set(tk, top);
      return { user: pub(me), coins, best: me[bk] | 0, rank: top.findIndex((e) => e.id === me.id) + 1, top, dayLeft: 600 - me.gameCoins };
    }
    if (route === "slot/spin") {
      if (me.slotDay !== kstDay()) { me.slotDay = kstDay(); me.slotCount = 0; }
      if ((me.slotCount | 0) >= 20) fail("slotDaily", 429);
      if ((me.coins | 0) < 20) fail("coins");
      me.slotCount = (me.slotCount | 0) + 1;
      const r = Math.floor(Math.random() * 100000), O = ["grape", "bell", "note", "candy", "clover", "lemon"], pk = (a) => a[Math.floor(Math.random() * a.length)];
      let reels, outcome, mult;
      if (r < 333) { outcome = "jackpot"; mult = 100; reels = ["jelly", "jelly", "jelly"]; }
      else if (r < 1333) { outcome = "jelly2"; mult = 10; reels = ["jelly", "jelly", pk(O)].sort(() => Math.random() - 0.5); }
      else if (r < 7583) { outcome = "apple"; mult = 3; reels = ["apple", "apple", "apple"]; }
      else if (r < 13833) { outcome = "heart"; mult = 3; reels = ["heart", "heart", "heart"]; }
      else if (r < 53833) { outcome = "star"; mult = 1; reels = ["star", pk(O), pk(["apple", "heart", ...O])].sort(() => Math.random() - 0.5); }
      else { outcome = "lose"; mult = 0; do { reels = [0, 1, 2].map(() => pk(["jelly", "apple", "heart", ...O])); } while (reels.filter((x) => x === "jelly").length >= 2 || (reels[0] === reels[1] && reels[1] === reels[2])); }
      me.coins = (me.coins | 0) - 20 + 20 * mult; save();
      return { reels, outcome, payout: 20 * mult, bet: 20, user: pub(me) };
    }
    if (route === "rec") {
      const all = ls.get("jl_demo_rec", []), m = opts.method || "GET";
      const left = () => (me.recDay === kstDay() ? Math.max(0, 3 - (me.recCount | 0)) : 3);
      if (m === "GET") { const page = +q.get("page") || 0; return { entries: all.slice().reverse().slice(page * 15, page * 15 + 15), total: all.length, left: left() }; }
      if (m === "POST") {
        if (me.recDay !== kstDay()) { me.recDay = kstDay(); me.recCount = 0; }
        if ((me.recCount | 0) >= 3) fail("recDaily", 429);
        if (!b.notes || !b.notes.length) fail("recEmpty");
        const e = { id: me.id, name: me.nickname, role: me.role || "fan", avatar: me.avatar, title: String(b.title || "").slice(0, 30), notes: b.notes, len: Math.max(...b.notes.map((n) => n[0])), ts: Date.now(), key: "r" + Date.now() };
        all.push(e); ls.set("jl_demo_rec", all); me.recCount = (me.recCount | 0) + 1; save();
        return { entry: e, left: left() };
      }
      if (m === "DELETE") { ls.set("jl_demo_rec", all.filter((e) => e.key !== q.get("key"))); return { ok: true }; }
    }
    if (route === "mail") {
      const box = ls.get("jl_demo_mail_" + me.id, []);
      if ((opts.method || "GET") === "DELETE") { const nb = box.filter((m) => m.ts !== +q.get("ts")); ls.set("jl_demo_mail_" + me.id, nb); return { box: nb, unread: nb.filter((m) => !m.read).length }; }
      return { box, unread: box.filter((m) => !m.read).length };
    }
    if (route === "mail/read") { ls.set("jl_demo_mail_" + me.id, ls.get("jl_demo_mail_" + me.id, []).map((m) => ({ ...m, read: true }))); return { ok: true }; }
    if (route === "admin/users") return { users: Object.values(users).map((u) => ({ id: u.id, email: u.email, nickname: u.nickname, avatar: u.avatar, role: u.role || "fan", coins: u.coins | 0, createdAt: +String(u.id).slice(1) || 0, best: u.best | 0, bestUp: u.bestUp | 0, bestTet: u.bestTet | 0 })) };
    if (route === "admin/mail") {
      const m = { ts: Date.now(), from: me.nickname, fromRole: me.role || "admin", text: b.text, read: false, all: b.to === "all" };
      const ids = b.to === "all" ? Object.values(users).map((u) => u.id) : [b.to];
      ids.forEach((id) => { const k = "jl_demo_mail_" + id; ls.set(k, [m, ...ls.get(k, [])]); });
      return { ok: true, sent: ids.length };
    }
    if (route === "push/key") return { key: "" };
    if (route === "push/sub" || route === "push/host") return { ok: true, demo: true };
    if (route === "admin/coins") {
      const e = Object.keys(users).find((k) => users[k].id === b.id); if (!e) fail("notfound", 404);
      const u = users[e], before = u.coins | 0; u.coins = Math.max(0, b.mode === "set" ? +b.amount | 0 : before + (+b.amount | 0)); save();
      return { ok: true, id: u.id, coins: u.coins, diff: u.coins - before, user: u.id === me.id ? pub(u) : undefined };
    }
    // 🎣 데모: 젤리 해변 낚시 (진짜 확률·시간 검사는 서버에 — 표는 api.mjs 의 FISH 와 같게)
    if (route.startsWith("fish/")) {
      const F = [["goldfish", 30, 30, 1, 0.4, 80, 3, 0, 0, 8, 16], ["minnow", 40, 22, 1, 0.48, 70, 3, 0, 0, 5, 10], ["puffer", 60, 16, 2, 0.5, 64, 3, 0, 0, 14, 30], ["mackerel", 80, 11, 2, 0.58, 56, 3, 0, 0, 24, 45], ["flounder", 110, 7.5, 3, 0.6, 52, 3, 1, 0, 25, 50], ["halibut", 150, 5, 3, 0.68, 46, 2, 1, 0, 40, 85], ["cutlass", 220, 3.2, 4, 0.72, 42, 2, 1, 0, 80, 150], ["tuna", 320, 2, 4, 0.82, 38, 2, 1, 0, 100, 220], ["grouper", 500, 1.2, 5, 0.88, 34, 2, 1, 0, 60, 130], ["shark", 900, 0.7, 6, 0.95, 30, 2, 1, 1, 200, 420], ["orca", 1600, 0.35, 7, 1.05, 27, 1, 1, 1, 500, 820], ["cloudwhale", 4000, 0.15, 8, 1.12, 24, 1, 1, 1, 1000, 1800], ["furwhale", 20000, 0.08, 10, 1.1, 26, 2, 1, 1, 2500, 3600]];
      if (route === "fish/hall") return { hall: ls.get("jl_demo_whale", []) };
      if (route === "fish/cast") {
        if (me.fishDay !== kstDay()) { me.fishDay = kstDay(); me.fishCount = 0; }
        if ((me.fishCount | 0) >= 15) fail("fishNoBait", 429);
        let roll = Math.random() * F.reduce((a, f) => a + f[2], 0), f = F[0];
        for (const x of F) { roll -= x[2]; if (roll <= 0) { f = x; break; } }
        const id = Math.random().toString(36).slice(2, 10), tier = F.indexOf(f), size = Math.round(f[9] + (f[10] - f[9]) * Math.pow(Math.random(), 1.6));
        me.fishCast = { id, sp: f[0], size }; me.fishCount = (me.fishCount | 0) + 1; save();
        return { cast: { id, biteMs: Math.round(1500 + Math.random() * 3500 + tier * 120), need: f[3], speed: f[4], zone: f[5], miss: f[6], move: f[7], rev: f[8], limit: Math.round(f[3] * (1000 / f[4]) * 2.4 + 6000), tier }, user: pub(me) };
      }
      if (route === "fish/end") {
        const c = me.fishCast; if (!c || c.id !== b.id) fail("fishGone");
        me.fishCast = null;
        if (!b.ok) { save(); return { ok: false, sp: c.sp, user: pub(me) }; }
        me.fishHave = me.fishHave || {}; me.fishTotal = me.fishTotal || {}; me.fishBest = me.fishBest || {};
        me.fishHave[c.sp] = (me.fishHave[c.sp] | 0) + 1; me.fishTotal[c.sp] = (me.fishTotal[c.sp] | 0) + 1;
        const best = c.size > (me.fishBest[c.sp] | 0); if (best) me.fishBest[c.sp] = c.size;
        let hallN = 0;
        if (c.sp === "furwhale") { const hall = ls.get("jl_demo_whale", []); hallN = (hall[0] ? hall[0].n | 0 : 0) + 1; hall.unshift({ n: hallN, id: me.id, name: me.nickname, avatar: me.avatar, role: me.role || "fan", size: c.size, ts: Date.now() }); ls.set("jl_demo_whale", hall.slice(0, 100)); }
        save(); return { ok: true, sp: c.sp, size: c.size, best, hallN, user: pub(me) };
      }
      if (route === "fish/sell") {
        const have = me.fishHave || {}; let earned = 0, sold = 0;
        const sell = (sp, n) => { const f = F.find((x) => x[0] === sp); n = Math.max(0, Math.min(have[sp] | 0, n | 0)); if (!f || !n) return; have[sp] -= n; if (!have[sp]) delete have[sp]; earned += f[1] * n; sold += n; };
        if (b.all) { for (const sp of Object.keys(have)) if (sp !== "furwhale" || b.whale) sell(sp, have[sp]); } else sell(String(b.sp || ""), b.n);
        if (!sold) fail("fishNone");
        me.fishHave = have; me.coins = (me.coins | 0) + earned; save();
        return { earned, sold, user: pub(me) };
      }
    }
    // 🫧 데모: 분수대 퀴즈 (진짜 문제는 서버에만 있음 — 데모는 연습용 3문제)
    if (route.startsWith("sea/")) {
      const DQ = [["노르웨이의 수도는?", ["오슬로", "스톡홀름", "코펜하겐", "헬싱키"]], ["거미의 다리는 몇 개?", ["8", "6", "10", "4"]], ["태양계에서 가장 큰 행성은?", ["목성", "토성", "지구", "해왕성"]]];
      const now = Date.now(), lock = Math.max(0, (me.seaAt || 0) + 30 * 60e3 - now);
      if (route === "sea/dive") { me.sea = { t0: now, ok: 0 }; save(); return { o2: 15000, need: 2, coins: 400, lockLeft: lock }; }
      if (!me.sea || now - me.sea.t0 > 17500) fail("seaTimeout");
      if (lock > 0) fail("seaLocked");
      if (route === "sea/q") { const qi = (Math.random() * DQ.length) | 0, perm = [0, 1, 2, 3].sort(() => Math.random() - 0.5); me.sea.q = qi; me.sea.perm = perm; save(); return { q: DQ[qi][0], choices: perm.map((i) => DQ[qi][1][i]), ok: me.sea.ok, need: 2 }; }
      if (route === "sea/answer") {
        const answer = me.sea.perm.indexOf(0), correct = (b.choice | 0) === answer; if (correct) me.sea.ok++;
        if (me.sea.ok >= 2) { me.sea = null; me.seaAt = now; me.coins = (me.coins | 0) + 400; save(); return { correct, answer, ok: 2, opened: true, coins: 400, lockLeft: 30 * 60e3, user: pub(me) }; }
        save(); return { correct, answer, ok: me.sea.ok, opened: false };
      }
    }
    // 🎨 데모: 그림 갤러리
    if (route.startsWith("art")) {
      let arts = ls.get("jl_demo_art", []);
      const left = () => (me.role === "admin" ? 99 : me.artDay === kstDay() ? Math.max(0, 3 - (me.artCount | 0)) : 3);
      const view = (e) => ({ ...e, likes: (e.likes || []).length, liked: (e.likes || []).includes(me.id) });
      if (route === "art" && (!opts.method || opts.method === "GET")) {
        const list = arts.slice().sort(q.get("sort") === "top" ? (x, y) => (y.likes || []).length - (x.likes || []).length || y.ts - x.ts : (x, y) => y.ts - x.ts);
        const page = +q.get("page") || 0; return { items: list.slice(page * 12, page * 12 + 12).map(view), total: list.length, left: left() };
      }
      if (route === "art" && opts.method === "POST") {
        if (left() <= 0) fail("artDaily", 429);
        if (me.artDay !== kstDay()) { me.artDay = kstDay(); me.artCount = 0; }
        let gained = 0; if (!me.artCount) { gained = 50; me.coins = (me.coins | 0) + 50; }
        me.artCount = (me.artCount | 0) + 1; save();
        const e = { id: Date.now().toString(36), uid: me.id, name: me.nickname, role: me.role || "fan", avatar: me.avatar, title: String(b.title || "").slice(0, 30), ts: Date.now(), likes: [], img: b.img };
        arts.push(e); try { ls.set("jl_demo_art", arts.slice(-30)); } catch {}
        return { item: view(e), left: left(), gained, user: pub(me) };
      }
      if (route === "art/like") { const e = arts.find((x) => x.id === b.id); if (!e) fail("notfound", 404); e.likes = e.likes.includes(me.id) ? e.likes.filter((u) => u !== me.id) : [...e.likes, me.id]; ls.set("jl_demo_art", arts); return { item: view(e) }; }
      if (route === "art" && opts.method === "DELETE") { ls.set("jl_demo_art", arts.filter((x) => x.id !== q.get("id"))); return { ok: true }; }
    }
    if (route === "admin/pwresets") { const all = ls.get("jl_demo_resets", {}); return { requests: Object.values(all).map((r) => ({ ...r, account: users[r.email] ? { id: users[r.email].id, nickname: users[r.email].nickname, avatar: users[r.email].avatar } : null, sameNick: Object.values(users).filter((u) => u.nickname === r.nick && u.email !== r.email).map((u) => ({ id: u.id, email: u.email })) })) }; }
    if (route === "admin/pwreset/decide") { const all = ls.get("jl_demo_resets", {}); const r = all[String(b.email).toLowerCase()]; if (!r) fail("notfound", 404); if (b.ok === "delete") delete all[r.email]; else { r.status = b.ok ? "approved" : "rejected"; r.decidedAt = Date.now(); } ls.set("jl_demo_resets", all); return { ok: true }; }
    if (route === "admin/email") { const e = Object.keys(users).find((k) => users[k].id === b.id); if (!e) fail("notfound", 404); const ne = String(b.email).toLowerCase(); if (users[ne]) fail("exists", 409); users[ne] = { ...users[e], email: ne }; delete users[e]; save(); return { ok: true, email: ne }; }
    if (route === "admin/pwreset/temp") { const e = Object.keys(users).find((k) => users[k].id === b.id); if (!e) fail("notfound", 404); const pw = "jelly-" + Math.random().toString(36).slice(2, 8); users[e].pw = await sha(pw); users[e].tempPw = true; save(); return { ok: true, password: pw, email: e }; }
    if (route === "password") { if (me.pw !== (await sha(b.old || ""))) fail("pwWrong"); if (String(b.password || "").length < 6) fail("pw6"); me.pw = await sha(b.password); me.tempPw = false; save(); return { ok: true, user: pub(me) }; }
    if (route === "admin/rank") {
      const e = Object.keys(users).find((k) => users[k].id === b.id); if (!e) fail("notfound", 404);
      const u = users[e], bk = { jump: "best", up: "bestUp", tet: "bestTet", jx: "bestJx" }[b.game] || "best", tk = { jump: "jl_demo_top", up: "jl_demo_top_up", tet: "jl_demo_top_tet", jx: "jl_demo_top_jx" }[b.game] || "jl_demo_top";
      const m = b.mode === "remove" ? 0 : Math.max(0, Math.floor(+b.m || 0)); u[bk] = m; save();
      let top = ls.get(tk, []); const old = top.find((x) => x.id === u.id); top = top.filter((x) => x.id !== u.id);
      if (m > 0) top.push({ id: u.id, name: u.nickname, avatar: u.avatar, role: u.role || "fan", m, ts: old ? old.ts : Date.now() });
      top = top.sort((x, y) => y.m - x.m || x.ts - y.ts).slice(0, 10); ls.set(tk, top);
      return { ok: true, id: u.id, game: b.game, m, rank: top.findIndex((x) => x.id === u.id) + 1, top };
    }
    if (route === "admin/delete") { const e = Object.keys(users).find((k) => users[k].id === b.id); if (e) delete users[e]; save(); return { ok: true }; }
    if (route === "game/top") {
      if (q.get("game") === "all") return { jump: ls.get("jl_demo_top", [])[0] || null, up: ls.get("jl_demo_top_up", [])[0] || null, tet: ls.get("jl_demo_top_tet", [])[0] || null, jx: ls.get("jl_demo_top_jx", [])[0] || null };
      const gk = ["up", "tet", "jx"].includes(q.get("game")) ? q.get("game") : "jump";
      return { top: ls.get({ jump: "jl_demo_top", up: "jl_demo_top_up", tet: "jl_demo_top_tet", jx: "jl_demo_top_jx" }[gk], []), best: me[{ jump: "best", up: "bestUp", tet: "bestTet", jx: "bestJx" }[gk]] | 0 };
    }
    if (route === "settings") { if (b.lang) me.lang = b.lang; ls.set("jl_demo_users", users); return { user: pub(me) }; }
    if (route === "presence") return { others: [], online: 1 };
    if (route === "sync") {
      const room = b.scene || "plaza";
      const all = ls.get("jl_demo_chat_" + room, []);
      return { others: [], online: 1, messages: all.filter((m) => m.ts >= (b.since || 0)).slice(-50), notice: ls.get("jl_demo_notice_" + room, null) };
    }
    if (route === "guestbook") {
      const all = ls.get("jl_demo_gb", []);
      const m = opts.method || "GET";
      if (m === "GET") { const page = +q.get("page") || 0; return { entries: all.slice().reverse().slice(page * 20, page * 20 + 20), total: all.length }; }
      if (m === "POST") {
        const text = String(b.text || "").trim().slice(0, 300); if (!text) fail("msg");
        if (me.gbDay === kstDay() && me.role !== "admin" && me.role !== "artist") fail("gbDaily", 429);
        const e = { id: me.id, name: me.nickname, role: me.role || "fan", avatar: me.avatar, text, ts: Date.now(), key: "g" + Date.now() };
        all.push(e); ls.set("jl_demo_gb", all);
        const d = kstDay(); if (me.gbDay !== d) { me.gbDay = d; me.gbCount = 0; }
        let coins = 0; if ((me.gbCount | 0) < 1) { me.gbCount = 1; me.coins = (me.coins | 0) + 50; coins = 50; }
        save(); return { entry: e, coins, user: pub(me) };
      }
      if (m === "DELETE") { ls.set("jl_demo_gb", all.filter((e) => e.key !== q.get("key"))); return { ok: true }; }
    }
    if (route === "chat") {
      const room = q.get("room") || b.room || "lounge";
      const all = ls.get("jl_demo_chat_" + room, []);
      if ((opts.method || "GET") === "GET") {
        const since = +q.get("since") || 0;
        return { messages: all.filter((m) => m.ts > since).slice(-60), notice: ls.get("jl_demo_notice_" + room, null) };
      }
      if (opts.method === "POST") {
        const text = String(b.text || "").trim().slice(0, 200);
        if (!text) fail("msg");
        const m = { id: me.id, name: me.nickname, role: me.role || "fan", text, ts: Date.now(), key: "k" + Date.now(), ...(await demoTranslate(text)) };
        all.push(m); ls.set("jl_demo_chat_" + room, all.slice(-60));
        return { message: m };
      }
    }
    fail("notfound", 404);
  }

  // 데모 모드: 브라우저에서 무료 번역 API 직접 호출 (실패하면 원문 그대로)
  async function demoTranslate(text) {
    const src = /[\uAC00-\uD7A3\u3131-\u318E]/.test(text) ? "ko" : /[\u3040-\u30FF\u4E00-\u9FFF]/.test(text) ? "ja" : "en";
    const tr = { [src]: text };
    await Promise.all(["ko", "en", "ja"].filter((l) => l !== src).map(async (to) => {
      try {
        const c = new AbortController(); setTimeout(() => c.abort(), 4000);
        const r = await fetch(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=${src}|${to}`, { signal: c.signal });
        const d = await r.json();
        if (Number(d.responseStatus) === 200 && !/MYMEMORY WARNING/i.test(d.responseData.translatedText)) tr[to] = d.responseData.translatedText;
      } catch {}
    }));
    return { lang: src, tr };
  }

  // 서버가 새 토큰(닉네임·아바타 포함)을 주면 교체
  function keep(d) { if (d && d.token) { token = d.token; ls.set(TOKEN_KEY, token); } return d; }

  async function call(path, opts) { return demo ? mock(path, opts) : real(path, opts); }

  window.JellyAPI = {
    get demo() { return demo; },
    async init() {
      try {
        const r = await fetch("/api/health", { cache: "no-store" });
        const d = await r.json();
        demo = !d.ok;
      } catch { demo = true; }
      if (demo && token && !String(token).startsWith("demo:")) token = null;
      return demo;
    },
    hasToken: () => !!token,
    get token() { return token; },
    async signup(email, password, lang) { const d = await call("signup", { method: "POST", body: { email, password, lang } }); token = d.token; ls.set(TOKEN_KEY, token); return d.user; },
    async login(email, password) { const d = await call("login", { method: "POST", body: { email, password } }); token = d.token; ls.set(TOKEN_KEY, token); return d.user; },
    logout() { token = null; ls.del(TOKEN_KEY); },
    async me() { return keep(await call("me")).user; },
    async saveAvatar(nickname, avatar) { return keep(await call("avatar", { method: "POST", body: { nickname, avatar } })).user; },
    async saveSettings(s) { return keep(await call("settings", { method: "POST", body: s })).user; },
    sync: (p) => call("sync", { method: "POST", body: p }),
    presence: (p) => call("presence", { method: "POST", body: p }),
    chatList: (room, since) => call(`chat?room=${room}&since=${since || 0}`),
    chatSend: (room, text, notice) => call("chat", { method: "POST", body: { room, text, notice: !!notice } }),
    gbList: (page) => call("guestbook?page=" + (page || 0)),
    gbWrite: (text) => call("guestbook", { method: "POST", body: { text } }),
    gbDelete: (key) => call("guestbook?key=" + encodeURIComponent(key), { method: "DELETE" }),
    daily: () => call("daily", { method: "POST", body: {} }),
    buy: (item) => call("shop/buy", { method: "POST", body: { item } }),
    cafeBuy: (k) => call("cafe/buy", { method: "POST", body: { k } }),
    // 🎣 낚시 · 🐠 어항 · 🐋 털보고래 명예의 전당
    fishCast: () => call("fish/cast", { method: "POST", body: {} }),
    fishEnd: (id, ok) => call("fish/end", { method: "POST", body: { id, ok: !!ok } }),
    fishSell: (b) => call("fish/sell", { method: "POST", body: b }),
    fishHall: () => call("fish/hall"),
    gameStart: (game) => call("game/start", { method: "POST", body: { game: game || "jump" } }),
    slotSpin: () => call("slot/spin", { method: "POST", body: {} }),
    gameTop: (game) => call("game/top?game=" + (game || "jump")),
    mail: () => call("mail"),
    recList: (page) => call("rec?page=" + (page || 0)),
    recPost: (notes, title) => call("rec", { method: "POST", body: { notes, title } }),
    recDelete: (key) => call("rec?key=" + encodeURIComponent(key), { method: "DELETE" }),
    mailRead: () => call("mail/read", { method: "POST", body: {} }),
    mailDelete: (ts) => call("mail?ts=" + ts, { method: "DELETE" }),
    adminUsers: () => call("admin/users"),
    adminMail: (to, text) => call("admin/mail", { method: "POST", body: { to, text } }),
    adminCoins: (id, mode, amount) => call("admin/coins", { method: "POST", body: { id, mode, amount } }),
    pushKey: () => call("push/key"),
    pushSub: (sub) => call("push/sub", { method: "POST", body: { sub } }),
    pushHost: () => call("push/host", { method: "POST", body: {} }),
    adminRank: (game, id, m, mode) => call("admin/rank", { method: "POST", body: { game, id, m, mode } }),
    pwResetRequest: (email, nick, note, lang) => call("pwreset/request", { method: "POST", body: { email, nick, note, lang } }),
    pwResetStatus: (email, token) => call("pwreset/status", { method: "POST", body: { email, token } }),
    async pwResetComplete(email, tok, password) { const d = await call("pwreset/complete", { method: "POST", body: { email, token: tok, password } }); token = d.token; ls.set(TOKEN_KEY, token); return d.user; },
    changePassword: (old, password) => call("password", { method: "POST", body: { old, password } }),
    adminPwResets: () => call("admin/pwresets"),
    adminPwDecide: (email, ok) => call("admin/pwreset/decide", { method: "POST", body: { email, ok } }),
    adminEmail: (id, email) => call("admin/email", { method: "POST", body: { id, email } }),
    adminTempPw: (id) => call("admin/pwreset/temp", { method: "POST", body: { id } }),
    adminDelete: (id) => call("admin/delete", { method: "POST", body: { id } }),
    gameFinish: (run, m) => call("game/finish", { method: "POST", body: { run, m } }),
    seaDive: () => call("sea/dive", { method: "POST", body: {} }),
    seaQ: (lang) => call("sea/q", { method: "POST", body: { lang } }),
    seaAnswer: (choice) => call("sea/answer", { method: "POST", body: { choice } }),
    artList: (page, sort) => call(`art?page=${page || 0}&sort=${sort || "new"}`),
    artPost: (img, title) => call("art", { method: "POST", body: { img, title } }),
    artLike: (id) => call("art/like", { method: "POST", body: { id } }),
    artDelete: (id) => call("art?id=" + encodeURIComponent(id), { method: "DELETE" }),
    artImg: (it) => it.img || "/api/art/img?id=" + encodeURIComponent(it.id),
    chatDelete: (key) => call("chat?key=" + encodeURIComponent(key), { method: "DELETE" }),
  };
})();
